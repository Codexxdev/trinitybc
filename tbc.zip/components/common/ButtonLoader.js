import BeatLoader from "react-spinners/BeatLoader";

const ButtonLoader = () => {
    return (
        <BeatLoader color="#ffffff"  size={10} />
    )
}

export default ButtonLoader
