"use strict";
(() => {
var exports = {};
exports.id = 3247;
exports.ids = [3247];
exports.modules = {

/***/ 949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(29);
// EXTERNAL MODULE: external "babel-plugin-superjson-next/tools"
var tools_ = __webpack_require__(1421);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7794);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Player.js + 2 modules
var Player = __webpack_require__(2640);
// EXTERNAL MODULE: ./components/sermons/Body.js
var Body = __webpack_require__(5447);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/features/currentUser.js
var currentUser = __webpack_require__(3998);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/biblestudy/Details.js









const Details = () => {
  const {
    bibleStudy
  } = (0,external_react_redux_.useSelector)(state => state.clientBibleStudy);
  const dispatch = (0,external_react_redux_.useDispatch)();
  (0,external_react_.useEffect)(() => {
    dispatch((0,currentUser/* loadUser */.I)());
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "!mb-20  w-full space-y-5",
    children: [/*#__PURE__*/jsx_runtime_.jsx(Player/* default */.Z, {
      resource: bibleStudy
    }), /*#__PURE__*/jsx_runtime_.jsx(Body/* default */.Z, {
      resource: bibleStudy
    })]
  });
};

/* harmony default export */ const biblestudy_Details = (Details);
// EXTERNAL MODULE: ./redux/features/client/bibleStudy.js
var bibleStudy = __webpack_require__(9695);
// EXTERNAL MODULE: ./redux/Store.js
var Store = __webpack_require__(3501);
;// CONCATENATED MODULE: ./pages/resources/biblestudy/[id].js




var __jsx = (external_react_default()).createElement;






function BibleStudyPage() {
  return __jsx("div", null, __jsx((head_default()), null, __jsx("title", null, "TBC | Preaching Series")), __jsx(biblestudy_Details, null));
}

/* harmony default export */ const _id_ = ((0,tools_.withSuperJSONPage)(BibleStudyPage));
var getServerSideProps = (0,tools_.withSuperJSONProps)(Store/* wrapper.getServerSideProps */.Y.getServerSideProps(function (store) {
  return /*#__PURE__*/function () {
    var _ref2 = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(_ref) {
      var req, params, id;
      return regenerator_default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              req = _ref.req, params = _ref.params;
              id = params.id;
              _context.next = 4;
              return store.dispatch((0,bibleStudy/* getClientBibleStudyDetails */.h)({
                req: req,
                id: id
              }));

            case 4:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }();
}), []);

/***/ }),

/***/ 3622:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBack");

/***/ }),

/***/ 1883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForward");

/***/ }),

/***/ 3681:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloudDownload");

/***/ }),

/***/ 416:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PauseCircleOutline");

/***/ }),

/***/ 1929:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PlayCircleOutline");

/***/ }),

/***/ 3682:
/***/ ((module) => {

module.exports = require("@mui/material/Slider");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 4146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 5506:
/***/ ((module) => {

module.exports = require("next-absolute-url");

/***/ }),

/***/ 5648:
/***/ ((module) => {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,5675,5771,4519,9198,9422,5152,3036,9403,9041,6199,1806,1505,2934,9506,2993,3501,1618,5649], () => (__webpack_exec__(949)));
module.exports = __webpack_exports__;

})();