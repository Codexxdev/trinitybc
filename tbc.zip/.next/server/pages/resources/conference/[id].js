"use strict";
(() => {
var exports = {};
exports.id = 627;
exports.ids = [627];
exports.modules = {

/***/ 5882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(29);
// EXTERNAL MODULE: external "babel-plugin-superjson-next/tools"
var tools_ = __webpack_require__(1421);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7794);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Player.js + 2 modules
var Player = __webpack_require__(2640);
// EXTERNAL MODULE: ./components/series/Body.js
var Body = __webpack_require__(9039);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/features/currentUser.js
var currentUser = __webpack_require__(3998);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/conference/Details.js











const Details = () => {
  const {
    conference
  } = (0,external_react_redux_.useSelector)(state => state.clientConference);
  const {
    0: current,
    1: setCurrent
  } = (0,external_react_.useState)(conference.sermons[0]);
  const dispatch = (0,external_react_redux_.useDispatch)();
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    if (router.query.index) {
      setCurrent(conference.sermons[router.query.index]);
    }

    dispatch((0,currentUser/* loadUser */.I)());
  }, []);

  const changeCurrent = index => {
    setCurrent(conference.sermons[index]);
    scrollToTop();
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const scrollToAll = () => {
    window.scrollTo({
      top: 1200,
      behavior: 'smooth'
    });
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: ` !mb-20 w-full`,
    children: [/*#__PURE__*/jsx_runtime_.jsx(Player/* default */.Z, {
      resource: current
    }), /*#__PURE__*/jsx_runtime_.jsx(Body/* default */.Z, {
      series: conference,
      scrollToTop: scrollToTop,
      scrollToAll: scrollToAll,
      current: current,
      changeCurrent: changeCurrent
    })]
  });
};

/* harmony default export */ const conference_Details = (Details);
// EXTERNAL MODULE: ./redux/features/client/conference.js
var conference = __webpack_require__(4153);
// EXTERNAL MODULE: ./redux/Store.js
var Store = __webpack_require__(3501);
;// CONCATENATED MODULE: ./pages/resources/conference/[id].js




var __jsx = (external_react_default()).createElement;






function SermonPage() {
  return __jsx("div", null, __jsx((head_default()), null, __jsx("title", null, "TBC | Conference Messages")), __jsx(conference_Details, null));
}

/* harmony default export */ const _id_ = ((0,tools_.withSuperJSONPage)(SermonPage));
var getServerSideProps = (0,tools_.withSuperJSONProps)(Store/* wrapper.getServerSideProps */.Y.getServerSideProps(function (store) {
  return /*#__PURE__*/function () {
    var _ref2 = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(_ref) {
      var req, params, id;
      return regenerator_default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              req = _ref.req, params = _ref.params;
              id = params.id;
              _context.next = 4;
              return store.dispatch((0,conference/* getClientConferenceDetails */.c)({
                req: req,
                id: id
              }));

            case 4:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }();
}), []);

/***/ }),

/***/ 3622:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBack");

/***/ }),

/***/ 1883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForward");

/***/ }),

/***/ 3681:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloudDownload");

/***/ }),

/***/ 3042:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GraphicEq");

/***/ }),

/***/ 2803:
/***/ ((module) => {

module.exports = require("@mui/icons-material/OndemandVideo");

/***/ }),

/***/ 416:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PauseCircleOutline");

/***/ }),

/***/ 1929:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PlayCircleOutline");

/***/ }),

/***/ 3682:
/***/ ((module) => {

module.exports = require("@mui/material/Slider");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 4146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 5506:
/***/ ((module) => {

module.exports = require("next-absolute-url");

/***/ }),

/***/ 5648:
/***/ ((module) => {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,5675,5771,4519,9198,9422,5152,3036,9403,9041,6199,1806,1505,2934,9506,2993,3501,1569,1618,9039], () => (__webpack_exec__(5882)));
module.exports = __webpack_exports__;

})();