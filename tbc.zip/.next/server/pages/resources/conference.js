"use strict";
(() => {
var exports = {};
exports.id = 3954;
exports.ids = [3954];
exports.modules = {

/***/ 8748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ conference),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(29);
// EXTERNAL MODULE: external "babel-plugin-superjson-next/tools"
var tools_ = __webpack_require__(1421);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7794);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/conference/Hero.js



const Hero = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "bg-gradient-to-r from-primary-dark to-primary-light text-[white]  pt-[100px]  md:pt-[68px] ",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "container px-2 md:px-0 lg:px-[2rem] pb-16 pt-10 md:pb-36 md:pt-28  flex flex-col items-center justify-center space-y-5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "text-xl md:text-3xl   text-center uppercase font-medium",
        children: "Conference Messages"
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "text-sm md:text-base max-w-screen-md mx-auto font-light text-center",
        children: "Access our biblical resources here at TBC. Read, Watch and Listen to sound teachings from faithful Ministers of the Gospel."
      })]
    })
  });
};

/* harmony default export */ const conference_Hero = (Hero);
// EXTERNAL MODULE: ./components/sermons/Filter.js + 2 modules
var Filter = __webpack_require__(5727);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "@mui/icons-material/GraphicEq"
var GraphicEq_ = __webpack_require__(3042);
var GraphicEq_default = /*#__PURE__*/__webpack_require__.n(GraphicEq_);
// EXTERNAL MODULE: external "@mui/icons-material/OndemandVideo"
var OndemandVideo_ = __webpack_require__(2803);
var OndemandVideo_default = /*#__PURE__*/__webpack_require__.n(OndemandVideo_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./components/common/blur.js
var common_blur = __webpack_require__(1569);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(4146);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/common/Pagination.js
var Pagination = __webpack_require__(7989);
// EXTERNAL MODULE: ./redux/features/client/ministers.js
var ministers = __webpack_require__(7334);
;// CONCATENATED MODULE: ./components/conference/List.js
















const List = () => {
  const {
    0: fitlerToggle,
    1: setFilterToggle
  } = (0,external_react_.useState)(false);
  const {
    0: sortToggle,
    1: setSortToggle
  } = (0,external_react_.useState)(false);
  const {
    conferences,
    totalItems,
    resPerPage,
    topics,
    preachers,
    scriptures
  } = (0,external_react_redux_.useSelector)(state => state.clientConferences);
  const dispatch = (0,external_react_redux_.useDispatch)();
  const router = (0,router_.useRouter)();
  const page = Number(router.query.page) || 1;
  (0,external_react_.useEffect)(() => {
    dispatch((0,ministers/* getClientMinisters */.s)());
  }, [conferences]);

  const lister = index => {
    const dp = [];
    conferences[index].sermons.map(sermon => {
      dp.push(sermon.preacher.imageUrl.url);
    });
    let images = [...new Set(dp)];
    return images.map(image => /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "!ml-[-6px] h-[25px] w-[25px] md:h-[35px] md:w-[35px] border-2 border-gray-50  rounded-full relative",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
        src: image,
        className: "object-cover w-full h-full rounded-full",
        layout: "fill",
        blurDataURL: common_blur/* default */.Z,
        placeholder: "blur",
        alt: "logo"
      })
    }, image));
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: ` md:mt-10`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "container md:px-0 lg:px-[2rem]",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "hidden lg:block uppercase text-center lg:text-left text-sm font-light mb-5",
        children: `${totalItems > 1 ? totalItems + " Results" : totalItems + " Result"} - Page ${page}`
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-20 ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "lg:hidden text-center uppercase text-xs font-light ",
          children: `${totalItems > 1 ? totalItems + " Results" : totalItems + " Result"} - Page ${page}`
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "lg:col-span-7 lg:!mt-10",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "grid gap-5 grid-cols-1 md:grid-cols-2 ",
            children: conferences.map((conference, index) => /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              href: `/resources/conference/${conference._id}`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "w-full flex flex-row-reverse items-center md:rounded-md md:flex-col bg-[white] space-x-1 md:space-x-0\r md:py-0 md:px-0 px-2 py-2 shadow-sm md:shadow-xl hover:md:shadow-2xl hover:md:scale-105 cursor-pointer",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "w-[80px] h-[75px] md:w-full md:h-[170px] md:rounded-t-md rounded-lg  relative",
                    children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                      src: conference.imageUrl.url,
                      className: "object-cover w-full h-full rounded-lg md:rounded-none md:rounded-t-md ",
                      layout: "fill",
                      blurDataURL: common_blur/* default */.Z,
                      placeholder: "blur",
                      alt: "logo"
                    })
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "w-full md:p-5 space-y-2",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "flex space-x-1",
                      children: [/*#__PURE__*/jsx_runtime_.jsx((GraphicEq_default()), {
                        className: "text-[orange] !text-base"
                      }), /*#__PURE__*/jsx_runtime_.jsx((OndemandVideo_default()), {
                        className: "text-[red]/80 !text-base"
                      }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                        className: "text-xs font-light uppercase",
                        children: `| ${conference.sermons.length > 1 ? conference.sermons.length + " sermons" : conference.sermons.length + " sermon"}`
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                      className: "capitalize md:!mt-5",
                      children: conference.title
                    }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                      className: "md:hidden text-xs tracking-wider uppercase ",
                      children: (0,external_date_fns_.format)(new Date(conference.startDate), 'MMM, do yyyy')
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "flex items-center md:!mt-5 justify-between pr-5 md:pr-0",
                      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                        className: "flex items-center ml-[6px]",
                        children: lister(index)
                      }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                        className: "hidden md:block text-xs tracking-wider uppercase ",
                        children: (0,external_date_fns_.format)(new Date(conference.startDate), 'MMM, do yyyy')
                      })]
                    })]
                  })]
                })
              })
            }, conference._id))
          }), totalItems > resPerPage && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex !my-10 w-full items-center justify-center",
            children: /*#__PURE__*/jsx_runtime_.jsx(Pagination/* Pagination */.t, {
              resPerPage: resPerPage,
              page: page,
              totalItems: totalItems
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: " lg:col-span-5 lg:!mt-10 order-first lg:order-last",
          children: /*#__PURE__*/jsx_runtime_.jsx(Filter/* default */.Z, {
            topics: topics,
            preachers: preachers,
            scriptures: scriptures,
            fitlerToggle: fitlerToggle,
            setFilterToggle: setFilterToggle,
            sortToggle: sortToggle,
            setSortToggle: setSortToggle
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const conference_List = (List);
// EXTERNAL MODULE: ./redux/features/currentUser.js
var currentUser = __webpack_require__(3998);
;// CONCATENATED MODULE: ./components/conference/Conference.js








const Conference = () => {
  const dispatch = (0,external_react_redux_.useDispatch)();
  (0,external_react_.useEffect)(() => {
    dispatch((0,currentUser/* loadUser */.I)());
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "!mb-20  w-full",
    children: [/*#__PURE__*/jsx_runtime_.jsx(conference_Hero, {}), /*#__PURE__*/jsx_runtime_.jsx(conference_List, {})]
  });
};

/* harmony default export */ const conference_Conference = (Conference);
// EXTERNAL MODULE: ./redux/features/client/conferences.js
var conferences = __webpack_require__(3253);
// EXTERNAL MODULE: ./redux/Store.js
var Store = __webpack_require__(3501);
;// CONCATENATED MODULE: ./pages/resources/conference/index.js




var __jsx = (external_react_default()).createElement;






function ConferencePage() {
  return __jsx("div", null, __jsx((head_default()), null, __jsx("title", null, "TBC | Conference Messages")), __jsx(conference_Conference, null));
}

/* harmony default export */ const conference = ((0,tools_.withSuperJSONPage)(ConferencePage));
var getServerSideProps = (0,tools_.withSuperJSONProps)(Store/* wrapper.getServerSideProps */.Y.getServerSideProps(function (store) {
  return /*#__PURE__*/function () {
    var _ref2 = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(_ref) {
      var req, query, topic, preacher, page, sort, scripture;
      return regenerator_default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              req = _ref.req, query = _ref.query;
              topic = query.topic, preacher = query.preacher, page = query.page, sort = query.sort, scripture = query.scripture;
              _context.next = 4;
              return store.dispatch((0,conferences/* getClientConferences */.ov)({
                req: req,
                topic: topic,
                preacher: preacher,
                page: page,
                sort: sort,
                scripture: scripture
              }));

            case 4:
              _context.next = 6;
              return store.dispatch((0,conferences/* getConferenceFilters */.Oy)({
                req: req
              }));

            case 6:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }();
}), []);

/***/ }),

/***/ 3042:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GraphicEq");

/***/ }),

/***/ 2803:
/***/ ((module) => {

module.exports = require("@mui/icons-material/OndemandVideo");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 4146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 5506:
/***/ ((module) => {

module.exports = require("next-absolute-url");

/***/ }),

/***/ 5648:
/***/ ((module) => {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5636:
/***/ ((module) => {

module.exports = require("react-js-pagination");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,5675,676,1664,5771,4519,9198,9422,5152,3036,9403,9041,6199,1806,1505,2934,9506,2993,3501,1569,7989,1294], () => (__webpack_exec__(8748)));
module.exports = __webpack_exports__;

})();