(() => {
var exports = {};
exports.id = 7695;
exports.ids = [7695,1569];
exports.modules = {

/***/ 8095:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Hero__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7617);
/* harmony import */ var _Lists__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2019);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _redux_features_currentUser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3998);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Lists__WEBPACK_IMPORTED_MODULE_1__]);
_Lists__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const Events = () => {
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    dispatch((0,_redux_features_currentUser__WEBPACK_IMPORTED_MODULE_4__/* .loadUser */ .I)());
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: "!mb-20  w-full",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Hero__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_Lists__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Events);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



const Hero = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: "bg-gradient-to-r from-primary-dark to-primary-light text-[white]  pt-[100px]  md:pt-[68px] ",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "container px-2 md:px-0 lg:px-[2rem] pb-16 pt-10 md:pb-36 md:pt-28  flex flex-col items-center justify-center space-y-5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
        className: "text-xl md:text-3xl  text-center uppercase font-medium",
        children: "Upcoming Events & News"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
        className: "text-sm md:text-base max-w-screen-md mx-auto font-light text-center",
        children: "Mark your calender, learn more, and register for upcoming events in Trinity Baptist Church Abuja. Also, gain access to the latest news and updates from the church."
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);

/***/ }),

/***/ 2019:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5675);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(983);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_datepicker__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5994);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _common_blur__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1569);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2905);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([html_react_parser__WEBPACK_IMPORTED_MODULE_8__]);
html_react_parser__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const defaultImage = "https://res.cloudinary.com/dk6uhtgvo/image/upload/v1651307275/Global/conference_eojsyc.jpg";

const Lists = () => {
  const {
    0: startDate,
    1: setStartDate
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(new Date());
  const {
    0: toggleDate,
    1: setToggleDate
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
  const {
    events,
    news
  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)(state => state.clientEvents);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();

  const lister = index => {
    const dp = [];
    events[index].sessions.map(session => {
      dp.push(session.preacher.imageUrl.url);
    });
    let images = [...new Set(dp)];
    return images.map(image => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
      className: "!ml-[-6px] h-[30px] w-[30px] border-2 border-white  rounded-full relative",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
        src: image,
        className: "object-cover w-full h-full rounded-full",
        layout: "fill",
        blurDataURL: _common_blur__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
        placeholder: "blur",
        alt: "logo"
      })
    }, image));
  };

  const date = (start, end) => {
    if (start === end) {
      return (0,date_fns__WEBPACK_IMPORTED_MODULE_6__.format)(new Date(start), 'MMM, do yyyy');
    } else {
      return `${(0,date_fns__WEBPACK_IMPORTED_MODULE_6__.format)(new Date(start), 'do')} - ${(0,date_fns__WEBPACK_IMPORTED_MODULE_6__.format)(new Date(end), 'do MMM yyyy')}`;
    }
  };

  const truncate = des => {
    if (des.length > 10) {
      return des.substr(0, 257) + "...";
    } else {
      return des;
    }
  };

  const parser = html => {
    const short = truncate(html);
    return (0,html_react_parser__WEBPACK_IMPORTED_MODULE_8__["default"])(short);
  };

  const handleChange = date => {
    setStartDate(date);
    const fDate = new Date(date).toISOString();
    let month = new Date(fDate).getMonth();
    const year = new Date(fDate).getFullYear();
    const nextMonth = new Date(year, month + 1).toISOString();
    router.push(`${router.route}?month=${fDate}&next=${nextMonth}`);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
    className: ` md:mt-10`,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "container md:px-0 lg:px-[2rem]",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
        onClick: () => setToggleDate(!toggleDate),
        className: "max-w-[270px] lg:hidden mx-auto text-center bg-primary-dark text-sm text-white py-2  uppercase mt-5",
        children: "Filter by month"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "grid grid-cols-1 lg:grid-cols-12 lg:gap-20 ",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "lg:col-span-8",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: "flex px-2 items-center mt-7 mb-4 space-x-1",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
              className: "w-3 h-[2.5px] bg-primary-dark"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
              className: "text-base font-medium uppercase",
              children: "Upcoming events"
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
            className: "flex flex-col w-full mt-2 md:mt-5 space-y-5",
            children: events ? events.map((event, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__["default"], {
              href: `/events/${event._id}`,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("a", {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                  className: "flex flex-col w-full md:flex-row items-center shadow-lg hover:scale-105 \r hover:shadow-xl space-y-3 md:space-y-0 md:space-x-3 h-fit bg-gray-50/50 py-3 px-3 cursor-pointer",
                  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                    className: "flex items-center justify-center w-full h-[200px]  md:w-[170px] md:h-[120px]  relative",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                      src: event.imageUrl.url,
                      className: "object-cover w-full h-full ",
                      layout: "fill",
                      blurDataURL: _common_blur__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                      placeholder: "blur",
                      alt: "logo"
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                      className: "hidden md:block absolute font-medium text-center text-[10px] uppercase px-1 py-2 text-white bg-gray-900/70",
                      children: event.type
                    })]
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                    className: "w-full flex flex-col space-y-2 px-3 md:px-0",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                      className: " md:hidden text-xs text-center text-primary-dark uppercase font-medium ",
                      children: event.type
                    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                      className: "flex flex-col-reverse md:flex-row items-center md:justify-between",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                        className: "uppercase font-medium",
                        children: event.title
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                        className: " text-sm mb-2 md:mb-0",
                        children: date(event.startDate, event.endDate)
                      })]
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
                      className: "font-light text-sm text-justify",
                      children: truncate(event.description)
                    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                      className: "flex items-center justify-between",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
                        className: "flex items-center ml-[6px]",
                        children: lister(index)
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                        className: "text-xs rounded-l-full uppercase bg-primary-light text-white py-1 px-3",
                        children: "Learn more"
                      })]
                    })]
                  })]
                })
              })
            }, event._id)) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
              className: "text-center uppercase font-medium",
              children: " No Events To Display"
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: "flex px-2 items-center mt-7 mb-4 space-x-1",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
              className: "w-3 h-[2.5px] bg-primary-dark"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
              className: "text-base font-medium uppercase",
              children: "Latest News"
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
            className: "flex flex-col w-full mt-2 md:mt-5 space-y-5",
            children: news ? news.map((info, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__["default"], {
              href: `/events/news/${info._id}`,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("a", {
                children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                  className: "flex flex-col w-full md:flex-row items-center shadow-lg hover:scale-105 \r hover:shadow-xl space-y-3 md:space-y-0 md:space-x-3 h-fit bg-gray-50/50 py-3 px-3 cursor-pointer",
                  children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                    className: "flex items-center justify-center w-full h-[200px]  md:w-[170px] md:h-[120px]  relative",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                      src: info.imageUrl.url,
                      className: "object-cover w-full h-full ",
                      layout: "fill",
                      blurDataURL: _common_blur__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                      placeholder: "blur",
                      alt: "logo"
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                      className: "hidden md:block absolute font-medium text-center text-[10px] uppercase px-1 py-2 text-white bg-gray-900/70",
                      children: "news"
                    })]
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                    className: "w-full flex flex-col space-y-2 px-3 md:px-0",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                      className: " md:hidden text-xs text-center text-primary-dark uppercase font-medium ",
                      children: "news"
                    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                      className: "flex flex-col-reverse md:flex-row items-center md:justify-between",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                        className: "uppercase font-medium",
                        children: info.title
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                        className: " text-sm mb-2 md:mb-0",
                        children: (0,date_fns__WEBPACK_IMPORTED_MODULE_6__.format)(new Date(info.updatedAt), 'MMM, do yyyy')
                      })]
                    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
                      className: "font-light text-sm text-justify",
                      children: parser(info.body) && parser(info.body)
                    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
                      className: "flex items-center justify-between",
                      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
                        className: "flex items-center ml-[6px]",
                        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("h1", {
                          className: "text-sm italic",
                          children: ["written by ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
                            children: info.author.name
                          })]
                        })
                      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
                        className: "text-xs rounded-l-full uppercase bg-primary-light text-white py-1 px-3",
                        children: "Learn more"
                      })]
                    })]
                  })]
                })
              })
            }, info._id)) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
              className: "text-center uppercase text-lg font-medium",
              children: " No News To Display"
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: ` ${toggleDate ? "" : "hidden lg:block"} lg:!mt-4 lg:col-span-4  w-full order-first lg:order-last flex flex-col justify-center `,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h1", {
            className: "hidden lg:block text-center font-medium uppercase ",
            children: "Filter by month"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
            className: "flex !mt-5 flex-col w-full items-center justify-center",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((react_datepicker__WEBPACK_IMPORTED_MODULE_1___default()), {
              selected: startDate,
              onChange: handleChange,
              dateFormat: "MM/yyyy",
              showMonthYearPicker: true,
              inline: true
            })
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Lists);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const blur = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAAKAAoDASIAAhEBAxEB/8QAFwAAAwEAAAAAAAAAAAAAAAAAAAMGB//EABQBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAdDRKg//xAAYEAADAQEAAAAAAAAAAAAAAAABAgMQE//aAAgBAQABBQJpyA4Jv//EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oACAEDAQE/Aa//xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAgBAgEBPwGP/8QAGxAAAAcBAAAAAAAAAAAAAAAAAAECEDEzkqL/2gAIAQEABj8CrRkRyT//xAAbEAACAQUAAAAAAAAAAAAAAAABEQAQIWGR4f/aAAgBAQABPyFiOpG3UY4V/9oADAMBAAIAAwAAABAD/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAERMf/aAAgBAwEBPxBRh//EABcRAAMBAAAAAAAAAAAAAAAAAAABETH/2gAIAQIBAT8Qdaf/xAAcEAAABgMAAAAAAAAAAAAAAAAAAREhQVEQMWH/2gAIAQEAAT8QmtEUBLbaF13QxzL/2Q==";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blur);

/***/ }),

/***/ 9655:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(29);
/* harmony import */ var babel_plugin_superjson_next_tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1421);
/* harmony import */ var babel_plugin_superjson_next_tools__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_plugin_superjson_next_tools__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7794);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Events_Events__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8095);
/* harmony import */ var _redux_features_client_events__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1630);
/* harmony import */ var _redux_Store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3501);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Events_Events__WEBPACK_IMPORTED_MODULE_4__]);
_components_Events_Events__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




var __jsx = (react__WEBPACK_IMPORTED_MODULE_1___default().createElement);






function EventsPage() {
  return __jsx("div", null, __jsx((next_head__WEBPACK_IMPORTED_MODULE_3___default()), null, __jsx("title", null, "TBC || Events")), __jsx(_components_Events_Events__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, null));
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,babel_plugin_superjson_next_tools__WEBPACK_IMPORTED_MODULE_0__.withSuperJSONPage)(EventsPage));
var getServerSideProps = (0,babel_plugin_superjson_next_tools__WEBPACK_IMPORTED_MODULE_0__.withSuperJSONProps)(_redux_Store__WEBPACK_IMPORTED_MODULE_6__/* .wrapper.getServerSideProps */ .Y.getServerSideProps(function (store) {
  return /*#__PURE__*/function () {
    var _ref2 = (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)( /*#__PURE__*/C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(_ref) {
      var req, query, month, next;
      return C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              req = _ref.req, query = _ref.query;
              month = query.month, next = query.next;
              _context.next = 4;
              return store.dispatch((0,_redux_features_client_events__WEBPACK_IMPORTED_MODULE_5__/* .getClientEvents */ .Iu)({
                req: req,
                month: month,
                next: next
              }));

            case 4:
              _context.next = 6;
              return store.dispatch((0,_redux_features_client_events__WEBPACK_IMPORTED_MODULE_5__/* .getClientNews */ .bo)({
                req: req
              }));

            case 6:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }();
}), []);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7794:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(8319);


/***/ }),

/***/ 5994:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

"use strict";
module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 4146:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 5506:
/***/ ((module) => {

"use strict";
module.exports = require("next-absolute-url");

/***/ }),

/***/ 5648:
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 8319:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 983:
/***/ ((module) => {

"use strict";
module.exports = require("react-datepicker");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2905:
/***/ ((module) => {

"use strict";
module.exports = import("html-react-parser");;

/***/ }),

/***/ 29:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,5675,676,1664,5771,4519,9198,9422,5152,3036,9403,9041,6199,1806,1505,2934,9506,2993,3501], () => (__webpack_exec__(9655)));
module.exports = __webpack_exports__;

})();