"use strict";
(() => {
var exports = {};
exports.id = 660;
exports.ids = [660];
exports.modules = {

/***/ 887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9499);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2777);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2262);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5959);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2179);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7247);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7794);
/* harmony import */ var C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6859);








var __jsx = (react__WEBPACK_IMPORTED_MODULE_1___default().createElement);


function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)(this, result);
  };
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}



var MyDocument = /*#__PURE__*/function (_Document) {
  (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_inherits__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(MyDocument, _Document);

  var _super = _createSuper(MyDocument);

  function MyDocument() {
    (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_classCallCheck__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(this, MyDocument);

    return _super.apply(this, arguments);
  }

  (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_createClass__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(MyDocument, [{
    key: "render",
    value: function render() {
      return __jsx(next_document__WEBPACK_IMPORTED_MODULE_5__.Html, {
        className: "scroll-smooth !scroll-pt-[60px]"
      }, __jsx(next_document__WEBPACK_IMPORTED_MODULE_5__.Head, null, __jsx("link", {
        rel: "icon",
        href: "/logo.png"
      })), __jsx("body", null, __jsx(next_document__WEBPACK_IMPORTED_MODULE_5__.Main, null), __jsx(next_document__WEBPACK_IMPORTED_MODULE_5__.NextScript, null)));
    }
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = (0,C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)( /*#__PURE__*/C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(ctx) {
        var initialProps;
        return C_Users_user_Documents_PROJECTS_tbc_node_modules_next_dist_compiled_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return next_document__WEBPACK_IMPORTED_MODULE_5__["default"].getInitialProps(ctx);

              case 2:
                initialProps = _context.sent;
                return _context.abrupt("return", _objectSpread({}, initialProps));

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      function getInitialProps(_x) {
        return _getInitialProps.apply(this, arguments);
      }

      return getInitialProps;
    }()
  }]);

  return MyDocument;
}(next_document__WEBPACK_IMPORTED_MODULE_5__["default"]);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyDocument);

/***/ }),

/***/ 6642:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@babel/runtime/helpers/typeof");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 4140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,4191], () => (__webpack_exec__(887)));
module.exports = __webpack_exports__;

})();