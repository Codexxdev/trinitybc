"use strict";
(() => {
var exports = {};
exports.id = 1015;
exports.ids = [1015];
exports.modules = {

/***/ 7449:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* reexport */ external_next_s3_upload_namespaceObject.APIRoute)
});

;// CONCATENATED MODULE: external "next-s3-upload"
const external_next_s3_upload_namespaceObject = require("next-s3-upload");
;// CONCATENATED MODULE: ./pages/api/s3-upload.js


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7449));
module.exports = __webpack_exports__;

})();