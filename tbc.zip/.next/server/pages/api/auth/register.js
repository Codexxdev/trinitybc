"use strict";
(() => {
var exports = {};
exports.id = 7007;
exports.ids = [7007];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 2776:
/***/ ((module) => {

module.exports = require("express-async-handler");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 1564:
/***/ ((module) => {

module.exports = require("validator");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ register),
/* harmony export */   "a": () => (/* binding */ currentUser)
/* harmony export */ });
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4871);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_1__);


const register = express_async_handler__WEBPACK_IMPORTED_MODULE_1___default()(async (req, res) => {
  const {
    name,
    email,
    password
  } = req.body;
  const user = await _models_User__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create({
    name,
    email,
    password
  });
  res.status(200).json({
    success: true,
    message: "registered User"
  });
});
const currentUser = express_async_handler__WEBPACK_IMPORTED_MODULE_1___default()(async (req, res) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: "Unauthorized"
    });
  }

  const user = await _models_User__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.user._id);
  res.status(200).json({
    success: 'true',
    user
  });
});


/***/ }),

/***/ 21:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
class ErrorHandler extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode == statusCode;
    Error.captureStackTrace(this, this.constructor);
  }

}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorHandler);

/***/ }),

/***/ 6602:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _utils_dbConnect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(771);
/* harmony import */ var _controllers_authController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(461);
/* harmony import */ var _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(21);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




var handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])({
  onError: _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
});
(0,_utils_dbConnect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
handler.post(_controllers_authController__WEBPACK_IMPORTED_MODULE_2__/* .register */ .z);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);


const dbConnect = () => {
  if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.readyState) >= 1) {
    return;
  }

  mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI).then(con => {
    console.log('conncted to database');
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4871], () => (__webpack_exec__(6602)));
module.exports = __webpack_exports__;

})();