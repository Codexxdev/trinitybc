"use strict";
(() => {
var exports = {};
exports.id = 3748;
exports.ids = [3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 1564:
/***/ ((module) => {

module.exports = require("validator");

/***/ }),

/***/ 287:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__(2496);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(7641);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7424);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/credentials"
const credentials_namespaceObject = require("next-auth/providers/credentials");
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_namespaceObject);
// EXTERNAL MODULE: external "bcryptjs"
var external_bcryptjs_ = __webpack_require__(8432);
var external_bcryptjs_default = /*#__PURE__*/__webpack_require__.n(external_bcryptjs_);
// EXTERNAL MODULE: ./models/User.js
var User = __webpack_require__(4871);
// EXTERNAL MODULE: ./utils/dbConnect.js
var dbConnect = __webpack_require__(771);
;// CONCATENATED MODULE: external "@next-auth/mongodb-adapter"
const mongodb_adapter_namespaceObject = require("@next-auth/mongodb-adapter");
;// CONCATENATED MODULE: external "mongodb"
const external_mongodb_namespaceObject = require("mongodb");
;// CONCATENATED MODULE: ./lib/mongodb.js
// This approach is taken from https://github.com/vercel/next.js/tree/canary/examples/with-mongodb

const uri = process.env.MONGODB_URI;
const options = {
  useUnifiedTopology: true,
  useNewUrlParser: true
};
let client;
let clientPromise;

if (!process.env.MONGODB_URI) {
  throw new Error("Please add your Mongo URI to .env.local");
}

if (false) {} else {
  // In production mode, it's best to not use a global variable.
  client = new external_mongodb_namespaceObject.MongoClient(uri, options);
  clientPromise = client.connect();
} // Export a module-scoped MongoClient promise. By doing this in a
// separate module, the client can be shared across functions.


/* harmony default export */ const mongodb = (clientPromise);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].js



var _NextAuth;









/* harmony default export */ const _nextauth_ = (external_next_auth_default()((_NextAuth = {
  session: {
    jwt: true
  },
  providers: [credentials_default()({
    authorize: function authorize(credentials) {
      return (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee() {
        var email, password, user, isPasswordMatch;
        return regenerator_default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                (0,dbConnect/* default */.Z)();
                email = credentials.email, password = credentials.password; // check if email and password is entered

                if (!(!email || !password)) {
                  _context.next = 4;
                  break;
                }

                throw new Error('Please enter email and password');

              case 4:
                _context.next = 6;
                return User/* default.findOne */.Z.findOne({
                  email: email
                });

              case 6:
                user = _context.sent;

                if (user) {
                  _context.next = 9;
                  break;
                }

                throw new Error('Invalid email or Password');

              case 9:
                _context.next = 11;
                return external_bcryptjs_default().compare(password, user.password);

              case 11:
                isPasswordMatch = _context.sent;

                if (isPasswordMatch) {
                  _context.next = 14;
                  break;
                }

                throw new Error('Invalid email or Password');

              case 14:
                return _context.abrupt("return", Promise.resolve(user));

              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    }
  })],
  secret: "l9zh0+Uldc9W/IHMY42P/rDFIGkMjfj0nQDg1EygFDc=",
  adapter: (0,mongodb_adapter_namespaceObject.MongoDBAdapter)(mongodb),
  pages: {
    signIn: "/"
  }
}, (0,defineProperty/* default */.Z)(_NextAuth, "session", {
  strategy: "jwt"
}), (0,defineProperty/* default */.Z)(_NextAuth, "callbacks", {
  jwt: function jwt(_ref) {
    return (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee2() {
      var token, user;
      return regenerator_default().wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              token = _ref.token, user = _ref.user;
              user && (token.user = user);
              return _context2.abrupt("return", token);

            case 3:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }))();
  },
  session: function session(_ref2) {
    return (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee3() {
      var session, token;
      return regenerator_default().wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              session = _ref2.session, token = _ref2.token;
              session.user = token.user;
              return _context3.abrupt("return", session);

            case 3:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }))();
  }
}), _NextAuth)));

/***/ }),

/***/ 771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);


const dbConnect = () => {
  if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.readyState) >= 1) {
    return;
  }

  mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI).then(con => {
    console.log('conncted to database');
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3527,4871], () => (__webpack_exec__(287)));
module.exports = __webpack_exports__;

})();