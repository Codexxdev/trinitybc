"use strict";
(() => {
var exports = {};
exports.id = 5198;
exports.ids = [5198];
exports.modules = {

/***/ 2776:
/***/ ((module) => {

module.exports = require("express-async-handler");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 8547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ searchAllResources)
/* harmony export */ });
/* unused harmony export getLatestResources */
/* harmony import */ var _models_Sermon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7173);
/* harmony import */ var _models_BibleStudy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4170);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _models_Ministers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3373);
/* harmony import */ var _models_Series__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6161);
/* harmony import */ var _models_Conference__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(840);





 // get client conference detail
// get => /api/client/conference/:id

const getLatestResources = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const all = []; // sermons

  const sermons = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort({
    date: -1
  }).populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  }).limit(5);
  all.push(...sermons);
  const bibleStudies = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find({}).sort({
    date: -1
  }).populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  }).limit(5);
  all.push(...bibleStudies);
  const conferences = await _models_Conference__WEBPACK_IMPORTED_MODULE_5__/* ["default"].find */ .Z.find({}).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  }).limit(5);
  conferences.map(conference => {
    const sermons = conference.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        preacher: sermon.preacher,
        conferenceId: conference._id,
        imageUrl: sermon.imageUrl,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    all.push(...sermons);
  });
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_4__/* ["default"].find */ .Z.find({}).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  }).limit(5);
  series.map(serie => {
    const sermons = serie.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        preacher: sermon.preacher,
        seriesId: serie._id,
        imageUrl: sermon.imageUrl,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    all.push(...sermons);
  });
  all.sort((a, b) => new Date(b.date) - new Date(a.date));
  const latest = all.slice(0, 6);
  res.status(200).json({
    success: "true",
    latest
  });
}); // get client conference detail
// get => /api/client/conference/:id

const searchAllResources = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    keyword
  } = req.query;
  const page = Number(req.query.page) || 1;
  const query = {
    $or: [{
      title: {
        $regex: keyword,
        $options: "i"
      }
    }, {
      topic: {
        $regex: keyword,
        $options: "i"
      }
    }, {
      description: {
        $regex: keyword,
        $options: "i"
      }
    }, {
      book: {
        $regex: keyword,
        $options: "i"
      }
    }]
  };
  const nestedQuery = {
    "sermons": {
      $elemMatch: {
        $or: [{
          title: {
            $regex: keyword,
            $options: "i"
          }
        }, {
          topic: {
            $regex: keyword,
            $options: "i"
          }
        }, {
          description: {
            $regex: keyword,
            $options: "i"
          }
        }, {
          book: {
            $regex: keyword,
            $options: "i"
          }
        }]
      }
    }
  };
  const all = []; // sermons

  const sermons = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find(query).sort('-date').populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  });

  if (sermons.length > 0) {
    all.push(...sermons);
  } // BibleStudies


  const bibleStudies = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_1__/* ["default"].find */ .Z.find(query).sort('-date').populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  });

  if (bibleStudies.length > 0) {
    all.push(...bibleStudies);
  }

  const conferences = await _models_Conference__WEBPACK_IMPORTED_MODULE_5__/* ["default"].find */ .Z.find(nestedQuery).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  });
  conferences.map(conference => {
    const sermons = conference.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        topic: sermon.topic,
        book: sermon.book,
        chapter: sermon.chapter,
        verse: sermon.verse,
        preacher: sermon.preacher,
        conferenceId: conference._id,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    sermons.map(sermon => {
      if (sermon.title.includes(keyword.toLowerCase()) || sermon.topic.includes(keyword.toLowerCase()) || sermon.description.includes(keyword.toLowerCase()) || sermon.book.includes(keyword.toLowerCase())) {
        all.push(sermon);
      }
    });
  });
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_4__/* ["default"].find */ .Z.find(nestedQuery).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
  });
  series.map(serie => {
    const sermons = serie.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        topic: sermon.topic,
        book: sermon.book,
        chapter: sermon.chapter,
        verse: sermon.verse,
        preacher: sermon.preacher,
        seriesId: serie._id,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    sermons.map(sermon => {
      if (sermon.title.includes(keyword.toLowerCase()) || sermon.topic.includes(keyword.toLowerCase()) || sermon.description.includes(keyword.toLowerCase()) || sermon.book.includes(keyword.toLowerCase())) {
        all.push(sermon);
      }
    });
  });
  all.sort((a, b) => new Date(b.date) - new Date(a.date));
  const resPerPage = 10;
  const totalItems = all.length;
  const start = (page - 1) * resPerPage;
  const end = page * resPerPage;
  res.status(200).json({
    success: "true",
    all: all.slice(start, end),
    totalItems,
    resPerPage
  });
});


/***/ }),

/***/ 4170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const bibleStudySchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  title: {
    type: String,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  preacher: {
    type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.ObjectId),
    required: true,
    ref: 'minister'
  },
  book: {
    type: String,
    required: true
  },
  chapter: {
    type: String,
    required: true
  },
  verse: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  audioUrl: {
    type: String,
    required: true
  },
  youtubeLink: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.BibleStudy) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('BibleStudy', bibleStudySchema));

/***/ }),

/***/ 7173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const sermonSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  title: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  preacher: {
    type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.ObjectId),
    required: true,
    ref: 'minister'
  },
  book: {
    type: String,
    required: true
  },
  chapter: {
    type: String,
    required: true
  },
  verse: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  audioUrl: {
    type: String,
    required: true
  },
  youtubeLink: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Sermon) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Sermon', sermonSchema));

/***/ }),

/***/ 4948:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _controllers_allController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8547);
/* harmony import */ var _utils_dbConnect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(771);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



var handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
(0,_utils_dbConnect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
handler.get(_controllers_allController__WEBPACK_IMPORTED_MODULE_1__/* .searchAllResources */ .K);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);


const dbConnect = () => {
  if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.readyState) >= 1) {
    return;
  }

  mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI).then(con => {
    console.log('conncted to database');
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9957,6161], () => (__webpack_exec__(4948)));
module.exports = __webpack_exports__;

})();