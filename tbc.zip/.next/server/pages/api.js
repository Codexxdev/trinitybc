"use strict";
(() => {
var exports = {};
exports.id = 4237;
exports.ids = [4237];
exports.modules = {

/***/ 6796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "D": () => (/* binding */ getLatestResources)
});

// UNUSED EXPORTS: searchAllResources

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/Sermon.js

const sermonSchema = new (external_mongoose_default()).Schema({
  title: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  preacher: {
    type: (external_mongoose_default()).Schema.ObjectId,
    required: true,
    ref: 'minister'
  },
  book: {
    type: String,
    required: true
  },
  chapter: {
    type: String,
    required: true
  },
  verse: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  audioUrl: {
    type: String,
    required: true
  },
  youtubeLink: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const Sermon = ((external_mongoose_default()).models.Sermon || external_mongoose_default().model('Sermon', sermonSchema));
;// CONCATENATED MODULE: ./models/BibleStudy.js

const bibleStudySchema = new (external_mongoose_default()).Schema({
  title: {
    type: String,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  preacher: {
    type: (external_mongoose_default()).Schema.ObjectId,
    required: true,
    ref: 'minister'
  },
  book: {
    type: String,
    required: true
  },
  chapter: {
    type: String,
    required: true
  },
  verse: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  audioUrl: {
    type: String,
    required: true
  },
  youtubeLink: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const BibleStudy = ((external_mongoose_default()).models.BibleStudy || external_mongoose_default().model('BibleStudy', bibleStudySchema));
;// CONCATENATED MODULE: external "express-async-handler"
const external_express_async_handler_namespaceObject = require("express-async-handler");
var external_express_async_handler_default = /*#__PURE__*/__webpack_require__.n(external_express_async_handler_namespaceObject);
;// CONCATENATED MODULE: ./models/Ministers.js

const ministerSchema = new (external_mongoose_default()).Schema({
  name: {
    type: String,
    required: [true, 'Please enter your name']
  },
  role: {
    type: String,
    default: 'minister'
  },
  about: {
    type: String,
    required: [true, "Please enter minister's about"]
  },
  imageUrl: {
    public_id: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const Ministers = ((external_mongoose_default()).models.Minister || external_mongoose_default().model('Minister', ministerSchema));
;// CONCATENATED MODULE: ./models/Series.js

const seriesSchema = new (external_mongoose_default()).Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  sermons: [{
    title: {
      type: String,
      required: true
    },
    category: {
      type: String,
      required: true
    },
    topic: {
      type: String,
      required: true
    },
    preacher: {
      type: (external_mongoose_default()).Schema.ObjectId,
      required: true,
      ref: 'minister'
    },
    book: {
      type: String,
      required: true
    },
    chapter: {
      type: String,
      required: true
    },
    verse: {
      type: String,
      required: true
    },
    date: {
      type: Date,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    imageUrl: {
      public_id: {
        type: String
      },
      url: {
        type: String
      }
    },
    audioUrl: {
      type: String,
      required: true
    },
    youtubeLink: {
      type: String
    }
  }]
});
/* harmony default export */ const Series = ((external_mongoose_default()).models.Series || external_mongoose_default().model('Series', seriesSchema));
;// CONCATENATED MODULE: ./models/Conference.js

const conferenceSchema = new (external_mongoose_default()).Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  sermons: [{
    title: {
      type: String,
      required: true
    },
    category: {
      type: String,
      required: true
    },
    topic: {
      type: String,
      required: true
    },
    preacher: {
      type: (external_mongoose_default()).Schema.ObjectId,
      required: true,
      ref: 'minister'
    },
    book: {
      type: String,
      required: true
    },
    chapter: {
      type: String,
      required: true
    },
    verse: {
      type: String,
      required: true
    },
    date: {
      type: Date,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    imageUrl: {
      public_id: {
        type: String
      },
      url: {
        type: String
      }
    },
    audioUrl: {
      type: String,
      required: true
    },
    youtubeLink: {
      type: String
    }
  }]
});
/* harmony default export */ const Conference = ((external_mongoose_default()).models.Conference || external_mongoose_default().model('Conference', conferenceSchema));
;// CONCATENATED MODULE: ./controllers/allController.js





 // get client conference detail
// get => /api/client/conference/:id

const getLatestResources = external_express_async_handler_default()(async (req, res, next) => {
  const all = []; // sermons

  const sermons = await Sermon.find({}).sort({
    date: -1
  }).populate({
    path: 'preacher',
    select: "name imageUrl",
    model: Ministers
  }).limit(5);
  all.push(...sermons);
  const bibleStudies = await BibleStudy.find({}).sort({
    date: -1
  }).populate({
    path: 'preacher',
    select: "name imageUrl",
    model: Ministers
  }).limit(5);
  all.push(...bibleStudies);
  const conferences = await Conference.find({}).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: Ministers
  }).limit(5);
  conferences.map(conference => {
    const sermons = conference.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        preacher: sermon.preacher,
        conferenceId: conference._id,
        imageUrl: sermon.imageUrl,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    all.push(...sermons);
  });
  const series = await Series.find({}).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: Ministers
  }).limit(5);
  series.map(serie => {
    const sermons = serie.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        preacher: sermon.preacher,
        seriesId: serie._id,
        imageUrl: sermon.imageUrl,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    all.push(...sermons);
  });
  all.sort((a, b) => new Date(b.date) - new Date(a.date));
  const latest = all.slice(0, 6);
  res.status(200).json({
    success: "true",
    latest
  });
}); // get client conference detail
// get => /api/client/conference/:id

const searchAllResources = external_express_async_handler_default()(async (req, res, next) => {
  const {
    keyword
  } = req.query;
  const page = Number(req.query.page) || 1;
  const query = {
    $or: [{
      title: {
        $regex: keyword,
        $options: "i"
      }
    }, {
      topic: {
        $regex: keyword,
        $options: "i"
      }
    }, {
      description: {
        $regex: keyword,
        $options: "i"
      }
    }, {
      book: {
        $regex: keyword,
        $options: "i"
      }
    }]
  };
  const nestedQuery = {
    "sermons": {
      $elemMatch: {
        $or: [{
          title: {
            $regex: keyword,
            $options: "i"
          }
        }, {
          topic: {
            $regex: keyword,
            $options: "i"
          }
        }, {
          description: {
            $regex: keyword,
            $options: "i"
          }
        }, {
          book: {
            $regex: keyword,
            $options: "i"
          }
        }]
      }
    }
  };
  const all = []; // sermons

  const sermons = await Sermon.find(query).sort('-date').populate({
    path: 'preacher',
    select: "name imageUrl",
    model: Ministers
  });

  if (sermons.length > 0) {
    all.push(...sermons);
  } // BibleStudies


  const bibleStudies = await BibleStudy.find(query).sort('-date').populate({
    path: 'preacher',
    select: "name imageUrl",
    model: Ministers
  });

  if (bibleStudies.length > 0) {
    all.push(...bibleStudies);
  }

  const conferences = await Conference.find(nestedQuery).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: Ministers
  });
  conferences.map(conference => {
    const sermons = conference.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        topic: sermon.topic,
        book: sermon.book,
        chapter: sermon.chapter,
        verse: sermon.verse,
        preacher: sermon.preacher,
        conferenceId: conference._id,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    sermons.map(sermon => {
      if (sermon.title.includes(keyword.toLowerCase()) || sermon.topic.includes(keyword.toLowerCase()) || sermon.description.includes(keyword.toLowerCase()) || sermon.book.includes(keyword.toLowerCase())) {
        all.push(sermon);
      }
    });
  });
  const series = await Series.find(nestedQuery).sort("-startDate").populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: Ministers
  });
  series.map(serie => {
    const sermons = serie.sermons.map((sermon, index) => {
      return {
        title: sermon.title,
        topic: sermon.topic,
        book: sermon.book,
        chapter: sermon.chapter,
        verse: sermon.verse,
        preacher: sermon.preacher,
        seriesId: serie._id,
        date: sermon.date,
        description: sermon.description,
        _id: sermon._id,
        index
      };
    });
    sermons.map(sermon => {
      if (sermon.title.includes(keyword.toLowerCase()) || sermon.topic.includes(keyword.toLowerCase()) || sermon.description.includes(keyword.toLowerCase()) || sermon.book.includes(keyword.toLowerCase())) {
        all.push(sermon);
      }
    });
  });
  all.sort((a, b) => new Date(b.date) - new Date(a.date));
  const resPerPage = 10;
  const totalItems = all.length;
  const start = (page - 1) * resPerPage;
  const end = page * resPerPage;
  res.status(200).json({
    success: "true",
    all: all.slice(start, end),
    totalItems,
    resPerPage
  });
});


/***/ }),

/***/ 6367:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _controllers_allController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6796);
/* harmony import */ var _utils_dbConnect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6622);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



var handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
(0,_utils_dbConnect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
handler.get(_controllers_allController__WEBPACK_IMPORTED_MODULE_1__/* .getLatestResources */ .D);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6622:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);


const dbConnect = () => {
  if ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.readyState) >= 1) {
    return;
  }

  mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI).then(con => {
    console.log('conncted to database');
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6367));
module.exports = __webpack_exports__;

})();