(() => {
var exports = {};
exports.id = 7616;
exports.ids = [7616];
exports.modules = {

/***/ 439:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ signup),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(29);
// EXTERNAL MODULE: external "babel-plugin-superjson-next/tools"
var tools_ = __webpack_require__(1421);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7794);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/common/ButtonLoader.js
var ButtonLoader = __webpack_require__(1947);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./redux/features/createUser.js
var createUser = __webpack_require__(2993);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/auth/SignUp.js











const SignUp = () => {
  const {
    0: email,
    1: setEmail
  } = (0,external_react_.useState)('');
  const {
    0: name,
    1: setName
  } = (0,external_react_.useState)('');
  const {
    0: password,
    1: setPassword
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const router = (0,router_.useRouter)();
  const dispatch = (0,external_react_redux_.useDispatch)();

  const handleSubmit = async e => {
    e.preventDefault();

    if (email && email.includes('@') && email.includes('.') && name && password) {
      setLoading(true);
      dispatch((0,createUser/* postCreateUser */.J)({
        name,
        email,
        password
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success('User created successfully');
          router.push('/signin');
        } else {
          setLoading(false);
          external_react_toastify_.toast.error('Email already Exists');
        }
      });
    } else {
      external_react_toastify_.toast.info('Please fill all the fields correctly');
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex justify-center items-center w-full bg-gray-800 h-screen px-2",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      onSubmit: handleSubmit,
      className: "relative max-w-screen-sm mx-auto rounded-xl flex flex-col space-y-5 w-full bg-white !mt-10 h-[450px] py-3 px-1 md:p-5 ",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase font-medium text-center",
        children: "Sign Up"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-2 px-1 md:px-5 !mt-10",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "name",
          className: "ml-2 text-sm uppercase",
          children: "Name"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "name",
          name: "name",
          className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
          required: true,
          value: name,
          onChange: e => {
            setName(e.target.value);
          }
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-2 px-1 md:px-5",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "title",
          className: "ml-2 text-sm uppercase",
          children: "Email"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "title",
          name: "title",
          className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
          required: true,
          value: email,
          onChange: e => {
            setEmail(e.target.value);
          }
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-2 px-1 md:px-5",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "password",
          className: "ml-2 text-sm uppercase",
          children: "Password"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "password",
          name: "password",
          className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
          required: true,
          value: password,
          onChange: e => {
            setPassword(e.target.value);
          }
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "absolute bottom-4 left-0 right-0 justify-center flex w-full items-center space-x-5 ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: handleSubmit,
          className: "uppercase text-sm  text-white bg-primary-light px-5 rounded-full py-1",
          children: loading ? /*#__PURE__*/jsx_runtime_.jsx(ButtonLoader/* default */.Z, {}) : "SIGN Up"
        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-sm uppercase cursor-pointer",
          children: "Or signin"
        })]
      })]
    })
  });
};

/* harmony default export */ const auth_SignUp = (SignUp);
;// CONCATENATED MODULE: ./pages/signup.js




var __jsx = (external_react_default()).createElement;




function SignInPage() {
  return __jsx(auth_SignUp, null);
}

/* harmony default export */ const signup = ((0,tools_.withSuperJSONPage)(SignInPage));
var getServerSideProps = (0,tools_.withSuperJSONProps)( /*#__PURE__*/function () {
  var _getServerSideProps = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(context) {
    var req, session;
    return regenerator_default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            req = context.req;
            _context.next = 3;
            return (0,react_.getSession)({
              req: req
            });

          case 3:
            session = _context.sent;

            if (!session) {
              _context.next = 6;
              break;
            }

            return _context.abrupt("return", {
              redirect: {
                destination: '/',
                permanent: false
              }
            });

          case 6:
            return _context.abrupt("return", {
              props: {}
            });

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  function getServerSideProps(_x) {
    return _getServerSideProps.apply(this, arguments);
  }

  return getServerSideProps;
}(), []);

/***/ }),

/***/ 7794:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(8319);


/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

"use strict";
module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 8319:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

"use strict";
module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 1187:
/***/ ((module) => {

"use strict";
module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 29:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,676,1664,1947,2993], () => (__webpack_exec__(439)));
module.exports = __webpack_exports__;

})();