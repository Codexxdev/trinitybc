"use strict";
(() => {
var exports = {};
exports.id = 4977;
exports.ids = [4977];
exports.modules = {

/***/ 674:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ upcoming_new),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(29);
// EXTERNAL MODULE: external "babel-plugin-superjson-next/tools"
var tools_ = __webpack_require__(1421);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7794);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Dashboard/DashboardLayout.js + 4 modules
var DashboardLayout = __webpack_require__(1817);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(4146);
// EXTERNAL MODULE: external "@mui/icons-material/Edit"
var Edit_ = __webpack_require__(6902);
var Edit_default = /*#__PURE__*/__webpack_require__.n(Edit_);
// EXTERNAL MODULE: external "@mui/icons-material/Delete"
var Delete_ = __webpack_require__(3188);
var Delete_default = /*#__PURE__*/__webpack_require__.n(Delete_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-datepicker"
var external_react_datepicker_ = __webpack_require__(983);
var external_react_datepicker_default = /*#__PURE__*/__webpack_require__.n(external_react_datepicker_);
// EXTERNAL MODULE: ./node_modules/react-datepicker/dist/react-datepicker.css
var react_datepicker = __webpack_require__(5994);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/features/menu.js
var menu = __webpack_require__(5771);
// EXTERNAL MODULE: ./redux/features/addEvent.js
var addEvent = __webpack_require__(1505);
// EXTERNAL MODULE: ./components/common/ImageUploader.js
var ImageUploader = __webpack_require__(6688);
// EXTERNAL MODULE: ./components/common/ButtonLoader.js
var ButtonLoader = __webpack_require__(1947);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Dashboard/events/upcoming/New.js
















const New = () => {
  const {
    0: imagePreview,
    1: setImagePreview
  } = (0,external_react_.useState)('');
  const {
    0: type,
    1: setType
  } = (0,external_react_.useState)('');
  const {
    0: title,
    1: setTitle
  } = (0,external_react_.useState)('');
  const {
    0: description,
    1: setDescription
  } = (0,external_react_.useState)('');
  const {
    0: imageUrl,
    1: setImageUrl
  } = (0,external_react_.useState)();
  const {
    0: startDate,
    1: setStartDate
  } = (0,external_react_.useState)();
  const {
    0: endDate,
    1: setEndDate
  } = (0,external_react_.useState)();
  const {
    0: day,
    1: setDay
  } = (0,external_react_.useState)('');
  const {
    0: days,
    1: setDays
  } = (0,external_react_.useState)(0);
  const {
    0: arr,
    1: setArr
  } = (0,external_react_.useState)(['select day']);
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const dispatch = (0,external_react_redux_.useDispatch)();
  const {
    sessions
  } = (0,external_react_redux_.useSelector)(state => state.menu);
  const {
    ministers
  } = (0,external_react_redux_.useSelector)(state => state.ministers);
  (0,external_react_.useEffect)(() => {
    for (let i = 1; i <= days; i++) {
      setArr(prev => [...prev, `Day ${i}`]);
    }

    return () => {
      dispatch((0,menu/* clearSessions */.VU)());
    };
  }, [days]);
  const router = (0,router_.useRouter)();

  const date = (start, end) => {
    return `${(0,external_date_fns_.format)(new Date(start), 'h:mm a')} - ${(0,external_date_fns_.format)(new Date(end), 'h:mm a')}`;
  };

  const handleSubmit = e => {
    e.preventDefault();
    setLoading(true);

    if (sessions && imageUrl && title && type && description && startDate && endDate) {
      dispatch((0,addEvent/* postCreateEvent */.H)({
        title,
        type,
        description,
        startDate,
        endDate,
        imageUrl,
        sessions
      })).then(res => {
        if (!res.error) {
          dispatch((0,menu/* clearSessions */.VU)());
          setLoading(false);
          external_react_toastify_.toast.success('Event created successfully');
          router.back();
        } else {
          console.log(res.error);
          setLoading(false);
        }
      });
    } else {
      external_react_toastify_.toast.info('Please fill all the fields');
      setLoading(false);
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex  w-full min-h-screen  my-2  mx-2 rounded-2xl bg-white",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full flex flex-col space-y-7 h-fit items-center  pt-5 px-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase text-lg text-primary-dark font-medium",
        children: "Add upcoming event"
      }), /*#__PURE__*/jsx_runtime_.jsx("form", {
        className: "w-full",
        autoComplete: "off",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full h-full grid grid-cols-12 gap-5",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "col-span-7 space-y-5 w-full text-gray-700 ",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "grid grid-cols-12  w-full items-center gap-2",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "col-span-5 space-y-2",
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  htmlFor: "title",
                  className: "ml-2 text-sm uppercase",
                  children: "Event Type"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "title",
                  name: "title",
                  className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                  required: true,
                  value: type,
                  onChange: e => {
                    setType(e.target.value);
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "col-span-7 space-y-2",
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  htmlFor: "title",
                  className: "ml-2 text-sm uppercase",
                  children: "Event title"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "title",
                  name: "title",
                  className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                  required: true,
                  value: title,
                  onChange: e => {
                    setTitle(e.target.value);
                  }
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "description",
                className: "ml-2 text-sm uppercase",
                children: "event description"
              }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                rows: "10",
                value: description,
                onChange: e => {
                  setDescription(e.target.value);
                }
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "col-span-5 space-y-5 w-full text-gray-700 ",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "space-y-2 w-full",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "name",
                className: "ml-2 text-sm uppercase",
                children: "Event Date"
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                selectsRange: true,
                selected: startDate,
                startDate: startDate,
                endDate: endDate,
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                onChange: dates => {
                  const [startDate, endDate] = dates;
                  setStartDate(startDate);
                  setEndDate(endDate);
                  setArr(['select day']);
                  setDays(0);

                  if (startDate && endDate) {
                    const diff = endDate.getTime() - startDate.getTime();
                    const days = Math.round(diff / (1000 * 60 * 60 * 24));
                    setDays(days + 1);
                  }
                },
                isClearable: true
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx(ImageUploader/* default */.Z, {
              imagePreview: imagePreview,
              setImagePreview: setImagePreview,
              setImageUrl: setImageUrl,
              imageUrl: imageUrl,
              height: "h-44"
            })]
          })]
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "w-full flex items-center space-x-4 ",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
          className: "text-sm uppercase",
          children: ["Number of Days: ", /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "font-medium",
            children: days
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("select", {
          type: "text",
          name: "day",
          className: "capitalize text-gray-500 !px-3 py-1 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
          value: day,
          onChange: e => {
            setDay(e.target.value);
          },
          children: arr.map(day => /*#__PURE__*/jsx_runtime_.jsx("option", {
            className: "capitalize",
            value: day,
            children: day
          }, day))
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          disabled: day === 'select day' || day === '',
          onClick: () => {
            dispatch((0,menu/* setModalState */.hr)(true));
            dispatch((0,menu/* setModalData */._6)(day));
          },
          className: "disabled:bg-gray-500 uppercase text-xs rounded bg-primary-light text-white  py-1 px-3",
          children: "Add schedule"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "w-full flex flex-col space-y-7 items-center justify-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "uppercase text-lg font-medium",
          children: `Event Scheldule`
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("table", {
          className: "w-full max-w-full table-auto border-collapse ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("thead", {
            className: "bg-gray-800 text-gray-200 ",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
              className: "",
              children: [/*#__PURE__*/jsx_runtime_.jsx("th", {
                scope: "col",
                className: "text-sm font-medium uppercase px-4 py-4 text-left",
                children: "#"
              }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                scope: "col",
                className: "text-sm font-medium uppercase px-3 py-4 text-left",
                children: "Session"
              }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                scope: "col",
                className: "text-sm font-medium uppercase px-3 py-4 text-left",
                children: "Topic"
              }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                scope: "col",
                className: "text-sm font-medium uppercase px-3 py-4 text-left",
                children: "Preacher"
              }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                scope: "col",
                className: "text-sm font-medium uppercase px-3 py-4 text-left",
                children: "Day"
              }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                scope: "col",
                className: "text-sm font-medium uppercase px-3 py-4 text-left",
                children: "Actions"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("tbody", {
            className: "bg-white  ",
            children: sessions && sessions.map((item, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
              className: ` transition duration-300 ease-in-out border-b border-b-gray-200`,
              children: [/*#__PURE__*/jsx_runtime_.jsx("td", {
                className: "px-4 py-4 whitespace-nowrap text-sm  ",
                children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
                  children: index + 1
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                className: "text-sm  px-3 py-4 whitespace-nowrap ",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "flex flex-col space-y-2",
                  children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
                    children: date(item.startTime, item.endTime)
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                className: "text-sm  px-3 py-4 whitespace-nowrap ",
                children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
                  className: "capitalize",
                  children: item.topic
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                className: "text-sm  px-3 py-4 whitespace-nowrap ",
                children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
                  children: ministers.map(minister => {
                    if (minister._id === item.preacher) {
                      return minister.name;
                    }
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                className: "text-sm  px-3 py-4 whitespace-nowrap ",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "flex flex-col space-y-2",
                  children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
                    children: item.day
                  })
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                className: "text-sm  font-light px-3 py-4 whitespace-nowrap",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "flex space-x-2 items-center",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                    onClick: () => {
                      dispatch((0,menu/* setModalState */.hr)(true));
                      dispatch((0,menu/* setModalData */._6)(item));
                    },
                    className: "flex justify-center items-center cursor-pointer hover:bg-primary-dark bg-primary-dark/90 w-7 h-7 rounded-full",
                    children: /*#__PURE__*/jsx_runtime_.jsx((Edit_default()), {
                      className: "!text-white !text-base"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "flex justify-center items-center cursor-pointer hover:bg-red-600 bg-red-600/90 w-7 h-7 rounded-full",
                    children: /*#__PURE__*/jsx_runtime_.jsx((Delete_default()), {
                      className: "!text-white !text-base"
                    })
                  })]
                })
              })]
            }, item.id))
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between w-full !mb-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          onClick: () => {
            router.back();
          },
          className: "cursor-pointer text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-red-700",
          children: "cancel"
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: handleSubmit,
          className: "text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-blue-600",
          children: loading ? /*#__PURE__*/jsx_runtime_.jsx(ButtonLoader/* default */.Z, {}) : 'create'
        })]
      })]
    })
  });
};

/* harmony default export */ const upcoming_New = (New);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/admin/events/upcoming/new.js




var __jsx = (external_react_default()).createElement;






function AdminDashboard() {
  return __jsx("div", null, __jsx((head_default()), null, __jsx("title", null, "TBC || Admin Dashboard")), __jsx(DashboardLayout/* default */.Z, null, __jsx(upcoming_New, null)));
}

/* harmony default export */ const upcoming_new = ((0,tools_.withSuperJSONPage)(AdminDashboard));
var getServerSideProps = (0,tools_.withSuperJSONProps)( /*#__PURE__*/function () {
  var _getServerSideProps = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(context) {
    var req, session;
    return regenerator_default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            req = context.req;
            _context.next = 3;
            return (0,react_.getSession)({
              req: req
            });

          case 3:
            session = _context.sent;

            if (session) {
              _context.next = 6;
              break;
            }

            return _context.abrupt("return", {
              redirect: {
                destination: '/',
                permanent: false
              }
            });

          case 6:
            return _context.abrupt("return", {
              props: {}
            });

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  function getServerSideProps(_x) {
    return _getServerSideProps.apply(this, arguments);
  }

  return getServerSideProps;
}(), []);

/***/ }),

/***/ 5680:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AppRegistration");

/***/ }),

/***/ 8511:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DashboardCustomize");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 6902:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 7980:
/***/ ((module) => {

module.exports = require("@mui/icons-material/EventNote");

/***/ }),

/***/ 2584:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SupervisorAccount");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 4146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 983:
/***/ ((module) => {

module.exports = require("react-datepicker");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,5675,676,1664,5771,4519,1947,1817,2489,1505], () => (__webpack_exec__(674)));
module.exports = __webpack_exports__;

})();