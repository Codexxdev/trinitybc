"use strict";
(() => {
var exports = {};
exports.id = 8894;
exports.ids = [8894];
exports.modules = {

/***/ 7496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ conference),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(29);
// EXTERNAL MODULE: external "babel-plugin-superjson-next/tools"
var tools_ = __webpack_require__(1421);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7794);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Dashboard/DashboardLayout.js + 4 modules
var DashboardLayout = __webpack_require__(1817);
// EXTERNAL MODULE: external "@mui/icons-material/Add"
var Add_ = __webpack_require__(6146);
// EXTERNAL MODULE: external "@mui/icons-material/Edit"
var Edit_ = __webpack_require__(6902);
// EXTERNAL MODULE: external "@mui/icons-material/Delete"
var Delete_ = __webpack_require__(3188);
var Delete_default = /*#__PURE__*/__webpack_require__.n(Delete_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./components/common/Loader.js
var Loader = __webpack_require__(538);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(4146);
// EXTERNAL MODULE: ./redux/features/register.js
var register = __webpack_require__(5460);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./redux/features/menu.js
var menu = __webpack_require__(5771);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Dashboard/register/conference/Conference.js













const Conference = () => {
  const {
    loading,
    registers
  } = (0,external_react_redux_.useSelector)(state => state.register);
  const dispatch = (0,external_react_redux_.useDispatch)();
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    dispatch((0,register/* getAdminRegisters */.EC)());
  }, [dispatch]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "space-y-5",
    children: loading ? /*#__PURE__*/jsx_runtime_.jsx(Loader/* default */.Z, {}) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("table", {
      className: "w-full ",
      children: [/*#__PURE__*/jsx_runtime_.jsx("thead", {
        className: "bg-gray-800 text-gray-200 ",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
          className: "",
          children: [/*#__PURE__*/jsx_runtime_.jsx("th", {
            scope: "col",
            className: "text-sm font-medium uppercase px-4 py-4 text-left",
            children: "#"
          }), /*#__PURE__*/jsx_runtime_.jsx("th", {
            scope: "col",
            className: "text-sm font-medium uppercase px-3 py-4 text-left",
            children: "Name"
          }), /*#__PURE__*/jsx_runtime_.jsx("th", {
            scope: "col",
            className: "text-sm font-medium uppercase px-3 py-4 text-left",
            children: "Email/Phone"
          }), /*#__PURE__*/jsx_runtime_.jsx("th", {
            scope: "col",
            className: "text-sm font-medium uppercase px-3 py-4 text-left",
            children: "Conference"
          }), /*#__PURE__*/jsx_runtime_.jsx("th", {
            scope: "col",
            className: "text-sm font-medium uppercase px-3 py-4 text-left",
            children: "Date"
          }), /*#__PURE__*/jsx_runtime_.jsx("th", {
            scope: "col",
            className: "text-sm font-medium uppercase px-3 py-4 text-left",
            children: "Actions"
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("tbody", {
        className: "bg-white  ",
        children: registers.map((register, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
          className: ` transition duration-300 ease-in-out border-b border-b-gray-200`,
          children: [/*#__PURE__*/jsx_runtime_.jsx("td", {
            className: "px-4 py-4 whitespace-nowrap text-sm  ",
            children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
              children: index + 1
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("td", {
            className: "text-sm px-3 py-4 whitespace-nowrap",
            children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "capitalize",
              children: `${register.firstName} ${register.lastName}`
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("td", {
            className: "text-sm px-3 py-4 whitespace-nowrap",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex flex-col space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                className: "lowercase",
                children: register.email
              }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                children: register.phone
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("td", {
            className: "text-sm px-3 py-4 whitespace-nowrap",
            children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "capitalize font-medium text-orange-600",
              children: register.conference.title
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("td", {
            className: "text-sm px-3 py-4 whitespace-nowrap",
            children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "capitalize",
              children: (0,external_date_fns_.format)(new Date(register.date), 'MMMM dd, yyyy')
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("td", {
            className: "text-sm  font-light px-3 py-4 whitespace-nowrap",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "flex space-x-2 items-center",
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                onClick: () => {
                  dispatch((0,menu/* setDeleteModalData */.bG)({
                    register,
                    index
                  }));
                  dispatch((0,menu/* setDeletModalState */.e$)(true));
                },
                className: "flex justify-center items-center cursor-pointer hover:bg-red-600 bg-red-600/90 w-7 h-7 rounded-full",
                children: /*#__PURE__*/jsx_runtime_.jsx((Delete_default()), {
                  className: "!text-white !text-base"
                })
              })
            })
          })]
        }, register._id))
      })]
    })
  });
};

/* harmony default export */ const conference_Conference = (Conference);
// EXTERNAL MODULE: ./components/Dashboard/register/Register.js
var Register = __webpack_require__(5323);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/admin/register/conference/index.js




var __jsx = (external_react_default()).createElement;







function AdminDashboard() {
  return __jsx("div", null, __jsx((head_default()), null, __jsx("title", null, "TBC || Admin Dashboard")), __jsx(DashboardLayout/* default */.Z, null, __jsx(Register/* default */.Z, null, __jsx(conference_Conference, null))));
}

/* harmony default export */ const conference = ((0,tools_.withSuperJSONPage)(AdminDashboard));
var getServerSideProps = (0,tools_.withSuperJSONProps)( /*#__PURE__*/function () {
  var _getServerSideProps = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(context) {
    var req, session;
    return regenerator_default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            req = context.req;
            _context.next = 3;
            return (0,react_.getSession)({
              req: req
            });

          case 3:
            session = _context.sent;

            if (session) {
              _context.next = 6;
              break;
            }

            return _context.abrupt("return", {
              redirect: {
                destination: '/',
                permanent: false
              }
            });

          case 6:
            return _context.abrupt("return", {
              props: {}
            });

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  function getServerSideProps(_x) {
    return _getServerSideProps.apply(this, arguments);
  }

  return getServerSideProps;
}(), []);

/***/ }),

/***/ 6146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 5680:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AppRegistration");

/***/ }),

/***/ 8511:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DashboardCustomize");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 6902:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 7980:
/***/ ((module) => {

module.exports = require("@mui/icons-material/EventNote");

/***/ }),

/***/ 2584:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SupervisorAccount");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 4146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 983:
/***/ ((module) => {

module.exports = require("react-datepicker");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 3278:
/***/ ((module) => {

module.exports = require("react-spinners/ClipLoader");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,5675,676,1664,5771,4519,1947,1817,1796], () => (__webpack_exec__(7496)));
module.exports = __webpack_exports__;

})();