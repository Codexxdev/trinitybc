"use strict";
(() => {
var exports = {};
exports.id = 4947;
exports.ids = [4947];
exports.modules = {

/***/ 1924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ministers_new),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(29);
// EXTERNAL MODULE: external "babel-plugin-superjson-next/tools"
var tools_ = __webpack_require__(1421);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7794);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Dashboard/DashboardLayout.js + 4 modules
var DashboardLayout = __webpack_require__(1817);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/features/addMinister.js
var addMinister = __webpack_require__(9506);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./components/common/ImageUploader.js
var ImageUploader = __webpack_require__(6688);
// EXTERNAL MODULE: external "react-spinners/BeatLoader"
var BeatLoader_ = __webpack_require__(3060);
var BeatLoader_default = /*#__PURE__*/__webpack_require__.n(BeatLoader_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Dashboard/ministers/New.js










const New = () => {
  const {
    0: imageUrl,
    1: setImageUrl
  } = (0,external_react_.useState)('');
  const {
    0: name,
    1: setName
  } = (0,external_react_.useState)('');
  const {
    0: role,
    1: setRole
  } = (0,external_react_.useState)('');
  const {
    0: about,
    1: setAbout
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    0: imagePreview,
    1: setImagePreview
  } = (0,external_react_.useState)('');
  const dispatch = (0,external_react_redux_.useDispatch)();
  (0,external_react_.useEffect)(() => {}, []);
  const router = (0,router_.useRouter)();

  const hadleSubmit = e => {
    e.preventDefault();

    if (imageUrl && name && role && about) {
      setLoading(true);
      dispatch((0,addMinister/* postAddMinister */.U)({
        name,
        role,
        imageUrl,
        about
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("Minister Added Successfully");
          router.push("/admin/ministers");
        } else {
          console.log(result.error);
        }
      });
    } else {
      external_react_toastify_.toast.error("Please fill all the fields");
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex  w-full min-h-screen  my-2  mx-2 rounded-2xl bg-white",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full flex flex-col space-y-7 h-fit items-center  pt-5 px-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase text-lg text-primary-dark font-medium",
        children: "Add minister"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
        className: "w-full space-y-5 ",
        autoComplete: "off",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full h-full grid grid-cols-12 items-center gap-5",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "col-span-7 space-y-5 w-full text-gray-700 ",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "grid grid-cols-12  w-full items-center gap-2",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "col-span-8 space-y-2",
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  htmlFor: "title",
                  className: "ml-2 text-sm uppercase",
                  children: "Name"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "title",
                  name: "title",
                  className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                  required: true,
                  value: name,
                  onChange: e => {
                    setName(e.target.value);
                  }
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "col-span-4 space-y-2",
                children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                  htmlFor: "title",
                  className: "ml-2 text-sm uppercase",
                  children: "Role"
                }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                  type: "title",
                  name: "title",
                  className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                  required: true,
                  value: role,
                  onChange: e => {
                    setRole(e.target.value);
                  }
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "description",
                className: "ml-2 text-sm uppercase",
                children: "About"
              }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                rows: "8",
                value: about,
                onChange: e => {
                  setAbout(e.target.value);
                }
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-span-5 space-y-5 w-full text-gray-700 ",
            children: /*#__PURE__*/jsx_runtime_.jsx(ImageUploader/* default */.Z, {
              imagePreview: imagePreview,
              setImagePreview: setImagePreview,
              setImageUrl: setImageUrl,
              imageUrl: imageUrl,
              height: "h-52"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center justify-between w-full !mt-10 !mb-3",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            onClick: () => {
              router.back();
            },
            className: "cursor-pointer text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-red-700",
            children: "cancel"
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            onClick: hadleSubmit,
            className: "text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-blue-600",
            children: loading ? /*#__PURE__*/jsx_runtime_.jsx((BeatLoader_default()), {
              color: "#ffffff",
              loading: loading,
              size: 10
            }) : "create"
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const ministers_New = (New);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/admin/ministers/new.js




var __jsx = (external_react_default()).createElement;






function AdminDashboard() {
  return __jsx("div", null, __jsx((head_default()), null, __jsx("title", null, "TBC || Admin Dashboard")), __jsx(DashboardLayout/* default */.Z, null, __jsx(ministers_New, null)));
}

/* harmony default export */ const ministers_new = ((0,tools_.withSuperJSONPage)(AdminDashboard));
var getServerSideProps = (0,tools_.withSuperJSONProps)( /*#__PURE__*/function () {
  var _getServerSideProps = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(context) {
    var req, session;
    return regenerator_default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            req = context.req;
            _context.next = 3;
            return (0,react_.getSession)({
              req: req
            });

          case 3:
            session = _context.sent;

            if (session) {
              _context.next = 6;
              break;
            }

            return _context.abrupt("return", {
              redirect: {
                destination: '/',
                permanent: false
              }
            });

          case 6:
            return _context.abrupt("return", {
              props: {}
            });

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  function getServerSideProps(_x) {
    return _getServerSideProps.apply(this, arguments);
  }

  return getServerSideProps;
}(), []);

/***/ }),

/***/ 5680:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AppRegistration");

/***/ }),

/***/ 8511:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DashboardCustomize");

/***/ }),

/***/ 7980:
/***/ ((module) => {

module.exports = require("@mui/icons-material/EventNote");

/***/ }),

/***/ 2584:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SupervisorAccount");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1421:
/***/ ((module) => {

module.exports = require("babel-plugin-superjson-next/tools");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 8319:
/***/ ((module) => {

module.exports = require("next/dist/compiled/regenerator-runtime");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 4241:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/routing-items.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 983:
/***/ ((module) => {

module.exports = require("react-datepicker");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 3060:
/***/ ((module) => {

module.exports = require("react-spinners/BeatLoader");

/***/ }),

/***/ 1187:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2082,5675,676,1664,5771,4519,1947,1817,2489,9506], () => (__webpack_exec__(1924)));
module.exports = __webpack_exports__;

})();