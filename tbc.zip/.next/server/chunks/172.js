exports.id = 172;
exports.ids = [172];
exports.modules = {

/***/ 172:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_Layout)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(8017);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3365);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/features/menu.js
var menu = __webpack_require__(5771);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Ministries/data.js
var data = __webpack_require__(9888);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/layout/Links.js








const Links = ({
  title
}) => {
  const router = (0,router_.useRouter)();
  const {
    0: active,
    1: setActive
  } = (0,external_react_.useState)();
  const {
    0: toggleMinistries,
    1: setToggleMinistries
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    if (title !== "events & news") {
      setActive(title);
    } else {
      setActive("events");
    }
  }, [title]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      onMouseOver: () => {
        if (title === "ministries") {
          setToggleMinistries(true);
        }
      },
      onMouseOut: () => {
        if (title === "ministries") {
          setToggleMinistries(false);
        }
      },
      className: "relative",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: `${title !== "ministries" ? "/" + active : "#"}`,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: `${router.pathname.split("/")[1] === active ? "font-medium" : "font-light"} hover:font-normal hover:text-[black]/70 capitalize `,
          children: title
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: ` ${router.pathname.split("/")[1] === active ? "h-1" : "h-0"} w-full rounded-md   bg-primary-dark/80 absolute -bottom-[22.5px]  `
      })]
    }), title === "ministries" && toggleMinistries && /*#__PURE__*/jsx_runtime_.jsx("div", {
      onMouseOver: () => {
        if (title === "ministries") {
          setToggleMinistries(true);
        }
      },
      onMouseOut: () => {
        if (title === "ministries") {
          setToggleMinistries(false);
        }
      },
      className: "absolute w-36 h-[500]",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "-ml-10 mt-6 p-5 space-y-5 rounded-xl flex flex-col h-full shadow-2xl bg-white",
        children: data/* default.map */.Z.map(data => /*#__PURE__*/jsx_runtime_.jsx("h1", {
          onClick: () => {
            router.push(`/ministries/${data.id}`);
          },
          className: "text-sm border-b border-b-gray-100 pb-1 capitalize font-light cursor-pointer",
          children: data.title
        }, data.id))
      })
    })]
  });
};

/* harmony default export */ const layout_Links = (Links);
// EXTERNAL MODULE: external "@mui/icons-material/Close"
var Close_ = __webpack_require__(4173);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
// EXTERNAL MODULE: external "@mui/icons-material/Person"
var Person_ = __webpack_require__(1939);
var Person_default = /*#__PURE__*/__webpack_require__.n(Person_);
// EXTERNAL MODULE: ./redux/features/currentUser.js
var currentUser = __webpack_require__(3998);
;// CONCATENATED MODULE: ./components/layout/Header.js
















const Header = ({
  menuState
}) => {
  const {
    0: toggleSearch,
    1: setToggleSearch
  } = (0,external_react_.useState)(false);
  const {
    0: keyword,
    1: setKeyword
  } = (0,external_react_.useState)('');
  const dispatch = (0,external_react_redux_.useDispatch)();
  const router = (0,router_.useRouter)();
  const {
    loading,
    user,
    message
  } = (0,external_react_redux_.useSelector)(state => state.currentUser);
  (0,external_react_.useEffect)(() => {
    dispatch((0,currentUser/* loadUser */.I)());
  }, []);

  const handleSubmit = e => {
    e.preventDefault();

    if (keyword.trim() !== '') {
      setToggleSearch(false);
      setKeyword('');
      router.push(`/search?keyword=${keyword.trim()}`);
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: ` ${toggleSearch ? "h-[60px] md:h-[68px] py-1 md:py-2 " : "h-0"} transition-all duration-200 ease-in-out
            bg-white w-full shadow-sm fixed top-0 left-0 right-0  !z-50 `,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
        onSubmit: handleSubmit,
        className: `${!toggleSearch ? "hidden" : "flex"} container px-2 md:px-0 xl:px-[2rem] lg:px-[1rem]  w-full h-full justify-between items-center`,
        children: [/*#__PURE__*/jsx_runtime_.jsx((Search_default()), {
          className: "!md:text-3xl"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          value: keyword,
          onChange: e => setKeyword(e.target.value),
          className: "w-full px-4 py-2 \r text-sm md:text-base md:px-8 md:py-4 bg-transparent focus:outline-none focus:bg-transparent",
          type: "text",
          placeholder: "Search Resources"
        }), /*#__PURE__*/jsx_runtime_.jsx((Close_default()), {
          onClick: () => setToggleSearch(!toggleSearch),
          className: "cursor-pointer"
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("header", {
      className: ` bg-[#fff] shadow-md fixed top-0 left-0 right-0  !z-40 py-1 md:py-2 `,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
        className: "flex justify-between items-center h-[50px] container px-1 md:px-0 xl:px-[2rem] lg:px-[1rem]  relative",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
            src: "/logo.png",
            width: 37,
            height: 37,
            alt: "logo"
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "text-sm lg:text-base",
              children: "Trinity Baptist Church"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: " hidden lg:flex  justify-between space-x-8 ",
          children: [/*#__PURE__*/jsx_runtime_.jsx(layout_Links, {
            title: "ministries"
          }), /*#__PURE__*/jsx_runtime_.jsx(layout_Links, {
            title: "about"
          }), /*#__PURE__*/jsx_runtime_.jsx(layout_Links, {
            title: "resources"
          }), /*#__PURE__*/jsx_runtime_.jsx(layout_Links, {
            title: "events & news"
          }), /*#__PURE__*/jsx_runtime_.jsx(layout_Links, {
            title: "give"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "hidden lg:flex space-x-5 items-center lg:ml-28 ",
          children: [user && user.role === "admin" && /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/admin/resources/sermon",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: /*#__PURE__*/jsx_runtime_.jsx((Person_default()), {
                className: " cursor-pointer"
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx((Search_default()), {
            onClick: () => setToggleSearch(!toggleSearch),
            className: "!md:text-3xl cursor-pointer"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex lg:hidden items-center !space-x-5",
          children: [/*#__PURE__*/jsx_runtime_.jsx((Search_default()), {
            onClick: () => setToggleSearch(!toggleSearch),
            className: " !text-[28px] !text-primary-black/70 cursor-pointer "
          }), /*#__PURE__*/jsx_runtime_.jsx((Menu_default()), {
            onClick: () => {
              dispatch((0,menu/* setMenuState */.eu)(true));
            },
            className: " !text-4xl !text-primary-black/70 cursor-pointer"
          })]
        })]
      })
    })]
  });
};

/* harmony default export */ const layout_Header = (Header);
// EXTERNAL MODULE: external "@mui/icons-material/Facebook"
var Facebook_ = __webpack_require__(7666);
var Facebook_default = /*#__PURE__*/__webpack_require__.n(Facebook_);
// EXTERNAL MODULE: external "@mui/icons-material/Instagram"
var Instagram_ = __webpack_require__(3281);
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_);
// EXTERNAL MODULE: external "@mui/icons-material/YouTube"
var YouTube_ = __webpack_require__(375);
var YouTube_default = /*#__PURE__*/__webpack_require__.n(YouTube_);
// EXTERNAL MODULE: ./redux/features/client/addEmail.js
var addEmail = __webpack_require__(4509);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./components/common/ButtonLoader.js
var ButtonLoader = __webpack_require__(1947);
;// CONCATENATED MODULE: ./components/layout/Footer.js













const Footer = () => {
  const {
    0: email,
    1: setEmail
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const router = (0,router_.useRouter)();
  const dispatch = (0,external_react_redux_.useDispatch)();

  const handleSubmit = e => {
    e.preventDefault();
    setLoading(true);

    if (email.includes('@') && email.includes('.')) {
      dispatch((0,addEmail/* postAddEmail */.Q)({
        email
      })).then(res => {
        if (!res.error) {
          setEmail('');
          setLoading(false);
          external_react_toastify_.toast.success('Email added successfully');
        } else {
          setLoading(false);
          external_react_toastify_.toast.error('Email already exists');
        }
      });
    } else {
      setLoading(false);
      external_react_toastify_.toast.info('Please enter a valid email');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const goHome = () => {
    if (router.route !== '/') {
      router.push('/');
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `${router.pathname.includes("admin") || router.pathname.includes("sign") ? "hidden" : "block"} `,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex  w-full mb-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        onClick: scrollToTop,
        className: "w-full cursor-pointer h-8 flex items-center justify-center bg-gray-600",
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "text-center text-xs uppercase text-gray-100",
          children: "Scroll to top"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        onClick: goHome,
        className: `${router.route === '/' ? "cursor-not-allowed" : "cursor-pointer"} w-full  h-8 flex items-center justify-center bg-gray-300`,
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          disabled: router.route === '/',
          className: `${router.route === '/' ? "text-gray-500" : "text-gray-800"} text-xs text-center uppercase `,
          children: "Go home"
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "bg-gradient-to-r from-primary-dark to-primary-light text-[white]  pt-2",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container lg:px-[2rem] py-4 !mt-10 px-2 md:px-0 space-y-4 ",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col md:flex-row md:justify-between md:items-center space-y-5 md:space-y-0",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col space-y-1 md:space-x-2 justify-center md:flex-row items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-sm lg:text-base",
              children: "follow us on:"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "space-x-3",
              children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjRl_ewhPH4AhWFwYUKHW7fBTQQ9zB6BAg2EAU&url=https%3A%2F%2Fwww.facebook.com%2FTrinityAbuja%2F&usg=AOvVaw3QTaeA8X43LW2QfQufo2os",
                target: "_blank",
                rel: "noreferrer",
                children: /*#__PURE__*/jsx_runtime_.jsx((Facebook_default()), {
                  className: "text-xl lg:text-2xl "
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjRl_ewhPH4AhWFwYUKHW7fBTQQ9zB6BAg2EAc&url=https%3A%2F%2Fwww.instagram.com%2Ftrinityabuja_%2F&usg=AOvVaw2gaudocp3es_is4bTSFRo3",
                target: "_blank",
                rel: "noreferrer",
                children: /*#__PURE__*/jsx_runtime_.jsx((Instagram_default()), {
                  className: "text-xl lg:text-2xl "
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "https://www.youtube.com/channel/UCQseR5f03EmwlbIGyFTImlQ",
                target: "_blank",
                rel: "noreferrer",
                children: /*#__PURE__*/jsx_runtime_.jsx((YouTube_default()), {
                  className: "text-xl lg:text-2xl "
                })
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col space-y-1",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "uppercase text-xs lg:text-sm",
              children: "New Resources in your inbox"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex ",
              children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "email",
                value: email,
                onChange: e => setEmail(e.target.value),
                className: "border bg-transparent  py-1 text-sm lg:text-base !w-full h-9 px-3 lg:px-5  outline-none text-white ",
                placeholder: "Email Address"
              }), /*#__PURE__*/jsx_runtime_.jsx("button", {
                onClick: handleSubmit,
                className: "border py-1 px-3 md:px-4 uppercase\r text-xs w-28 lg:text-sm bg-white text-black rounded-r-xl ",
                children: loading ? /*#__PURE__*/jsx_runtime_.jsx(ButtonLoader/* default */.Z, {}) : "Submit"
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col w-full md:flex-row space-y-8 !mt-5 md:!mt-10 md:space-y-0 md:justify-between !items-start",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col w-full md:!w-fit text-center md:text-left space-y-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-sm lg:text-base mb-4  font-medium uppercase",
              children: "Services"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm font-medium uppercase",
              children: "LORD'S DAY SERVICES:"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "Sunday School 9AM - 10AM"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "Morning Service 10AM - 11:30AM"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "Evening Service 4PM - 5:30PM"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm font-medium uppercase !mt-6",
              children: "TUSEDAY BIBLE STUDY: 6PM - 7:30PM"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm font-medium uppercase !mt-6 ",
              children: "FRIDAY PRAYER MEETING: 6PM - 7:30PM"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col w-full md:!w-fit text-center md:text-left space-y-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-sm lg:text-base font-medium mb-4 uppercase",
              children: "LOCATION"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "Trinity Baptist Church,"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "House 4, Juba Street,"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "Galadimawa, Suncity Estate,"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "Abuja FCT"
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              href: "https://www.google.com/maps/place/Trinity+Baptist+Church,+Abuja/@8.989531,7.433382,16z/data=!4m5!3m4!1s0x0:0x95fb206cd5ea74f5!8m2!3d8.9895309!4d7.4333819?hl=en",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                target: "_blank",
                rel: "noreferrer",
                children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
                  className: "text-xs lg:text-sm uppercase !mt-6 underline cursor-pointer hover:scale-105 ",
                  children: "Maps and Direction "
                })
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col w-full md:!w-fit text-center md:text-left space-y-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-sm lg:text-base font-medium mb-4 uppercase",
              children: "CONTACT"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm uppercase",
              children: "M-F 9AM - 5PM"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "+234 903 888 1689"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: "text-xs lg:text-sm ",
              children: "trinitybaptistchurchabuja@gmail.com"
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              href: "/signin",
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
                  className: "text-xs cursor-pointer uppercase lg:text-sm ",
                  children: "Admin signin"
                })
              })
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-center text-xs md:text-sm !mt-4",
          children: "Copyright \xA9 2022 Trinity Baptist Church. All Rights Reserved."
        })]
      })
    })]
  });
};

/* harmony default export */ const layout_Footer = (Footer);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowUp"
var KeyboardArrowUp_ = __webpack_require__(9881);
var KeyboardArrowUp_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowUp_);
;// CONCATENATED MODULE: ./components/MenuLinks.js













const MenuLinks = ({
  title
}) => {
  const {
    0: ministries,
    1: setMinistries
  } = (0,external_react_.useState)(false);
  const {
    0: active,
    1: setActive
  } = (0,external_react_.useState)();
  const router = (0,router_.useRouter)();
  const {
    menuState
  } = (0,external_react_redux_.useSelector)(state => state.menu);
  const dispatch = (0,external_react_redux_.useDispatch)();
  (0,external_react_.useEffect)(() => {
    if (title !== "events & news") {
      setActive(title);
    } else {
      setActive("events");
    }
  }, [title]);

  const handleClick = () => {
    router.push(`/${active}`);
    dispatch((0,menu/* setMenuState */.eu)(false));
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-col space-y-3 mt-4 ",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `flex w-full justify-between items-center ${title === "ministries" ? "space-x-1" : "space-x-0"} ${menuState ? "!text-primary-black" : "text-[white]"} 
            transition-all duration-300 ease-in-out`,
      onClick: () => {
        if (title === "ministries") {
          setMinistries(!ministries);
        } else {
          handleClick();
        }
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: `${router.pathname.split("/")[1] === active ? "font-medium" : "font-light"} text-xl md:hover:font-medium capitalize cursor-pointer`,
        children: title
      }), title === "ministries" && /*#__PURE__*/jsx_runtime_.jsx("div", {
        children: ministries ? /*#__PURE__*/jsx_runtime_.jsx((KeyboardArrowUp_default()), {
          className: " text-xl "
        }) : /*#__PURE__*/jsx_runtime_.jsx((KeyboardArrowDown_default()), {
          className: " text-xl "
        })
      })]
    }), title === "ministries" && ministries && menuState && /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `flex flex-col w-full text-lg font-light pl-3 space-y-2  `,
      children: data/* default */.Z === null || data/* default */.Z === void 0 ? void 0 : data/* default.map */.Z.map(data => /*#__PURE__*/jsx_runtime_.jsx("h1", {
        onClick: () => {
          router.push(`/ministries/${data.id}`);
          dispatch((0,menu/* setMenuState */.eu)(false));
        },
        className: "text-sm hover:text-black hover:font-normal border-b border-b-gray-100 pb-1 capitalize font-light cursor-pointer ",
        children: data.title
      }, data.id))
    })]
  });
};

/* harmony default export */ const components_MenuLinks = (MenuLinks);
;// CONCATENATED MODULE: ./components/Menu.js







const Menu = ({
  menuState
}) => {
  const dispatch = (0,external_react_redux_.useDispatch)();
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: `${menuState ? " w-[70%] md:w-[40%] " : "w-0"} !shadow-2xl lg:hidden py-5 fixed transition-all duration-700 ease-in-out bg-[white] h-screen top-0 right-0 !z-50 !overflow-x-hidden `,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col w-full px-5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex justify-end",
        children: /*#__PURE__*/jsx_runtime_.jsx((Close_default()), {
          className: `  ${menuState ? " text-primary-black " : "text-[white]/80"} cursor-pointer transition-all duration-500 ease-in-out font-light`,
          onClick: () => {
            dispatch((0,menu/* setMenuState */.eu)(false));
          }
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `flex flex-col px-3 py-3 space-y-7  `,
        children: [/*#__PURE__*/jsx_runtime_.jsx(components_MenuLinks, {
          title: "ministries"
        }), /*#__PURE__*/jsx_runtime_.jsx(components_MenuLinks, {
          title: "about"
        }), /*#__PURE__*/jsx_runtime_.jsx(components_MenuLinks, {
          title: "resources"
        }), /*#__PURE__*/jsx_runtime_.jsx(components_MenuLinks, {
          title: "events & news"
        }), /*#__PURE__*/jsx_runtime_.jsx(components_MenuLinks, {
          title: "give"
        })]
      })]
    })
  });
};

/* harmony default export */ const components_Menu = (Menu);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(8819);
;// CONCATENATED MODULE: ./components/layout/Layout.js











const Layout = ({
  children
}) => {
  const {
    menuState
  } = (0,external_react_redux_.useSelector)(state => state.menu);
  const dispatch = (0,external_react_redux_.useDispatch)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "font-Poppins  text-gray-900 overflow-x-hidden",
    children: [/*#__PURE__*/jsx_runtime_.jsx(components_Menu, {
      menuState: menuState
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `${menuState ? " overflow-y-hidden  " : "w-full"} `,
      onClick: () => menuState && dispatch((0,menu/* setMenuState */.eu)(false)),
      children: [/*#__PURE__*/jsx_runtime_.jsx(layout_Header, {
        menState: menuState
      }), /*#__PURE__*/jsx_runtime_.jsx(external_react_toastify_.ToastContainer, {
        position: "bottom-right"
      }), children, /*#__PURE__*/jsx_runtime_.jsx(layout_Footer, {})]
    })]
  });
};

/* harmony default export */ const layout_Layout = (Layout);

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;