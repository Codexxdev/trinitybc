"use strict";
exports.id = 1885;
exports.ids = [1885];
exports.modules = {

/***/ 1885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dc": () => (/* binding */ createConference),
/* harmony export */   "O4": () => (/* binding */ getAdminConferences),
/* harmony export */   "Q8": () => (/* binding */ deleteConference),
/* harmony export */   "kE": () => (/* binding */ deleteConferenceSermon),
/* harmony export */   "vQ": () => (/* binding */ getConference),
/* harmony export */   "Hj": () => (/* binding */ conferenceSermons),
/* harmony export */   "Fn": () => (/* binding */ updateConference),
/* harmony export */   "kx": () => (/* binding */ updateConferenceSermon),
/* harmony export */   "Kj": () => (/* binding */ getConferenceDetails),
/* harmony export */   "fh": () => (/* binding */ getClientConference),
/* harmony export */   "Oy": () => (/* binding */ getConferenceFilters)
/* harmony export */ });
/* harmony import */ var _models_Conference__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(840);
/* harmony import */ var _models_Ministers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3373);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3518);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(cloudinary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21);





cloudinary__WEBPACK_IMPORTED_MODULE_3___default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // get client sermons
// get => /api/client/sermons

const getConferenceFilters = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conferences = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort('-startDate').populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  let dt = [];
  let dp = [];
  let ds = [];
  conferences.map(conference => {
    conference.sermons.map(sermon => {
      dt.push(sermon.topic);
      dp.push(sermon.preacher.name);
      ds.push(sermon.book);
    });
  });
  const topics = [...new Set(dt)];
  const preachers = [...new Set(dp)];
  const scriptures = [...new Set(ds)];
  res.status(200).json({
    success: "true",
    topics,
    preachers,
    scriptures
  });
}); // get client conference
// get => /api/client/conference

const getClientConference = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    topic,
    preacher,
    scripture,
    sort
  } = req.query;
  const page = Number(req.query.page) || 1;
  const resPerPage = 10;
  let sortQuery = "-startDate";

  if (sort) {
    sort === 'oldest' ? sortQuery = 'startDate' : sort === 'a-z' ? sortQuery = 'title' : sort === 'z-a' ? sortQuery = '-title' : sortQuery = '-startDate';
  }

  const query = {
    "sermons": {
      $elemMatch: {}
    }
  };

  if (topic) {
    query.sermons.$elemMatch.topic = {
      $regex: topic,
      $options: 'i'
    };
  }

  if (preacher) {
    query.sermons.$elemMatch.preacher = preacher;
  }

  if (scripture) {
    query.sermons.$elemMatch.book = {
      $regex: scripture,
      $options: 'i'
    };
  }

  const totalItems = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].countDocuments */ .Z.countDocuments(query);
  const conferences = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find(query).sort(sortQuery).skip((page - 1) * resPerPage).limit(resPerPage).populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    conferences,
    totalItems,
    resPerPage
  });
}); // get client conference detail
// get => /api/client/conference/:id

const getConferenceDetails = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'sermons.preacher',
    select: "name about imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    conference
  });
}); // create conference
// post =>  /api/admin/conference

const createConference = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create(req.body);
  res.status(200).json({
    success: "true",
    message: "Conference created successfully"
  });
}); // get Conference
// get =>  /api/admin/conference

const getAdminConferences = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conferences = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort({
    date: -1
  }).populate({
    path: 'sermons.preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    conferences
  });
}); // Delete conference
// Delete => api/admin/conference/:id

const deleteConference = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!conference) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Conference not found with this ID', 404));
  } else {
    await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(conference.imageUrl.public_id);
    conference.sermons.forEach(async sermon => {
      var _sermon$imageUrl;

      if ((_sermon$imageUrl = sermon.imageUrl) !== null && _sermon$imageUrl !== void 0 && _sermon$imageUrl.public_id) {
        var _sermon$imageUrl2;

        await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy((_sermon$imageUrl2 = sermon.imageUrl) === null || _sermon$imageUrl2 === void 0 ? void 0 : _sermon$imageUrl2.public_id);
      }
    });
    await conference.remove();
    res.status(200).json({
      success: "true",
      message: "Conference Deleted"
    });
  }
}); // Delete conference sermon
// Delete => api/admin/conference/:id

const deleteConferenceSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    sermonId,
    id
  } = req.query;
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(id);

  if (!conference) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Conference not found with this ID', 404));
  } else {
    conference.sermons.forEach(async sermon => {
      if (sermon._id.toString() === sermonId.toString()) {
        var _sermon$imageUrl3;

        if ((_sermon$imageUrl3 = sermon.imageUrl) !== null && _sermon$imageUrl3 !== void 0 && _sermon$imageUrl3.public_id) {
          var _sermon$imageUrl4;

          await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy((_sermon$imageUrl4 = sermon.imageUrl) === null || _sermon$imageUrl4 === void 0 ? void 0 : _sermon$imageUrl4.public_id);
        }
      }
    });
    const updatedConferenceSermon = conference.sermons.filter(sermon => sermon._id.toString() !== sermonId.toString());
    conference.sermons = updatedConferenceSermon;
    await conference.save();
    res.status(200).json({
      success: "true",
      message: "Conference Sermon Deleted"
    });
  }
}); // get conference
// get => api/conference/:id

const getConference = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'sermons.preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });

  if (!conference) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Conference not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      conference
    });
  }
}); // update conference sermons
// put => api/conference/:id

const conferenceSermons = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!conference) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Conference not found with this ID', 404));
  } else {
    const {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    } = req.body;
    const sermon = {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    };
    conference.sermons.push(sermon);
    await conference.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
}); // update conference sermons
// put => api/conferences/:id

const updateConferenceSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    id,
    sermonId
  } = req.query;
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(id);
  const {
    title,
    category,
    topic,
    preacher,
    book,
    chapter,
    verse,
    date,
    description,
    imageUrl,
    audioUrl,
    youtubeLink
  } = req.body;

  if (!conference) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Conference not found with this ID', 404));
  } else {
    conference.sermons.forEach(async sermon => {
      if (sermon._id.toString() === sermonId.toString()) {
        sermon.title = title;
        sermon.category = category;
        sermon.topic = topic;
        sermon.preacher = preacher;
        sermon.book = book;
        sermon.chapter = chapter;
        sermon.verse = verse;
        sermon.date = date;
        sermon.description = description;
        sermon.audioUrl = audioUrl;
        sermon.youtubeLink = youtubeLink;

        if (imageUrl) {
          var _sermon$imageUrl5;

          if ((_sermon$imageUrl5 = sermon.imageUrl) !== null && _sermon$imageUrl5 !== void 0 && _sermon$imageUrl5.public_id && sermon.imageUrl.public_id !== imageUrl.public_id) {
            await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(sermon.imageUrl.public_id);
            sermon.imageUrl = imageUrl;
          } else {
            sermon.imageUrl = imageUrl;
          }
        } else {
          sermon.imageUrl = imageUrl;
        }
      }
    });
    await conference.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
}); // update conference 
// put => api/conferences/:id

const updateConference = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const conference = await _models_Conference__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!conference) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Conference not found with this ID', 404));
  } else {
    const {
      title,
      description,
      imageUrl,
      startDate,
      endDate
    } = req.body;
    conference.title = title;
    conference.description = description;
    conference.startDate = startDate;
    conference.endDate = endDate;

    if (imageUrl && imageUrl !== null && imageUrl !== void 0 && imageUrl.public_id) {
      var _conference$imageUrl;

      if ((conference === null || conference === void 0 ? void 0 : (_conference$imageUrl = conference.imageUrl) === null || _conference$imageUrl === void 0 ? void 0 : _conference$imageUrl.public_id) !== imageUrl.public_id) {
        await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(conference.imageUrl.public_id);
        conference.imageUrl = imageUrl;
      }
    }

    await conference.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
});


/***/ })

};
;