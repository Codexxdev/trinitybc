"use strict";
exports.id = 1508;
exports.ids = [1508];
exports.modules = {

/***/ 1508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u$": () => (/* binding */ createSeries),
/* harmony export */   "hD": () => (/* binding */ getAdminSeries),
/* harmony export */   "iL": () => (/* binding */ deleteSeries),
/* harmony export */   "gU": () => (/* binding */ getSeries),
/* harmony export */   "zg": () => (/* binding */ seriesSermons),
/* harmony export */   "rd": () => (/* binding */ updateSeries),
/* harmony export */   "hp": () => (/* binding */ updateSeriesSermon),
/* harmony export */   "QH": () => (/* binding */ deleteSeriesSermon),
/* harmony export */   "q5": () => (/* binding */ getClientSeries),
/* harmony export */   "Zy": () => (/* binding */ getSeriesDetails),
/* harmony export */   "DY": () => (/* binding */ getSeriesFilters)
/* harmony export */ });
/* harmony import */ var _models_Series__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6161);
/* harmony import */ var _models_Ministers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3373);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3518);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(cloudinary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21);





cloudinary__WEBPACK_IMPORTED_MODULE_3___default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // get client sermons
// get => /api/client/sermons

const getSeriesFilters = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort('-createdAt').populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  let dt = [];
  let dp = [];
  let ds = [];
  series.map(serie => {
    serie.sermons.map(sermon => {
      dt.push(sermon.topic);
      dp.push(sermon.preacher.name);
      ds.push(sermon.book);
    });
  });
  const topics = [...new Set(dt)];
  const preachers = [...new Set(dp)];
  const scriptures = [...new Set(ds)];
  res.status(200).json({
    success: "true",
    topics,
    preachers,
    scriptures
  });
}); // get client series
// get => /api/client/series

const getClientSeries = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    topic,
    preacher,
    scripture,
    sort
  } = req.query;
  const page = Number(req.query.page) || 1;
  const resPerPage = 10;
  const query = {
    "sermons": {
      $elemMatch: {}
    }
  };
  let sortQuery = "-createdAt";

  if (sort) {
    sort === 'oldest' ? sortQuery = 'createdAt' : sort === 'a-z' ? sortQuery = 'title' : sort === 'z-a' ? sortQuery = '-title' : sortQuery = '-createdAt';
  }

  if (topic) {
    query.sermons.$elemMatch.topic = {
      $regex: topic,
      $options: 'i'
    };
  }

  if (preacher) {
    query.sermons.$elemMatch.preacher = preacher;
  }

  if (scripture) {
    query.sermons.$elemMatch.book = {
      $regex: scripture,
      $options: 'i'
    };
  }

  const totalItems = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].countDocuments */ .Z.countDocuments(query);
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find(query).sort(sortQuery).skip((page - 1) * resPerPage).limit(resPerPage).populate({
    path: 'sermons.preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    series,
    totalItems,
    resPerPage
  });
}); // get client series detail
// get => /api/client/series/:id

const getSeriesDetails = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'sermons.preacher',
    select: "name about imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    series
  });
}); // create series
// post =>  /api/admin/series

const createSeries = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create(req.body);
  res.status(200).json({
    success: "true",
    message: "Series created successfully"
  });
}); // get Series
// get =>  /api/admin/Series

const getAdminSeries = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort({
    createdAt: -1
  }).populate({
    path: 'sermons.preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    series
  });
}); // Delete Series
// Delete => api/admin/Series/:id

const deleteSeries = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!series) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Series not found with this ID', 404));
  } else {
    await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(series.imageUrl.public_id);
    series.sermons.forEach(async sermon => {
      var _sermon$imageUrl;

      if ((_sermon$imageUrl = sermon.imageUrl) !== null && _sermon$imageUrl !== void 0 && _sermon$imageUrl.public_id) {
        var _sermon$imageUrl2;

        await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy((_sermon$imageUrl2 = sermon.imageUrl) === null || _sermon$imageUrl2 === void 0 ? void 0 : _sermon$imageUrl2.public_id);
      }
    });
    await series.remove();
    res.status(200).json({
      success: "true",
      message: "Series Deleted"
    });
  }
}); // Delete Series sermon
// Delete => api/admin/Series/:id

const deleteSeriesSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    sermonId,
    id
  } = req.query;
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(id);

  if (!series) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Series not found with this ID', 404));
  } else {
    series.sermons.forEach(async sermon => {
      if (sermon._id.toString() === sermonId.toString()) {
        var _sermon$imageUrl3;

        if ((_sermon$imageUrl3 = sermon.imageUrl) !== null && _sermon$imageUrl3 !== void 0 && _sermon$imageUrl3.public_id) {
          var _sermon$imageUrl4;

          await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy((_sermon$imageUrl4 = sermon.imageUrl) === null || _sermon$imageUrl4 === void 0 ? void 0 : _sermon$imageUrl4.public_id);
        }
      }
    });
    const updatedSermonSeries = series.sermons.filter(sermon => sermon._id.toString() !== sermonId.toString());
    series.sermons = updatedSermonSeries;
    await series.save();
    res.status(200).json({
      success: "true",
      message: "Series Sermon Deleted"
    });
  }
}); // get Series
// get => api/Series/:id

const getSeries = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'sermons.preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });

  if (!series) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Series not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      series
    });
  }
}); // update Series sermons
// put => api/Seriess/:id

const seriesSermons = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!series) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Series not found with this ID', 404));
  } else {
    const {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    } = req.body;
    const sermon = {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    };
    series.sermons.push(sermon);
    await series.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
}); // update Series sermons
// put => api/Seriess/:id

const updateSeriesSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    id,
    sermonId
  } = req.query;
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(id);
  const {
    title,
    category,
    topic,
    preacher,
    book,
    chapter,
    verse,
    date,
    description,
    imageUrl,
    audioUrl,
    youtubeLink
  } = req.body;

  if (!series) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Series not found with this ID', 404));
  } else {
    series.sermons.forEach(async sermon => {
      if (sermon._id.toString() === sermonId.toString()) {
        sermon.title = title;
        sermon.category = category;
        sermon.topic = topic;
        sermon.preacher = preacher;
        sermon.book = book;
        sermon.chapter = chapter;
        sermon.verse = verse;
        sermon.date = date;
        sermon.description = description;
        sermon.audioUrl = audioUrl;
        sermon.youtubeLink = youtubeLink;

        if (imageUrl) {
          var _sermon$imageUrl5;

          if ((_sermon$imageUrl5 = sermon.imageUrl) !== null && _sermon$imageUrl5 !== void 0 && _sermon$imageUrl5.public_id && sermon.imageUrl.public_id !== imageUrl.public_id) {
            await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(sermon.imageUrl.public_id);
            return sermon.imageUrl = imageUrl;
          } else {
            return sermon.imageUrl = imageUrl;
          }
        } else {
          return sermon.imageUrl = imageUrl;
        }
      }
    });
    await series.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
}); // update Series 
// put => api/Seriess/:id

const updateSeries = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const series = await _models_Series__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!series) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Series not found with this ID', 404));
  } else {
    const {
      title,
      description,
      imageUrl
    } = req.body;
    series.title = title;
    series.description = description;

    if (imageUrl && imageUrl !== null && imageUrl !== void 0 && imageUrl.public_id) {
      var _series$imageUrl;

      if ((series === null || series === void 0 ? void 0 : (_series$imageUrl = series.imageUrl) === null || _series$imageUrl === void 0 ? void 0 : _series$imageUrl.public_id) !== imageUrl.public_id) {
        await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(series.imageUrl.public_id);
        return series.imageUrl = imageUrl;
      }
    }

    await series.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
});


/***/ }),

/***/ 3373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const ministerSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: [true, 'Please enter your name']
  },
  role: {
    type: String,
    default: 'minister'
  },
  about: {
    type: String,
    required: [true, "Please enter minister's about"]
  },
  imageUrl: {
    public_id: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Minister) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Minister', ministerSchema));

/***/ })

};
;