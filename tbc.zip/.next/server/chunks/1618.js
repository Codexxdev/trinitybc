exports.id = 1618;
exports.ids = [1618];
exports.modules = {

/***/ 2640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Player)
});

// EXTERNAL MODULE: external "@mui/icons-material/CloudDownload"
var CloudDownload_ = __webpack_require__(3681);
var CloudDownload_default = /*#__PURE__*/__webpack_require__.n(CloudDownload_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/icons-material/PlayCircleOutline"
var PlayCircleOutline_ = __webpack_require__(1929);
var PlayCircleOutline_default = /*#__PURE__*/__webpack_require__.n(PlayCircleOutline_);
// EXTERNAL MODULE: external "@mui/material/Slider"
var Slider_ = __webpack_require__(3682);
var Slider_default = /*#__PURE__*/__webpack_require__.n(Slider_);
// EXTERNAL MODULE: external "@mui/icons-material/PauseCircleOutline"
var PauseCircleOutline_ = __webpack_require__(416);
var PauseCircleOutline_default = /*#__PURE__*/__webpack_require__.n(PauseCircleOutline_);
// EXTERNAL MODULE: external "@mui/icons-material/ArrowBack"
var ArrowBack_ = __webpack_require__(3622);
var ArrowBack_default = /*#__PURE__*/__webpack_require__.n(ArrowBack_);
// EXTERNAL MODULE: external "@mui/icons-material/ArrowForward"
var ArrowForward_ = __webpack_require__(1883);
var ArrowForward_default = /*#__PURE__*/__webpack_require__.n(ArrowForward_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Audio.js











const Audio = ({
  isVideo,
  audioLink,
  title
}) => {
  var _audioPlayer$current, _audioPlayer$current2;

  const {
    0: position,
    1: setPosition
  } = (0,external_react_.useState)(0);
  const {
    0: isPlaying,
    1: setIsPlaying
  } = (0,external_react_.useState)(false);
  const {
    0: duration,
    1: setDuration
  } = (0,external_react_.useState)(0);
  const {
    0: currentTime,
    1: setCurrentTime
  } = (0,external_react_.useState)(0);
  const {
    0: isLoading,
    1: setIsLoading
  } = (0,external_react_.useState)(true);
  const audioPlayer = (0,external_react_.useRef)();
  (0,external_react_.useEffect)(() => {
    audioPlayer.current.addEventListener('timeupdate', () => {
      setPosition(prev => prev = audioPlayer.current.currentTime);
      setCurrentTime(prev => prev = Math.floor(audioPlayer.current.currentTime));
    });
    audioPlayer.current.addEventListener('loadedmetadata', () => {
      setDuration(prev => prev = Math.floor(audioPlayer.current.duration));
    });
  }, [audioPlayer === null || audioPlayer === void 0 ? void 0 : (_audioPlayer$current = audioPlayer.current) === null || _audioPlayer$current === void 0 ? void 0 : _audioPlayer$current.loadedmetadata, audioPlayer === null || audioPlayer === void 0 ? void 0 : (_audioPlayer$current2 = audioPlayer.current) === null || _audioPlayer$current2 === void 0 ? void 0 : _audioPlayer$current2.readyState]);
  (0,external_react_.useEffect)(() => {
    if (currentTime !== 0 && currentTime == duration) {
      handlePlay();
      audioPlayer.current.currentTime = 0;
      setPosition(0);
    }
  }, [currentTime]);

  const calculateTime = sec => {
    let min = Math.floor(sec / 60);
    let secs = sec % 60;
    return `${min < 10 ? '0' : ''}${min}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handlePlay = () => {
    setIsPlaying(!isPlaying);

    if (isPlaying) {
      audioPlayer.current.pause();
    } else {
      audioPlayer.current.play();
    }
  };

  const back = () => {
    const back = audioPlayer.current.currentTime - 10;
    audioPlayer.current.currentTime = back;
    setPosition(back);
  };

  const forward = () => {
    const forward = audioPlayer.current.currentTime + 10;
    audioPlayer.current.currentTime = forward;
    setPosition(forward);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: ` ${isVideo ? "hidden" : "block"} w-full h-[300px] md:h-[350px] relative text-white/90 bg-black flex items-center justify-center`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex  items-center justify-center w-[200px] h-[150px] md:w-[250px] md:h-[150px]  bg-primary-dark",
      children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "text-center  uppercase font-medium px-1 text-lg md:text-2xl",
        children: title
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("audio", {
      ref: audioPlayer,
      src: audioLink,
      onCanPlay: () => {
        setIsLoading(prev => prev = false);
      }
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "absolute w-full max-w-lg mx-auto flex items-center justify-between px-3 md:px-0",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        onClick: () => back(),
        className: "flex items-center text-gray-300 space-x-1 outline-none",
        children: [/*#__PURE__*/jsx_runtime_.jsx((ArrowBack_default()), {
          className: "  cursor-pointer !text-2xl"
        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-xs",
          children: "10s"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        children: isPlaying ? /*#__PURE__*/jsx_runtime_.jsx((PauseCircleOutline_default()), {
          onClick: handlePlay,
          className: "  cursor-pointer text-gray-600/70 md:text-gray-700/70  !text-6xl"
        }) : /*#__PURE__*/jsx_runtime_.jsx((PlayCircleOutline_default()), {
          onClick: handlePlay,
          className: "  cursor-pointer text-gray-600/70 md:text-gray-700/70  !text-6xl"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        onClick: () => forward(),
        className: "flex items-center text-gray-300 space-x-1 outline-none",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-xs",
          children: "10s"
        }), /*#__PURE__*/jsx_runtime_.jsx((ArrowForward_default()), {
          className: "  cursor-pointer  !text-2xl"
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "absolute bottom-3 md:bottom-5 px-2 md:px-0 max-w-lg flex w-full items-center space-x-2 md:space-x-4",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex !items-center w-full space-x-4 ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-xs font-light",
          children: calculateTime(currentTime)
        }), /*#__PURE__*/jsx_runtime_.jsx((Slider_default()), {
          "aria-label": "time-indicator",
          value: position,
          min: 0,
          step: 1,
          max: duration,
          className: "!text-gray-300",
          onChange: (_, value) => {
            setPosition(value);
            audioPlayer.current.currentTime = value;
          }
        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-xs font-light",
          children: calculateTime(duration)
        })]
      })
    })]
  });
};

/* harmony default export */ const components_Audio = (Audio);
;// CONCATENATED MODULE: ./components/Video.js


const Video = ({
  isVideo,
  videoLink
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: ` ${isVideo ? "block" : "hidden"} w-full h-[300px] md:h-[350px] relative aspect-video text-white/90 bg-black flex items-center justify-center`,
    children: /*#__PURE__*/jsx_runtime_.jsx("iframe", {
      className: "absolute top-0 left-0 bottom-0 right-0 w-full h-full",
      src: videoLink,
      title: "YouTube video player",
      frameBorder: "0",
      allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
      allowFullScreen: true
    })
  });
};

/* harmony default export */ const components_Video = (Video);
;// CONCATENATED MODULE: ./components/Player.js







const Player = ({
  resource
}) => {
  const {
    0: isVideo,
    1: setIsVideo
  } = (0,external_react_.useState)(false);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "bg-[#eee]/60 sm:!pt-24 !pt-[60px]  pb-5",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "max-w-screen-sm mx-auto ",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col justify-center items-center space-y-5",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex w-full",
          children: [/*#__PURE__*/jsx_runtime_.jsx(components_Audio, {
            audioLink: resource.audioUrl,
            title: resource.title,
            isVideo: isVideo
          }), /*#__PURE__*/jsx_runtime_.jsx(components_Video, {
            videoLink: resource.youtubeLink,
            isVideo: isVideo
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center justify-center w-full",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              onClick: () => setIsVideo(false),
              className: ` ${isVideo ? "bg-none text-primary-dark" : "text-white bg-primary-dark"} uppercase text-sm  cursor-pointer py-1 px-10 border border-primary-dark `,
              children: "Audio"
            }), resource.youtubeLink && /*#__PURE__*/jsx_runtime_.jsx("h1", {
              onClick: () => setIsVideo(true),
              className: ` ${isVideo ? "text-white bg-primary-dark" : "bg-none text-primary-dark"} uppercase text-sm py-1 px-10 border cursor-pointer border-primary-dark `,
              children: "Video"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center justify-center w-full ",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: resource.audioUrl,
            download: "he turned it",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex items-center cursor-pointer space-x-1",
              children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                className: "uppercase text-sm",
                children: "Download"
              }), /*#__PURE__*/jsx_runtime_.jsx((CloudDownload_default()), {
                className: "!text-xl"
              })]
            })
          })
        })]
      })
    })
  });
};

/* harmony default export */ const components_Player = (Player);

/***/ }),

/***/ 7430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _blur__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1569);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);






const About = ({
  preacher
}) => {
  var _preacher$imageUrl;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    className: "flex flex-col w-full rounded-2xl items-center text-gray-200 justify-center bg-gray-700 space-y-5 px-4 py-5 md:p-5",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h1", {
      className: "text-sm text-gray-100 lg:text-base font-medium uppercase",
      children: "About the speaker"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-[80px] h-[80px] rounded-full float-left mr-2  relative ",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
        src: preacher === null || preacher === void 0 ? void 0 : (_preacher$imageUrl = preacher.imageUrl) === null || _preacher$imageUrl === void 0 ? void 0 : _preacher$imageUrl.url,
        className: "object-cover rounded-full w-full h-full ",
        layout: "fill",
        blurDataURL: _blur__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
        placeholder: "blur",
        alt: "logo"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h1", {
      className: "text-sm font-light uppercase",
      children: preacher.name
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("p", {
      className: "text-sm md:text-base text-gray-300 md:leading-8 font-light text-justify md:px-1",
      children: preacher.about
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);

/***/ }),

/***/ 7794:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(8319);


/***/ }),

/***/ 29:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ })

};
;