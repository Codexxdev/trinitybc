"use strict";
exports.id = 3048;
exports.ids = [3048];
exports.modules = {

/***/ 3048:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_s3_upload__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7868);
/* harmony import */ var next_s3_upload__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_s3_upload__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ButtonLoader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1947);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const AudioUploader = ({
  audioUrl,
  setAudioUrl,
  name
}) => {
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: audio,
    1: setAudio
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    uploadToS3,
    files
  } = (0,next_s3_upload__WEBPACK_IMPORTED_MODULE_1__.useS3Upload)();

  const handleFileChange = async event => {
    event.preventDefault();

    if (audio) {
      setLoading(true);
      const {
        url
      } = await uploadToS3(audio);
      setAudioUrl(url);
      setLoading(false);
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: "space-y-4 w-full",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
      className: "ml-2 text-sm uppercase",
      children: `${name ? name : "audio"} file`
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("input", {
      onChange: e => {
        setAudio(e.target.files[0]);
        setAudioUrl('');
      },
      type: "file",
      accept: "audio/*,.pdf",
      className: "block w-full text-sm text-slate-500\r file:mr-4 file:py-2 file:px-4\r file:rounded-full file:border-0\r file:text-sm file:font-semibold\r file:bg-gray-100 file:text-violet-700\r hover:file:bg-violet-100\r "
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("button", {
      onClick: handleFileChange,
      disabled: audioUrl,
      className: " disabled:bg-gray-500 text-center w-full py-2 text-white text-sm uppercase bg-violet-700 rounded-lg",
      children: audioUrl ? "uploaded" : loading ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: "flex w-full items-center space-x-2 justify-center",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_ButtonLoader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}), files.map((file, index) => {
          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
            className: "uppercase",
            children: index === 0 && Math.floor(file.progress) + "%"
          }, index);
        })]
      }) : name ? "upload bulletin" : "Upload audio"
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AudioUploader);

/***/ })

};
;