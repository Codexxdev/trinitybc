"use strict";
exports.id = 3114;
exports.ids = [3114];
exports.modules = {

/***/ 3114:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ sermons_Sermons)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/sermons/Hero.js



const Hero = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "bg-gradient-to-r from-primary-dark to-primary-light text-[white]  pt-[100px]  md:pt-[68px] ",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "container px-2 md:px-0 lg:px-[2rem] pb-16 pt-10 md:pb-36 md:pt-28  flex flex-col items-center justify-center space-y-5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "text-xl md:text-3xl  text-center uppercase font-medium",
        children: "sermons"
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "text-sm md:text-base max-w-screen-md mx-auto font-light text-center",
        children: "Access our biblical resources here at TBC. Read, Watch and Listen to sound teachings from faithful Ministers of the Gospel."
      })]
    })
  });
};

/* harmony default export */ const sermons_Hero = (Hero);
// EXTERNAL MODULE: ./components/sermons/Filter.js + 2 modules
var Filter = __webpack_require__(5727);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/icons-material/GraphicEq"
var GraphicEq_ = __webpack_require__(3042);
var GraphicEq_default = /*#__PURE__*/__webpack_require__.n(GraphicEq_);
// EXTERNAL MODULE: external "@mui/icons-material/OndemandVideo"
var OndemandVideo_ = __webpack_require__(2803);
var OndemandVideo_default = /*#__PURE__*/__webpack_require__.n(OndemandVideo_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(4146);
// EXTERNAL MODULE: ./components/common/blur.js
var common_blur = __webpack_require__(1569);
// EXTERNAL MODULE: ./components/common/Pagination.js
var Pagination = __webpack_require__(7989);
// EXTERNAL MODULE: ./redux/features/client/ministers.js
var ministers = __webpack_require__(7334);
;// CONCATENATED MODULE: ./components/sermons/List.js















const defaultImage = "https://res.cloudinary.com/dk6uhtgvo/image/upload/v1651307278/Global/sermons_nbw4cx.jpg";

const List = () => {
  const {
    0: fitlerToggle,
    1: setFilterToggle
  } = (0,external_react_.useState)(false);
  const {
    0: sortToggle,
    1: setSortToggle
  } = (0,external_react_.useState)(false);
  const {
    sermons,
    totalItems,
    resPerPage
  } = (0,external_react_redux_.useSelector)(state => state.clientSermons);
  const {
    topics,
    preachers,
    scriptures
  } = (0,external_react_redux_.useSelector)(state => state.clientSermons);
  const dispatch = (0,external_react_redux_.useDispatch)();
  const router = (0,router_.useRouter)();
  const page = Number(router.query.page) || 1;
  (0,external_react_.useEffect)(() => {
    dispatch((0,ministers/* getClientMinisters */.s)());
  }, [sermons]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: ` md:mt-10`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "container md:px-0 lg:px-[2rem]",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "hidden lg:block uppercase text-center lg:ml-3 lg:text-left text-sm font-light mb-5",
        children: `${totalItems > 1 ? totalItems + " Results" : totalItems + " Result"} - Page ${page}`
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-20 ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "lg:hidden text-center uppercase text-xs font-light ",
          children: `${totalItems > 1 ? totalItems + " Results" : totalItems + " Result"} - Page ${page} `
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "lg:col-span-7",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex flex-col mt-2 md:mt-5 space-y-3",
            children: sermons.map(sermon => {
              var _sermon$preacher, _sermon$imageUrl;

              return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: `/resources/sermons/${sermon._id}`,
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "flex py-3 hover:bg-secondary-one/20 cursor-pointer items-center space-x-2 px-3 border-b border-b-primary-black/10",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "flex flex-col w-full space-y-2",
                      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                        className: "flex space-x-1",
                        children: [/*#__PURE__*/jsx_runtime_.jsx((GraphicEq_default()), {
                          className: "text-[orange] !text-base"
                        }), /*#__PURE__*/jsx_runtime_.jsx((OndemandVideo_default()), {
                          className: "text-[red]/80 !text-base"
                        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                          className: "text-xs uppercase font-light ",
                          children: '|  ' + (0,external_date_fns_.format)(new Date(sermon.date), 'do MMM yyyy')
                        })]
                      }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                        className: " text-base md:text-lg capitalize ",
                        children: sermon.title
                      }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                        className: "font-light text-sm capitalize ",
                        children: `${sermon.book} ${sermon.chapter}:${sermon.verse}`
                      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center !mt-3 space-x-2",
                        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                          className: "h-[25px] w-[25px] rounded-full relative",
                          children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                            src: sermon.preacher.imageUrl.url,
                            className: "object-cover w-full h-full rounded-full",
                            layout: "fill",
                            blurDataURL: common_blur/* default */.Z,
                            placeholder: "blur",
                            alt: "logo"
                          })
                        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                          className: "text-sm  font-light",
                          children: (_sermon$preacher = sermon.preacher) === null || _sermon$preacher === void 0 ? void 0 : _sermon$preacher.name
                        })]
                      })]
                    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                      className: "w-[80px] h-[75px] rounded-lg  relative",
                      children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                        src: sermon !== null && sermon !== void 0 && (_sermon$imageUrl = sermon.imageUrl) !== null && _sermon$imageUrl !== void 0 && _sermon$imageUrl.url ? sermon.imageUrl.url : defaultImage,
                        className: "object-cover rounded-lg w-full h-full ",
                        layout: "fill",
                        blurDataURL: common_blur/* default */.Z,
                        placeholder: "blur",
                        alt: "logo"
                      })
                    })]
                  })
                })
              }, sermon._id);
            })
          }), totalItems > resPerPage && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex !my-10 w-full items-center justify-center",
            children: /*#__PURE__*/jsx_runtime_.jsx(Pagination/* Pagination */.t, {
              resPerPage: resPerPage,
              page: page,
              totalItems: totalItems
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: " lg:col-span-5 lg:!mt-10 order-first lg:order-last",
          children: /*#__PURE__*/jsx_runtime_.jsx(Filter/* default */.Z, {
            topics: topics,
            preachers: preachers,
            scriptures: scriptures,
            fitlerToggle: fitlerToggle,
            setFilterToggle: setFilterToggle,
            sortToggle: sortToggle,
            setSortToggle: setSortToggle
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const sermons_List = (List);
// EXTERNAL MODULE: ./redux/features/currentUser.js
var currentUser = __webpack_require__(3998);
;// CONCATENATED MODULE: ./components/sermons/Sermons.js









const Sermons = () => {
  const router = (0,router_.useRouter)();
  const dispatch = (0,external_react_redux_.useDispatch)();
  (0,external_react_.useEffect)(() => {
    dispatch((0,currentUser/* loadUser */.I)());
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "!mb-20  w-full",
    children: [/*#__PURE__*/jsx_runtime_.jsx(sermons_Hero, {}), /*#__PURE__*/jsx_runtime_.jsx(sermons_List, {})]
  });
};

/* harmony default export */ const sermons_Sermons = (Sermons);

/***/ })

};
;