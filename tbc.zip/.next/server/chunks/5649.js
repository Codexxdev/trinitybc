"use strict";
exports.id = 5649;
exports.ids = [5649,1569];
exports.modules = {

/***/ 1569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const blur = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAAKAAoDASIAAhEBAxEB/8QAFwAAAwEAAAAAAAAAAAAAAAAAAAMGB//EABQBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAdDRKg//xAAYEAADAQEAAAAAAAAAAAAAAAABAgMQE//aAAgBAQABBQJpyA4Jv//EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oACAEDAQE/Aa//xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAgBAgEBPwGP/8QAGxAAAAcBAAAAAAAAAAAAAAAAAAECEDEzkqL/2gAIAQEABj8CrRkRyT//xAAbEAACAQUAAAAAAAAAAAAAAAABEQAQIWGR4f/aAAgBAQABPyFiOpG3UY4V/9oADAMBAAIAAwAAABAD/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAERMf/aAAgBAwEBPxBRh//EABcRAAMBAAAAAAAAAAAAAAAAAAABETH/2gAIAQIBAT8Qdaf/xAAcEAAABgMAAAAAAAAAAAAAAAAAAREhQVEQMWH/2gAIAQEAAT8QmtEUBLbaF13QxzL/2Q==";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blur);

/***/ }),

/***/ 5447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5675);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common_About__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7430);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const Body = ({
  resource
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    className: "max-w-screen-sm mx-auto px-2 md:px-0 ",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: "flex flex-col space-y-3 w-full",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
        className: "text-xs text-center font-light uppercase",
        children: (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(new Date(resource.date), 'do MMM yyyy')
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
        className: "text-xl md:text-3xl font-medium text-center uppercase",
        children: resource.title
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: "flex flex-col font-light uppercase text-sm space-y-2 justify-center",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          className: "flex items-center space-x-2 justify-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
            className: " ",
            children: "Scripture:"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
            className: " ",
            children: `${resource.book} ${resource.chapter}:${resource.verse}`
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          className: "flex items-center space-x-2 justify-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
            className: " ",
            children: "Speaker:"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
            className: " ",
            children: resource.preacher.name
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
        className: "flex flex-col !mt-10 !mb-12 space-y-3",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h1", {
          className: "mx-1 text-sm lg:text-base uppercase",
          children: "About the message"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
          className: "md:text-lg md:leading-8 text-gray-700 font-light text-justify px-1",
          children: resource.description
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_common_About__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        preacher: resource.preacher
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Body);

/***/ })

};
;