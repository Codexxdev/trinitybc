"use strict";
exports.id = 9198;
exports.ids = [9198];
exports.modules = {

/***/ 223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$W": () => (/* binding */ getBibleStudyDetails),
/* harmony export */   "GV": () => (/* binding */ updateBibleStudy),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getBibleStudyDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`bibleStudy/getBibleStudyDetails`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/biblestudy/${id}`);
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const updateBibleStudy = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`bibleStudy/updateBibleStudy`, async ({
  id,
  title,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/biblestudy/${id}`, {
      title,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const bibleStudySlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'bibleStudy',
  initialState: {
    loading: false,
    bibleStudy: null,
    message: null
  },
  reducers: {},
  extraReducers: {
    [getBibleStudyDetails.pending]: state => {
      state.loading = true;
    },
    [getBibleStudyDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.bibleStudy = payload.bibleStudy;
    },
    [getBibleStudyDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateBibleStudy.pending]: state => {
      state.loading = true;
    },
    [updateBibleStudy.fulfilled]: state => {
      state.loading = false;
    },
    [updateBibleStudy.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
}); // export const { deleteOne, addbibleStudy } = bibleStudySlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (bibleStudySlice.reducer);

/***/ }),

/***/ 1810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q1": () => (/* binding */ getSermonDetails),
/* harmony export */   "yh": () => (/* binding */ updateSermon),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getSermonDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermon/getSermonDetails`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/sermons/${id}`);
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const updateSermon = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermon/updateSermon`, async ({
  id,
  title,
  category,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/sermons/${id}`, {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const sermonSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'sermon',
  initialState: {
    loading: false,
    sermon: null,
    message: null
  },
  reducers: {},
  extraReducers: {
    [getSermonDetails.pending]: state => {
      state.loading = true;
    },
    [getSermonDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.sermon = payload.sermon;
    },
    [getSermonDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateSermon.pending]: state => {
      state.loading = true;
    },
    [updateSermon.fulfilled]: state => {
      state.loading = false;
    },
    [updateSermon.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
}); // export const { deleteOne, addsermon } = sermonSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sermonSlice.reducer);

/***/ })

};
;