"use strict";
exports.id = 2993;
exports.ids = [2993];
exports.modules = {

/***/ 2993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ postCreateUser),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const postCreateUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`user/postCreateUser`, async ({
  name,
  email,
  password
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/auth/register`, {
      name,
      email,
      password
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const addUserSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'addUser',
  initialState: {
    loading: true,
    message: null,
    error: null
  },
  reducers: {},
  extraReducers: {
    [postCreateUser.pending]: state => {
      state.loading = true;
    },
    [postCreateUser.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload.message;
    },
    [postCreateUser.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.error = payload;
    }
  }
}); // export const { deleteOne, addProduct } = addUserSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addUserSlice.reducer);

/***/ })

};
;