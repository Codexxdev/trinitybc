"use strict";
exports.id = 9696;
exports.ids = [9696];
exports.modules = {

/***/ 9696:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "nd": () => (/* binding */ deleteEmail),
  "Ii": () => (/* binding */ getAdminEmails),
  "Dc": () => (/* binding */ postEmail)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/Email.js

const emailSchema = new (external_mongoose_default()).Schema({
  email: {
    type: String,
    required: true,
    unique: [true, 'Email already exists']
  },
  date: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const Email = ((external_mongoose_default()).models.Email || external_mongoose_default().model('Email', emailSchema));
// EXTERNAL MODULE: external "express-async-handler"
var external_express_async_handler_ = __webpack_require__(2776);
var external_express_async_handler_default = /*#__PURE__*/__webpack_require__.n(external_express_async_handler_);
// EXTERNAL MODULE: ./middleware/errorHandler.js
var errorHandler = __webpack_require__(21);
;// CONCATENATED MODULE: ./controllers/emailController.js


 // post email
// post =>  /api/admin/email

const postEmail = external_express_async_handler_default()(async (req, res, next) => {
  const email = await Email.create(req.body);
  res.status(200).json({
    success: "true",
    message: "email created successfully"
  });
}); // create Email
// get =>  /api/admin/Email

const getAdminEmails = external_express_async_handler_default()(async (req, res, next) => {
  try {
    const emails = await Email.find({});
    res.status(200).json({
      success: "true",
      emails
    });
  } catch (error) {
    next(error);
  }
}); // Delete email
// Delete => api/admin/email/:id

const deleteEmail = external_express_async_handler_default()(async (req, res, next) => {
  const email = await Email.findById(req.query.id);

  if (!email) {
    return next(new errorHandler/* default */.Z('email not found with this ID', 404));
  } else {
    await email.remove();
    res.status(200).json({
      success: "true",
      message: "Email Deleted"
    });
  }
});


/***/ })

};
;