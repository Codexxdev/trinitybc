"use strict";
exports.id = 5152;
exports.ids = [5152];
exports.modules = {

/***/ 3312:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ postAddBibleStudy),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const postAddBibleStudy = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`addBibleStudy/postAddBibleStudy`, async ({
  title,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/admin/biblestudy`, {
      title,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const addBibleStudySlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'addBibleStudy',
  initialState: {
    loading: false,
    message: null,
    error: null
  },
  reducers: {},
  extraReducers: {
    [postAddBibleStudy.pending]: state => {
      state.loading = true;
    },
    [postAddBibleStudy.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload.message;
    },
    [postAddBibleStudy.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.error = payload;
    }
  }
}); // export const { deleteOne, addProduct } = addBibleStudySlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addBibleStudySlice.reducer);

/***/ }),

/***/ 2769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ postCreateSermon),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const postCreateSermon = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`user/postCreateSermon`, async ({
  title,
  category,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/admin/sermons`, {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const addSermonSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'addSermon',
  initialState: {
    loading: true,
    message: null,
    error: null
  },
  reducers: {},
  extraReducers: {
    [postCreateSermon.pending]: state => {
      state.loading = true;
    },
    [postCreateSermon.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload.message;
    },
    [postCreateSermon.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.error = payload;
    }
  }
}); // export const { deleteOne, addProduct } = addSermonSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addSermonSlice.reducer);

/***/ })

};
;