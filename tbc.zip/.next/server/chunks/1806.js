"use strict";
exports.id = 1806;
exports.ids = [1806];
exports.modules = {

/***/ 1806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "al": () => (/* binding */ getMinisterDetails),
/* harmony export */   "lf": () => (/* binding */ updateMinister),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getMinisterDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`minister/getMinisterDetails`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/ministers/${id}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const updateMinister = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`minister/updateMinister`, async ({
  id,
  name,
  role,
  about,
  imageUrl
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/ministers/${id}`, {
      name,
      role,
      about,
      imageUrl
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const ministerSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'minister',
  initialState: {
    loading: false,
    minister: null,
    message: null
  },
  reducers: {},
  extraReducers: {
    [getMinisterDetails.pending]: state => {
      state.loading = true;
    },
    [getMinisterDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.minister = payload.minister;
    },
    [getMinisterDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateMinister.pending]: state => {
      state.loading = true;
    },
    [updateMinister.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
    },
    [updateMinister.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
}); // export const { deleteOne, addminister } = ministerSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ministerSlice.reducer);

/***/ })

};
;