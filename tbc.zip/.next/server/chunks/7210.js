"use strict";
exports.id = 7210;
exports.ids = [7210];
exports.modules = {

/***/ 7210:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redux_features_sermons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(272);
/* harmony import */ var _redux_features_series__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9884);
/* harmony import */ var _redux_features_conferences__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4620);
/* harmony import */ var _redux_features_bibleStudies__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9119);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);










let grid = [{
  topic: "sermon",
  number: 15,
  path: "/sermon",
  id: 1
}, {
  topic: "preaching series",
  number: 20,
  path: "/series",
  id: 2
}, {
  topic: "conference messages",
  number: 30,
  path: "/conference",
  id: 3
}, {
  topic: "bible study",
  number: 40,
  path: "/biblestudy",
  id: 4
}];

const Resources = ({
  children
}) => {
  const {
    0: active,
    1: setActive
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("sermon");
  const {
    0: noOfSermons,
    1: setNoOfSermons
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: noOfSeries,
    1: setNoOfSeries
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: noOfConference,
    1: setNoOfConference
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: noOfStudy,
    1: setNoOfStudy
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
  const page = Number(router.query.page) || 1;
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (router.route === "/admin/resources") {
      router.push("/admin/resources/sermon");
    }

    dispatch((0,_redux_features_sermons__WEBPACK_IMPORTED_MODULE_3__/* .getAdminSermons */ .eU)({
      page
    })).then(result => {
      if (result.error) {
        console.log(result.error);
      } else {
        setNoOfSermons(result.payload.totalItems);
      }
    });
    dispatch((0,_redux_features_series__WEBPACK_IMPORTED_MODULE_4__/* .getAdminSeries */ .hD)()).then(result => {
      if (result.error) {
        console.log(result.error);
      } else {
        setNoOfSeries(result.payload.series.length);
      }
    });
    dispatch((0,_redux_features_conferences__WEBPACK_IMPORTED_MODULE_5__/* .getAdminConference */ .zC)()).then(result => {
      if (result.error) {
        toast.error(result.error);
      } else {
        setNoOfConference(result.payload.conferences.length);
      }
    });
    dispatch((0,_redux_features_bibleStudies__WEBPACK_IMPORTED_MODULE_6__/* .getAdminBibleStudies */ .Fh)()).then(result => {
      if (result.error) {
        console.log(result.error);
      } else {
        setNoOfStudy(result.payload.bibleStudies.length);
      }
    });
  }, [dispatch, page]);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    className: "flex w-full flex-col space-y-10 mb-3 p-4",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: "flex justify-between items-center",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        onClick: () => router.push(`/admin/resources/sermon`),
        className: ` ${router.pathname.includes("/sermon") ? "bg-gray-800" : "bg-white"}
                flex flex-col hover:scale-105 hover:shadow-2xl w-[180px] h-[90px] items-center shadow-lg cursor-pointer justify-center rounded-2xl `,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `${router.pathname.includes("/sermon") ? "text-gray-200" : "text-primary-dark"} uppercase font-medium text-xl`,
          children: noOfSermons
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `uppercase !text-primary-light font-medium text-xs`,
          children: "stand-alone sermons"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        onClick: () => router.push(`/admin/resources/series`),
        className: ` ${router.pathname.includes("/series") ? "bg-gray-800" : "bg-white"}
                flex flex-col hover:scale-105 hover:shadow-2xl w-[180px] h-[90px] items-center shadow-lg cursor-pointer justify-center rounded-2xl `,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `${router.pathname.includes("/series") ? "text-gray-200" : "text-primary-dark"} uppercase font-medium text-xl`,
          children: noOfSeries
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `uppercase !text-primary-light font-medium text-xs`,
          children: "preaching series"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        onClick: () => router.push(`/admin/resources/conference`),
        className: ` ${router.pathname.includes("/conference") ? "bg-gray-800" : "bg-white"}
                flex flex-col hover:scale-105 hover:shadow-2xl w-[180px] h-[90px] items-center shadow-lg cursor-pointer justify-center rounded-2xl `,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `${router.pathname.includes("/conference") ? "text-gray-200" : "text-primary-dark"} uppercase font-medium text-xl`,
          children: noOfConference
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `uppercase !text-primary-light font-medium text-xs`,
          children: "conference messages"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        onClick: () => router.push(`/admin/resources/biblestudy`),
        className: ` ${router.pathname.includes("/biblestudy") ? "bg-gray-800" : "bg-white"}
                flex flex-col hover:scale-105 hover:shadow-2xl w-[180px] h-[90px] items-center shadow-lg cursor-pointer justify-center rounded-2xl `,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `${router.pathname.includes("/biblestudy") ? "text-gray-200" : "text-primary-dark"} uppercase font-medium text-xl`,
          children: noOfStudy
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h1", {
          className: `uppercase !text-primary-light font-medium text-xs`,
          children: "bible study"
        })]
      })]
    }), children]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Resources);

/***/ })

};
;