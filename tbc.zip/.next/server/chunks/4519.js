"use strict";
exports.id = 4519;
exports.ids = [4519];
exports.modules = {

/***/ 9119:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fh": () => (/* binding */ getAdminBibleStudies),
/* harmony export */   "so": () => (/* binding */ postDeleteBibleStudy),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminBibleStudies = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`bibleStudies/getAdminBibleStudies`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/biblestudy`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteBibleStudy = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`bibleStudies/postDeleteBibleStudy`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/biblestudy/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const bibleStudiesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'bibleStudies',
  initialState: {
    loading: true,
    bibleStudies: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.bibleStudies.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminBibleStudies.pending]: state => {
      state.loading = true;
    },
    [getAdminBibleStudies.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.bibleStudies = payload.bibleStudies;
    },
    [getAdminBibleStudies.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteBibleStudy.pending]: state => {
      state.loading = true;
    },
    [postDeleteBibleStudy.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteBibleStudy.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = bibleStudiesSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (bibleStudiesSlice.reducer);

/***/ }),

/***/ 2961:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kj": () => (/* binding */ getConferenceDetails),
/* harmony export */   "Fn": () => (/* binding */ updateConference),
/* harmony export */   "$V": () => (/* binding */ postConferenceSermons),
/* harmony export */   "R1": () => (/* binding */ postUpdateConferenceSermons),
/* harmony export */   "id": () => (/* binding */ postDeleteConferenceSermon),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getConferenceDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/getConferenceDetails`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/conference/${id}`);
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const updateConference = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/updateConference`, async ({
  id,
  title,
  description,
  imageUrl,
  startDate,
  endDate
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/conference/${id}`, {
      title,
      description,
      imageUrl,
      startDate,
      endDate
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postConferenceSermons = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/postConferenceSermons`, async ({
  id,
  title,
  category,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/conference?id=${id}`, {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postUpdateConferenceSermons = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/postUpdateConferenceSermons`, async ({
  id,
  sermonId,
  title,
  category,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/admin/conference/${id}?sermonId=${sermonId}`, {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteConferenceSermon = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/postDeleteConferenceSermon`, async ({
  id,
  sermonId,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/conference?id=${id}&sermonId=${sermonId}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const conferenceSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'conference',
  initialState: {
    loading: false,
    conference: null,
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      var _state$conference$ser;

      (_state$conference$ser = state.conference.sermons) === null || _state$conference$ser === void 0 ? void 0 : _state$conference$ser.splice(payload, 1);
    }
  },
  extraReducers: {
    [getConferenceDetails.pending]: state => {
      state.loading = true;
    },
    [getConferenceDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.conference = payload.conference;
    },
    [getConferenceDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateConference.pending]: state => {
      state.loading = true;
    },
    [updateConference.fulfilled]: state => {
      state.loading = false;
    },
    [updateConference.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postConferenceSermons.pending]: state => {
      state.loading = true;
    },
    [postConferenceSermons.fulfilled]: state => {
      state.loading = false;
    },
    [postConferenceSermons.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postUpdateConferenceSermons.pending]: state => {
      state.loading = true;
    },
    [postUpdateConferenceSermons.fulfilled]: state => {
      state.loading = false;
    },
    [postUpdateConferenceSermons.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteConferenceSermon.pending]: state => {
      state.loading = true;
    },
    [postDeleteConferenceSermon.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteConferenceSermon.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = conferenceSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (conferenceSlice.reducer);

/***/ }),

/***/ 4620:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "zC": () => (/* binding */ getAdminConference),
/* harmony export */   "dF": () => (/* binding */ postDeleteConference),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminConference = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/getAdminConference`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/conference`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteConference = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/postDeleteConference`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/conference/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const conferenceSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'conference',
  initialState: {
    loading: true,
    conferences: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.conferences.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminConference.pending]: state => {
      state.loading = true;
    },
    [getAdminConference.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.conferences = payload.conferences;
    },
    [getAdminConference.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteConference.pending]: state => {
      state.loading = true;
    },
    [postDeleteConference.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteConference.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = conferenceSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (conferenceSlice.reducer);

/***/ }),

/***/ 1868:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ii": () => (/* binding */ getAdminEmails),
/* harmony export */   "bl": () => (/* binding */ postDeleteEmail),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminEmails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`email/getAdminEmails`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/email`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteEmail = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`email/postDeleteEmail`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/email/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const emailSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'email',
  initialState: {
    loading: true,
    emails: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.emails.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminEmails.pending]: state => {
      state.loading = true;
    },
    [getAdminEmails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.emails = payload.emails;
    },
    [getAdminEmails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteEmail.pending]: state => {
      state.loading = true;
    },
    [postDeleteEmail.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteEmail.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = emailSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (emailSlice.reducer);

/***/ }),

/***/ 3122:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EY": () => (/* binding */ getEvent),
/* harmony export */   "eJ": () => (/* binding */ updateEvent),
/* harmony export */   "t": () => (/* binding */ postDeleteEventSession),
/* harmony export */   "X$": () => (/* binding */ setEventSessions),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getEvent = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`event/getEvent`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/event/${id}`);
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const updateEvent = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`event/updateEvent`, async ({
  id,
  title,
  type,
  description,
  startDate,
  endDate,
  imageUrl,
  sessions
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/event/${id}`, {
      title,
      type,
      description,
      startDate,
      endDate,
      imageUrl,
      sessions
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteEventSession = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`series/postDeleteEventSession`, async ({
  id,
  sessionId,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/event?id=${id}&sessionId=${sessionId}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const eventSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'event',
  initialState: {
    loading: false,
    event: null,
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      var _state$event$sessions;

      (_state$event$sessions = state.event.sessions) === null || _state$event$sessions === void 0 ? void 0 : _state$event$sessions.splice(payload, 1);
    },
    setEventSessions: (state, {
      payload
    }) => {
      var _state$event, _state$event$sessions2;

      const inArray = (_state$event = state.event) === null || _state$event === void 0 ? void 0 : (_state$event$sessions2 = _state$event.sessions) === null || _state$event$sessions2 === void 0 ? void 0 : _state$event$sessions2.find(session => session._id === (payload === null || payload === void 0 ? void 0 : payload._id));

      if (inArray) {
        var _state$event2, _state$event2$session;

        (_state$event2 = state.event) === null || _state$event2 === void 0 ? void 0 : (_state$event2$session = _state$event2.sessions) === null || _state$event2$session === void 0 ? void 0 : _state$event2$session.map(session => {
          if (session._id === payload._id) {
            session.topic = payload.topic;
            session.preacher._id = payload.preacher;
            session.description = payload.description;
            session.startTime = payload.startTime;
            session.endTime = payload.endTime;
          }
        });
      } else {
        var _state$event3, _state$event3$session;

        (_state$event3 = state.event) === null || _state$event3 === void 0 ? void 0 : (_state$event3$session = _state$event3.sessions) === null || _state$event3$session === void 0 ? void 0 : _state$event3$session.push(payload);
      }
    }
  },
  extraReducers: {
    [getEvent.pending]: state => {
      state.loading = true;
    },
    [getEvent.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.event = payload.event;
    },
    [getEvent.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateEvent.pending]: state => {
      state.loading = true;
    },
    [updateEvent.fulfilled]: state => {
      state.loading = false;
    },
    [updateEvent.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteEventSession.pending]: state => {
      state.loading = true;
    },
    [postDeleteEventSession.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteEventSession.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  setEventSessions,
  deleteOne
} = eventSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (eventSlice.reducer);

/***/ }),

/***/ 4825:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GH": () => (/* binding */ getAdminEvents),
/* harmony export */   "S5": () => (/* binding */ postDeleteEvent),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminEvents = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`events/getAdminEvents`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/event`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteEvent = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`events/postDeleteEvent`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/event/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const eventsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'events',
  initialState: {
    loading: true,
    events: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.events.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminEvents.pending]: state => {
      state.loading = true;
    },
    [getAdminEvents.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.events = payload.events;
    },
    [getAdminEvents.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteEvent.pending]: state => {
      state.loading = true;
    },
    [postDeleteEvent.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteEvent.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = eventsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (eventsSlice.reducer);

/***/ }),

/***/ 7422:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Yy": () => (/* binding */ getAdminMinisters),
/* harmony export */   "Mb": () => (/* binding */ postDeleteMinister),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminMinisters = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`ministers/getAdminMinisters`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/ministers`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteMinister = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`ministers/postDeleteMinister`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/ministers/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const ministersSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'ministers',
  initialState: {
    loading: true,
    ministers: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.ministers.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminMinisters.pending]: state => {
      state.loading = true;
    },
    [getAdminMinisters.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.ministers = payload.ministers;
    },
    [getAdminMinisters.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteMinister.pending]: state => {
      state.loading = true;
    },
    [postDeleteMinister.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
    },
    [postDeleteMinister.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = ministersSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ministersSlice.reducer);

/***/ }),

/***/ 2268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tq": () => (/* binding */ getAdminNews),
/* harmony export */   "Df": () => (/* binding */ postDeleteNews),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminNews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`news/getAdminNews`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/news`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteNews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`news/postDeleteNews`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/news/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const newsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'news',
  initialState: {
    loading: true,
    news: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.news.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminNews.pending]: state => {
      state.loading = true;
    },
    [getAdminNews.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.news = payload.news;
    },
    [getAdminNews.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteNews.pending]: state => {
      state.loading = true;
    },
    [postDeleteNews.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteNews.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = newsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (newsSlice.reducer);

/***/ }),

/***/ 5460:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EC": () => (/* binding */ getAdminRegisters),
/* harmony export */   "yu": () => (/* binding */ postDeleteRegister),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminRegisters = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`register/getAdminRegisters`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/register`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteRegister = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`register/postDeleteRegister`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/register/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const registerSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'register',
  initialState: {
    loading: true,
    registers: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.registers.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminRegisters.pending]: state => {
      state.loading = true;
    },
    [getAdminRegisters.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.registers = payload.registers;
    },
    [getAdminRegisters.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteRegister.pending]: state => {
      state.loading = true;
    },
    [postDeleteRegister.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteRegister.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = registerSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (registerSlice.reducer);

/***/ }),

/***/ 9884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hD": () => (/* binding */ getAdminSeries),
/* harmony export */   "TH": () => (/* binding */ postDeleteSeries),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminSeries = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`series/getAdminSeries`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/series`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteSeries = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`series/postDeleteSeries`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/series/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const seriesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'series',
  initialState: {
    loading: true,
    series: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.series.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminSeries.pending]: state => {
      state.loading = true;
    },
    [getAdminSeries.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.series = payload.series;
    },
    [getAdminSeries.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteSeries.pending]: state => {
      state.loading = true;
    },
    [postDeleteSeries.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteSeries.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = seriesSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (seriesSlice.reducer);

/***/ }),

/***/ 228:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Zy": () => (/* binding */ getSeriesDetails),
/* harmony export */   "rd": () => (/* binding */ updateSeries),
/* harmony export */   "Vy": () => (/* binding */ postSermonSeries),
/* harmony export */   "lw": () => (/* binding */ postUpdateSeriesSermon),
/* harmony export */   "TC": () => (/* binding */ postDeleteSeriesSermon),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getSeriesDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`seriesDetails/getSeriesDetails`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/series/${id}`);
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const updateSeries = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`seriesDetails/updateSeries`, async ({
  id,
  title,
  description,
  imageUrl
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/series/${id}`, {
      title,
      description,
      imageUrl
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postSermonSeries = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`seriesDetails/postSermonSeries`, async ({
  id,
  title,
  category,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/series?id=${id}`, {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postUpdateSeriesSermon = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`seriesDetails/postUpdateSeriesSermon`, async ({
  id,
  sermonId,
  title,
  category,
  topic,
  preacher,
  book,
  chapter,
  verse,
  date,
  description,
  imageUrl,
  audioUrl,
  youtubeLink
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/admin/series/${id}?sermonId=${sermonId}`, {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteSeriesSermon = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`series/postDeleteSeriesSermon`, async ({
  id,
  sermonId,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/series?id=${id}&sermonId=${sermonId}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const seriesDetailsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'seriesDetails',
  initialState: {
    loading: false,
    seriesDetails: null,
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      var _state$seriesDetails$;

      (_state$seriesDetails$ = state.seriesDetails.sermons) === null || _state$seriesDetails$ === void 0 ? void 0 : _state$seriesDetails$.splice(payload, 1);
    }
  },
  extraReducers: {
    [getSeriesDetails.pending]: state => {
      state.loading = true;
    },
    [getSeriesDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.seriesDetails = payload.series;
    },
    [getSeriesDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateSeries.pending]: state => {
      state.loading = true;
    },
    [updateSeries.fulfilled]: state => {
      state.loading = false;
    },
    [updateSeries.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postSermonSeries.pending]: state => {
      state.loading = true;
    },
    [postSermonSeries.fulfilled]: state => {
      state.loading = false;
    },
    [postSermonSeries.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postUpdateSeriesSermon.pending]: state => {
      state.loading = true;
    },
    [postUpdateSeriesSermon.fulfilled]: state => {
      state.loading = false;
    },
    [postUpdateSeriesSermon.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteSeriesSermon.pending]: state => {
      state.loading = true;
    },
    [postDeleteSeriesSermon.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteSeriesSermon.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = seriesDetailsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (seriesDetailsSlice.reducer);

/***/ }),

/***/ 272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "eU": () => (/* binding */ getAdminSermons),
/* harmony export */   "aU": () => (/* binding */ postDeleteSermon),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminSermons = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermons/getAdminSermons`, async ({
  page
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/sermons?page=${page}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteSermon = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermons/postDeleteSermon`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/sermons/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const sermonsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'sermons',
  initialState: {
    loading: true,
    sermons: [],
    resPerPage: 0,
    totalItems: 0,
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.sermons.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminSermons.pending]: state => {
      state.loading = true;
    },
    [getAdminSermons.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.sermons = payload.sermons;
      state.resPerPage = payload.resPerPage;
      state.totalItems = payload.totalItems;
    },
    [getAdminSermons.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteSermon.pending]: state => {
      state.loading = true;
    },
    [postDeleteSermon.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteSermon.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = sermonsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sermonsSlice.reducer);

/***/ }),

/***/ 8797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ks": () => (/* binding */ getAdminServices),
/* harmony export */   "Mf": () => (/* binding */ postDeleteService),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export deleteOne */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getAdminServices = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`services/getAdminServices`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/service`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const postDeleteService = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`services/postDeleteService`, async ({
  id,
  index
}, {
  dispatch,
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default()["delete"](`/api/admin/service/${id}`);
    dispatch(deleteOne(index));
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const servicesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'services',
  initialState: {
    loading: true,
    services: [],
    message: null
  },
  reducers: {
    deleteOne: (state, {
      payload
    }) => {
      state.services.splice(payload, 1);
    }
  },
  extraReducers: {
    [getAdminServices.pending]: state => {
      state.loading = true;
    },
    [getAdminServices.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.services = payload.services;
    },
    [getAdminServices.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [postDeleteService.pending]: state => {
      state.loading = true;
    },
    [postDeleteService.fulfilled]: state => {
      state.loading = false;
    },
    [postDeleteService.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
const {
  deleteOne
} = servicesSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (servicesSlice.reducer);

/***/ })

};
;