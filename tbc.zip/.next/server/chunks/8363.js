"use strict";
exports.id = 8363;
exports.ids = [8363];
exports.modules = {

/***/ 8363:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "yM": () => (/* binding */ createEvent),
/* harmony export */   "Mi": () => (/* binding */ getAdminEvent),
/* harmony export */   "Bt": () => (/* binding */ deleteEvent),
/* harmony export */   "EY": () => (/* binding */ getEvent),
/* harmony export */   "eJ": () => (/* binding */ updateEvent),
/* harmony export */   "zF": () => (/* binding */ deleteEventSession),
/* harmony export */   "Lj": () => (/* binding */ getEventDetails),
/* harmony export */   "vw": () => (/* binding */ getEvents)
/* harmony export */ });
/* harmony import */ var _models_Event__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1730);
/* harmony import */ var _models_Ministers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3373);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3518);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(cloudinary__WEBPACK_IMPORTED_MODULE_3__);



 // import ErrorHandler from "../middleware/errorHandler"

cloudinary__WEBPACK_IMPORTED_MODULE_3___default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // get client events
// get => /api/client/event

const getEvents = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res) => {
  const {
    month,
    next
  } = req.query;
  const query = {};

  if (month) {
    query.startDate = {
      $gte: month
    };
  }

  if (next) {
    query.endDate = {
      $lte: next
    };
  }

  const allEvents = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find(query).sort('startDate').populate({
    path: 'sessions.preacher',
    select: "imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  const events = allEvents.filter(event => new Date(event.endDate) > new Date());
  const defaultEvent = allEvents[allEvents.length - 1];
  res.status(200).json({
    success: "true",
    events,
    defaultEvent
  });
}); // get client event detail
// get => /api/client/event/:id

const getEventDetails = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const event = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'sessions.preacher',
    select: "name about imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    event
  });
}); // create event
// post =>  /api/admin/event

const createEvent = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const event = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create(req.body);
  res.status(200).json({
    success: "true",
    message: "Event created successfully"
  });
}); // get Event
// get =>  /api/admin/Event

const getAdminEvent = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const events = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort({
    startDate: 1
  }).populate({
    path: 'sessions.preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    events
  });
}); // Delete event
// Delete => api/admin/event/:id

const deleteEvent = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const event = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!event) {// return next(new ErrorHandler('Event not found with this ID', 404))
  } else {
    await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(event.imageUrl.public_id);
    await event.remove();
    res.status(200).json({
      success: "true",
      message: "event Deleted"
    });
  }
}); // get Event
// get => api/event/:id

const getEvent = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const event = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'sessions.preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });

  if (!event) {// return next(new ErrorHandler('Event not found with this ID', 404))
  } else {
    res.status(200).json({
      success: "true",
      event
    });
  }
}); // update Event
// put => api/events/:id

const updateEvent = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const event = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!event) {// return next(new ErrorHandler('Event not found with this ID', 404))
  } else {
    const {
      title,
      type,
      description,
      startDate,
      endDate,
      imageUrl,
      sessions
    } = req.body;
    event.title = title;
    event.type = type;
    event.description = description;
    event.startDate = startDate;
    event.endDate = endDate;
    event.sessions = sessions;

    if (event.imageUrl.public_id && event.imageUrl.public_id !== imageUrl.public_id) {
      await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(event.imageUrl.public_id);
      event.imageUrl = imageUrl;
    }

    await event.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
}); // Delete Event sermon
// Delete => api/admin/event/:id

const deleteEventSession = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    sessionId,
    id
  } = req.query;
  const event = await _models_Event__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(id);

  if (!event) {// return next(new ErrorHandler('Event not found with this ID', 404))
  } else {
    const updatedEventSessions = event.sessions.filter(session => session._id.toString() !== sessionId.toString());
    event.sessions = updatedEventSessions;
    await event.save();
    res.status(200).json({
      success: "true",
      message: "Event Session Deleted"
    });
  }
});


/***/ }),

/***/ 1730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const eventSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  title: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  sessions: [{
    day: {
      type: String,
      required: true
    },
    topic: {
      type: String,
      required: true
    },
    preacher: {
      type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.ObjectId),
      ref: 'minister'
    },
    description: {
      type: String,
      required: true
    },
    startTime: {
      type: Date,
      required: true
    },
    endTime: {
      type: Date,
      required: true
    }
  }]
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Event) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Event', eventSchema));

/***/ }),

/***/ 3373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const ministerSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: [true, 'Please enter your name']
  },
  role: {
    type: String,
    default: 'minister'
  },
  about: {
    type: String,
    required: [true, "Please enter minister's about"]
  },
  imageUrl: {
    public_id: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Minister) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Minister', ministerSchema));

/***/ })

};
;