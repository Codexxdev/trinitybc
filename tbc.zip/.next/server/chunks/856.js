"use strict";
exports.id = 856;
exports.ids = [856];
exports.modules = {

/***/ 856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "co": () => (/* binding */ createBibleStudy),
/* harmony export */   "Fh": () => (/* binding */ getAdminBibleStudies),
/* harmony export */   "Fn": () => (/* binding */ deleteBibleStudy),
/* harmony export */   "bN": () => (/* binding */ getBibleStudy),
/* harmony export */   "GV": () => (/* binding */ updateBibleStudy),
/* harmony export */   "Ip": () => (/* binding */ getBibleStudies),
/* harmony export */   "$W": () => (/* binding */ getBibleStudyDetails),
/* harmony export */   "yF": () => (/* binding */ getBibleStudyFilters)
/* harmony export */ });
/* harmony import */ var _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4170);
/* harmony import */ var _models_Ministers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3373);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3518);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(cloudinary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21);





cloudinary__WEBPACK_IMPORTED_MODULE_3___default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // get client bibleStudy
// get => /api/client/biblestudy

const getBibleStudies = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    topic,
    preacher,
    scripture,
    sort
  } = req.query;
  const page = Number(req.query.page) || 1;
  const resPerPage = 10;
  const query = {};
  let sortQuery = '-date';

  if (sort) {
    sort === 'oldest' ? sortQuery = 'date' : sort === 'a-z' ? sortQuery = 'title' : sort === 'z-a' ? sortQuery = '-title' : sortQuery = '-date';
  }

  if (topic) {
    query.topic = {
      $regex: topic,
      $options: 'i'
    };
  }

  if (preacher) {
    query.preacher = preacher;
  }

  if (scripture) {
    query.book = {
      $regex: scripture,
      $options: 'i'
    };
  }

  const totalItems = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].countDocuments */ .Z.countDocuments(query);
  const bibleStudies = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find(query).sort(sortQuery).skip((page - 1) * resPerPage).limit(resPerPage).populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    bibleStudies,
    totalItems,
    resPerPage
  });
}); // get client sermons
// get => /api/client/sermons

const getBibleStudyFilters = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const biblestudies = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort('-date').populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  let dt = [];
  let dp = [];
  let ds = [];
  biblestudies.map(sermon => {
    dt.push(sermon.topic);
    dp.push(sermon.preacher.name);
    ds.push(sermon.book);
  });
  const topics = [...new Set(dt)];
  const preachers = [...new Set(dp)];
  const scriptures = [...new Set(ds)];
  res.status(200).json({
    success: "true",
    topics,
    preachers,
    scriptures
  });
}); // get client biblestudy detail
// get => /api/client/biblestudy/:id

const getBibleStudyDetails = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const bibleStudy = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'preacher',
    select: "name about imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    bibleStudy
  });
}); // create BibleStudy
// post =>  /api/admin/BibleStudy

const createBibleStudy = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const bibleStudy = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create(req.body);
  res.status(200).json({
    success: "true",
    message: "BibleStudy created successfully"
  });
}); // get BibleStudy
// get =>  /api/admin/BibleStudy

const getAdminBibleStudies = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const bibleStudies = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort({
    date: -1
  }).populate({
    path: 'preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    bibleStudies
  });
}); // Delete BibleStudy
// Delete => api/admin/BibleStudy/:id

const deleteBibleStudy = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const bibleStudy = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!bibleStudy) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('BibleStudy not found with this ID', 404));
  } else {
    if (bibleStudy.imageUrl.public_id) {
      await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(bibleStudy.imageUrl.public_id);
    }

    await bibleStudy.remove();
    res.status(200).json({
      success: "true",
      message: "BibleStudy Deleted"
    });
  }
}); // get bibleStudy
// get => api/bibleStudys/:id

const getBibleStudy = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const bibleStudy = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });

  if (!bibleStudy) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('BibleStudy not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      bibleStudy
    });
  }
}); // update bibleStudy
// put => api/bibleStudy/:id

const updateBibleStudy = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const bibleStudy = await _models_BibleStudy__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!bibleStudy) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('BibleStudy not found with this ID', 404));
  } else {
    const {
      title,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    } = req.body;
    bibleStudy.title = title;
    bibleStudy.topic = topic;
    bibleStudy.preacher = preacher;
    bibleStudy.book = book;
    bibleStudy.chapter = chapter;
    bibleStudy.verse = verse;
    bibleStudy.date = date;
    bibleStudy.description = description;
    bibleStudy.audioUrl = audioUrl;
    bibleStudy.youtubeLink = youtubeLink;

    if (imageUrl && imageUrl.public_id) {
      if (bibleStudy.imageUrl && bibleStudy.imageUrl.public_id && bibleStudy.imageUrl.public_id !== imageUrl.public_id) {
        await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(bibleStudy.imageUrl.public_id);
        bibleStudy.imageUrl = imageUrl;
      } else {
        bibleStudy.imageUrl = imageUrl;
      }
    } else {
      rbibleStudy.imageUrl = imageUrl;
    }
  }

  await bibleStudy.save({
    validateBeforeSave: false
  });
  res.status(200).json({
    success: "true"
  });
});


/***/ }),

/***/ 4170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const bibleStudySchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  title: {
    type: String,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  preacher: {
    type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.ObjectId),
    required: true,
    ref: 'minister'
  },
  book: {
    type: String,
    required: true
  },
  chapter: {
    type: String,
    required: true
  },
  verse: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  audioUrl: {
    type: String,
    required: true
  },
  youtubeLink: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.BibleStudy) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('BibleStudy', bibleStudySchema));

/***/ }),

/***/ 3373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const ministerSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: [true, 'Please enter your name']
  },
  role: {
    type: String,
    default: 'minister'
  },
  about: {
    type: String,
    required: [true, "Please enter minister's about"]
  },
  imageUrl: {
    public_id: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Minister) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Minister', ministerSchema));

/***/ })

};
;