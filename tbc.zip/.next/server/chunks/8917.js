"use strict";
exports.id = 8917;
exports.ids = [8917];
exports.modules = {

/***/ 8917:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const categories = ["select category", "christian life", "church & ministry", "family", "history & biography", "theology", "worldview & culture"];
const christianLife = ["select topic", "christian thought", "life issues", "spiritual growth"];
const churchMinistry = ["select topic", "trinity baptist church", "church leadership", "church life", "church practices", "outreach"];
const family = ["select topic", "children", "dating & singleness", "divorce and remarriage", "husband and fathers", "manhood & womanhood", "marriage", "men", "parenting", "wives and mothers", "women"];
const historyBiography = ["select topic", "auto biography", "church history"];
const theology = ["select topic", "bible studies", "general theology", "god", "jesus christ", "holy spirit", "salvation", "sin"];
const worldView = ["select topic", "apologetics", "arts & literature", "ethics", "worldview"];

const TopicInputs = ({
  setCategory,
  category,
  topic,
  setTopic
}) => {
  const {
    0: selectTopic,
    1: setSelectTopic
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['select topic']);
  const {
    0: hereCategory,
    1: setHereCategory
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: hereTopic,
    1: setHereTopic
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (category) {
      categories.map(cat => {
        if (cat === category) {
          handleTopic(cat);
          setHereCategory(cat);
        }
      });
    }

    if (topic) {
      selectTopic.map(top => {
        if (top === topic) {
          setHereTopic(top);
        }
      });
    }
  }, [category, selectTopic]);

  const handleTopic = value => {
    if (value === "christian life") {
      setSelectTopic(christianLife);
    } else if (value === "church & ministry") {
      setSelectTopic(churchMinistry);
    } else if (value === "family") {
      setSelectTopic(family);
    } else if (value === "history & biography") {
      setSelectTopic(historyBiography);
    } else if (value === "theology") {
      setSelectTopic(theology);
    } else if (value === "worldview & culture") {
      setSelectTopic(worldView);
    } else {
      setSelectTopic(['select topic']);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: "space-y-2",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "flex space-x-2 w-full items-center",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "space-y-2 w-full",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
          htmlFor: "name",
          className: "ml-2 text-sm uppercase",
          children: "Category"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("select", {
          type: "text",
          name: "category",
          className: "w-full capitalize text-gray-500 !px-1 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
          value: hereCategory,
          onChange: e => {
            setCategory(e.target.value);
            setHereCategory(e.target.value);
            handleTopic(e.target.value);
          },
          children: categories.map(category => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
            className: "capitalize",
            value: category,
            children: category
          }, category))
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "space-y-2 w-full",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
          htmlFor: "name",
          className: "ml-2 text-sm uppercase",
          children: "Topic"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("select", {
          type: "text",
          name: "topic",
          className: "w-full capitalize text-gray-500 !px-1 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
          value: hereTopic,
          onChange: e => {
            setHereTopic(e.target.value);
            setTopic(e.target.value);
          },
          children: selectTopic.map(item => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
            className: "capitalize",
            value: item,
            children: item
          }, item))
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopicInputs);

/***/ })

};
;