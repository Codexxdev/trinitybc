exports.id = 2489;
exports.ids = [2489,1569];
exports.modules = {

/***/ 6688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var _ButtonLoader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1947);
/* harmony import */ var _blur__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1569);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);








const ImageUploader = ({
  setImageUrl,
  imageUrl,
  imagePreview,
  setImagePreview,
  height
}) => {
  const {
    0: imageLoader,
    1: setImageLoader
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: image,
    1: setImage
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');

  const onChange = e => {
    setImageUrl();
    setImage(e.target.files[0]);
    const reader = new FileReader();

    reader.onload = () => {
      if (reader.readyState === 2) {
        setImagePreview(reader.result);
      }
    };

    reader.readAsDataURL(e.target.files[0]);
  };

  const onDrop = e => {
    setImageUrl();
    const droppedFile = Array.from(e.dataTransfer.files);
    setImage(droppedFile[0]);
    setImagePreview(URL.createObjectURL(droppedFile[0]));
  };

  const uploadImage = async e => {
    e.preventDefault();

    if (image) {
      try {
        setImageLoader(true);
        const data = new FormData();
        data.append("file", image);
        data.append("upload_preset", "codexx");
        data.append("cloud_name", "dk6uhtgvo");
        const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().post("https://api.cloudinary.com/v1_1/dk6uhtgvo/image/upload", data);
        const {
          url,
          public_id
        } = res.data;
        setImageUrl({
          public_id,
          url
        });
        setImageLoader(false);
      } catch (err) {
        console.log(err);
      }
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
    className: "space-y-3 w-full",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h1", {
      className: " uppercase text-sm",
      children: "Image"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("label", {
      onDragOver: e => {
        e.preventDefault();
      },
      onDragLeave: e => {
        e.preventDefault();
      },
      onDrop: e => {
        e.preventDefault();
        onDrop(e);
      },
      htmlFor: "dropzone-file",
      className: ` ${height} relative flex flex-col items-center justify-center w-full border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100`,
      children: [imagePreview ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__["default"], {
        src: imagePreview,
        className: "object-cover w-1/2 h-1/2 ",
        layout: "fill",
        blurDataURL: _blur__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
        placeholder: "blur",
        alt: "preview"
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: "flex flex-col items-center justify-center pt-5 pb-6",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
          className: "mb-2 text-sm text-gray-500 dark:text-gray-400 font-medium capitalize",
          children: "Drag 'n' Drop"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
          className: "mb-2 text-sm text-gray-500 dark:text-gray-400 capitalize",
          children: "or Click to select"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
          className: "text-xs text-gray-500 dark:text-gray-400",
          children: "PNG or JPG "
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("input", {
        onChange: onChange,
        id: "dropzone-file",
        type: "file",
        className: "hidden"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("button", {
      onClick: uploadImage,
      disabled: imageUrl,
      className: "text-center w-full py-2 text-white text-sm uppercase disabled:bg-gray-500 bg-violet-700 rounded-lg",
      children: imageUrl ? "uploaded" : imageLoader ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_ButtonLoader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : "Upload Image"
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageUploader);

/***/ }),

/***/ 1569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const blur = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAAKAAoDASIAAhEBAxEB/8QAFwAAAwEAAAAAAAAAAAAAAAAAAAMGB//EABQBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAdDRKg//xAAYEAADAQEAAAAAAAAAAAAAAAABAgMQE//aAAgBAQABBQJpyA4Jv//EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oACAEDAQE/Aa//xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAgBAgEBPwGP/8QAGxAAAAcBAAAAAAAAAAAAAAAAAAECEDEzkqL/2gAIAQEABj8CrRkRyT//xAAbEAACAQUAAAAAAAAAAAAAAAABEQAQIWGR4f/aAAgBAQABPyFiOpG3UY4V/9oADAMBAAIAAwAAABAD/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAERMf/aAAgBAwEBPxBRh//EABcRAAMBAAAAAAAAAAAAAAAAAAABETH/2gAIAQIBAT8Qdaf/xAAcEAAABgMAAAAAAAAAAAAAAAAAAREhQVEQMWH/2gAIAQEAAT8QmtEUBLbaF13QxzL/2Q==";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blur);

/***/ }),

/***/ 7794:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(8319);


/***/ }),

/***/ 29:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ })

};
;