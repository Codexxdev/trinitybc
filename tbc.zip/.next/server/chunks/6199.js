"use strict";
exports.id = 6199;
exports.ids = [6199];
exports.modules = {

/***/ 6199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uv": () => (/* binding */ getServiceDetails),
/* harmony export */   "Pg": () => (/* binding */ updateService),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getServiceDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`service/getServiceDetails`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/service/${id}`);
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const updateService = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`service/updateService`, async ({
  id,
  service,
  startTime,
  endTime,
  topic,
  imageUrl,
  bulletin
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/service/${id}`, {
      service,
      startTime,
      endTime,
      topic,
      imageUrl,
      bulletin
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const serviceSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'service',
  initialState: {
    loading: false,
    service: null,
    message: null
  },
  reducers: {},
  extraReducers: {
    [getServiceDetails.pending]: state => {
      state.loading = true;
    },
    [getServiceDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.service = payload.service;
    },
    [getServiceDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateService.pending]: state => {
      state.loading = true;
    },
    [updateService.fulfilled]: state => {
      state.loading = false;
    },
    [updateService.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
}); // export const { deleteOne, addservice } = serviceSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (serviceSlice.reducer);

/***/ })

};
;