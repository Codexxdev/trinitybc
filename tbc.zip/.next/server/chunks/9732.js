"use strict";
exports.id = 9732;
exports.ids = [9732];
exports.modules = {

/***/ 9732:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "zX": () => (/* binding */ createNews),
  "kN": () => (/* binding */ deleteNews),
  "tq": () => (/* binding */ getAdminNews),
  "bo": () => (/* binding */ getClientNews),
  "dD": () => (/* binding */ getNews),
  "f9": () => (/* binding */ getNewsDetails),
  "jB": () => (/* binding */ updateNews)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/News.js

const newsSchema = new (external_mongoose_default()).Schema({
  title: {
    type: String,
    required: true
  },
  author: {
    type: (external_mongoose_default()).Schema.ObjectId,
    required: true,
    ref: 'user'
  },
  action: {
    type: String
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  body: {
    type: String,
    require: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const News = ((external_mongoose_default()).models.News || external_mongoose_default().model('News', newsSchema));
// EXTERNAL MODULE: ./models/User.js
var User = __webpack_require__(4871);
// EXTERNAL MODULE: external "express-async-handler"
var external_express_async_handler_ = __webpack_require__(2776);
var external_express_async_handler_default = /*#__PURE__*/__webpack_require__.n(external_express_async_handler_);
// EXTERNAL MODULE: external "cloudinary"
var external_cloudinary_ = __webpack_require__(3518);
var external_cloudinary_default = /*#__PURE__*/__webpack_require__.n(external_cloudinary_);
// EXTERNAL MODULE: ./middleware/errorHandler.js
var errorHandler = __webpack_require__(21);
;// CONCATENATED MODULE: ./controllers/newsController.js





external_cloudinary_default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // Get news details
// get =>  /api/admin/news

const getNewsDetails = external_express_async_handler_default()(async (req, res, next) => {
  const news = await News.findById(req.query.id).sort('-updatedAt').populate({
    path: 'author',
    select: "name",
    model: User/* default */.Z
  });

  if (!news) {
    return next(new errorHandler/* default */.Z('News not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      news
    });
  }
}); // Get news details
// get =>  /api/admin/news

const getClientNews = external_express_async_handler_default()(async (req, res, next) => {
  const news = await News.find({}).sort('-updatedAt').populate({
    path: 'author',
    select: "name",
    model: User/* default */.Z
  });
  res.status(200).json({
    success: "true",
    news
  });
}); // create news
// post =>  /api/admin/news

const createNews = external_express_async_handler_default()(async (req, res, next) => {
  req.body.author = req.user._id;
  const news = await News.create(req.body);
  res.status(200).json({
    success: "true",
    message: "News created successfully"
  });
}); // create news
// get =>  /api/admin/news

const getAdminNews = external_express_async_handler_default()(async (req, res, next) => {
  const news = await News.find({}).sort('-updatedAt').populate({
    path: 'author',
    select: "name",
    model: User/* default */.Z
  });
  res.status(200).json({
    success: "true",
    news
  });
}); // Delete news
// Delete => api/admin/news/:id

const deleteNews = external_express_async_handler_default()(async (req, res, next) => {
  const news = await News.findById(req.query.id);

  if (!news) {
    return next(new errorHandler/* default */.Z('News not found with this ID', 404));
  } else {
    await external_cloudinary_default().v2.uploader.destroy(news.imageUrl.public_id);
    await news.remove();
    res.status(200).json({
      success: "true",
      message: "News Deleted"
    });
  }
}); // get News
// get => api/News/:id

const getNews = external_express_async_handler_default()(async (req, res, next) => {
  const news = await News.findById(req.query.id);

  if (!news) {
    return next(new errorHandler/* default */.Z('News not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      news
    });
  }
}); // update news
// put => api/newss/:id

const updateNews = external_express_async_handler_default()(async (req, res, next) => {
  const news = await News.findById(req.query.id);

  if (!news) {
    return next(new errorHandler/* default */.Z('news not found with this ID', 404));
  } else {
    var _news$imageUrl;

    const {
      title,
      action,
      body,
      imageUrl
    } = req.body;
    news.title = title;
    news.action = action;
    news.body = body;
    news.updatedAt = Date.now();

    if ((news === null || news === void 0 ? void 0 : (_news$imageUrl = news.imageUrl) === null || _news$imageUrl === void 0 ? void 0 : _news$imageUrl.public_id) !== imageUrl.public_id) {
      await external_cloudinary_default().v2.uploader.destroy(news.imageUrl.public_id);
      news.imageUrl = imageUrl;
    }

    await news.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
});


/***/ })

};
;