"use strict";
exports.id = 9039;
exports.ids = [9039];
exports.modules = {

/***/ 9039:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5675);
/* harmony import */ var _mui_icons_material_GraphicEq__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3042);
/* harmony import */ var _mui_icons_material_GraphicEq__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_GraphicEq__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_OndemandVideo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2803);
/* harmony import */ var _mui_icons_material_OndemandVideo__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_OndemandVideo__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _common_blur__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1569);
/* harmony import */ var _common_About__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7430);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const defaultImage = "https://res.cloudinary.com/dk6uhtgvo/image/upload/v1651307274/Global/series_yvd6gq.jpg";

const Body = ({
  series,
  changeCurrent,
  current
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: "container lg:px-[2rem]  ",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
      className: "text-xs lg:hidden uppercase bg-gray-700 text-center text-white px-5 py-2 lg:py-0",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("a", {
        href: "#all",
        children: "View All from this series"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
      className: "flex flex-col justify-center !mt-3 !lg:mt-0 items-center space-y-3 mb-3",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
        className: "text-xs text-center lg:text-left tracking-widest font-light uppercase",
        children: (0,date_fns__WEBPACK_IMPORTED_MODULE_4__.format)(new Date(current.date), 'do MMM yyyy')
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
        className: "text-xl md:text-3xl font-medium text-center lg:text-left uppercase",
        children: current.title
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
        className: "flex flex-col font-light uppercase text-sm space-y-2",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
          className: "flex items-center space-x-2 justify-center ",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
            className: " ",
            children: "Scripture:"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
            className: " ",
            children: `${current.book} ${current.chapter}:${current.verse}`
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
          className: "flex items-center space-x-2 justify-center ",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
            className: " ",
            children: "Speaker:"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
            className: " ",
            children: current.preacher.name
          })]
        })]
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
      className: "grid grid-cols-1 md:!mt-10 lg:grid-cols-12 items-start gap-5 ",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        className: "lg:col-span-7 px-2 md:px-0",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
          className: "flex flex-col space-y-3 w-full",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
            className: "flex flex-col !mb-12 !mt-10 space-y-3",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
              className: "mx-1 text-sm lg:text-base uppercase",
              children: "About the message"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("p", {
              className: "md:text-lg md:leading-8 font-light text-justify px-1",
              children: current.description
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_common_About__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            preacher: current.preacher
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        id: "all",
        className: ` lg:col-span-5 h-fit  lg:max-h-[500px] mx-2 lg:mx-0 py-5 shadow-2xl px-0 md:px-2 pt-3  overflow-y-auto overscroll-contain`,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
          className: "flex flex-col  md:mt-5 !space-y-3  ",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
            className: "text-center text-xs uppercase",
            children: "Part of a Series"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
            className: "text-center  font-medium uppercase",
            children: series.title
          }), series.sermons.map((sermon, index) => {
            var _sermon$imageUrl;

            return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
              onClick: () => changeCurrent(index),
              className: `${current._id === sermon._id ? "bg-primary-dark text-white" : "lg:hover:bg-gray-200 lg:hover:text-gray-800"} flex py-3 cursor-pointer  items-center justify-between space-x-2 px-2 border-b border-b-primary-black/10`,
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
                className: "flex flex-col space-y-2",
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
                  className: "flex space-x-1",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx((_mui_icons_material_GraphicEq__WEBPACK_IMPORTED_MODULE_1___default()), {
                    className: "text-[orange] !text-base"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx((_mui_icons_material_OndemandVideo__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "text-[red]/80 !text-base"
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
                    className: "text-xs tracking-widest font-light uppercase",
                    children: '|  ' + (0,date_fns__WEBPACK_IMPORTED_MODULE_4__.format)(new Date(sermon.date), 'do MMM yyyy')
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
                  className: " text-base md:text-lg capitalize ",
                  children: `${index + 1}. ${sermon.title} `
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
                  className: "font-light text-sm capitalize tracking-wide ",
                  children: `${sermon.book} ${sermon.chapter}:${sermon.verse}`
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
                  className: "flex items-center !mt-3 space-x-2",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
                    className: "h-[25px] w-[25px] rounded-full relative",
                    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                      src: sermon.preacher.imageUrl.url,
                      className: "object-cover w-full h-full rounded-full",
                      layout: "fill",
                      blurDataURL: _common_blur__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                      placeholder: "blur",
                      alt: "logo"
                    })
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h1", {
                    className: "text-sm  font-light capitalize",
                    children: sermon.preacher.name
                  })]
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
                className: "w-[70px] h-[75px] rounded-lg  relative",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
                  src: (_sermon$imageUrl = sermon.imageUrl) !== null && _sermon$imageUrl !== void 0 && _sermon$imageUrl.url ? sermon.imageUrl.url : defaultImage,
                  className: "object-cover rounded-lg w-full h-full ",
                  layout: "fill",
                  blurDataURL: _common_blur__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                  placeholder: "blur",
                  alt: "logo"
                })
              })]
            }, sermon._id);
          })]
        })
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Body);

/***/ })

};
;