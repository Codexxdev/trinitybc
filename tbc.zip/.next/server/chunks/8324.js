"use strict";
exports.id = 8324;
exports.ids = [8324];
exports.modules = {

/***/ 8324:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "uj": () => (/* binding */ addMinister),
/* harmony export */   "y7": () => (/* binding */ getMinisters),
/* harmony export */   "Gh": () => (/* binding */ deleteMinister),
/* harmony export */   "th": () => (/* binding */ getMinister),
/* harmony export */   "lf": () => (/* binding */ updateMinister),
/* harmony export */   "si": () => (/* binding */ getClientMinisters)
/* harmony export */ });
/* harmony import */ var _models_Ministers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3373);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3518);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cloudinary__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(21);




cloudinary__WEBPACK_IMPORTED_MODULE_1___default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // Create Minister
// post => api/ministers

const addMinister = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    name,
    about,
    role,
    imageUrl
  } = req.body;
  const minister = await _models_Ministers__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create({
    name,
    about,
    role,
    imageUrl
  });
  res.status(200).json({
    success: "true",
    message: "Added new minister"
  });
}); // Get all Ministers
// get => api/ministers

const getMinisters = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const ministers = await _models_Ministers__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find().sort({
    createdAt: -1
  });
  res.status(200).json({
    success: "true",
    ministers
  });
}); // Get all Ministers
// get => api/ministers

const getClientMinisters = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const ministers = await _models_Ministers__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find().sort('-createdAt');
  res.status(200).json({
    success: "true",
    ministers
  });
}); // Delete Minister
// Delete => api/ministers/:id

const deleteMinister = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const minister = await _models_Ministers__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!minister) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z('Sermon not found with this ID', 404));
  } else {
    await cloudinary__WEBPACK_IMPORTED_MODULE_1___default().v2.uploader.destroy(minister.imageUrl.public_id);
    await minister.remove();
    res.status(200).json({
      success: "true",
      message: "minister Deleted"
    });
  }
}); // get Minister
// get => api/ministers/:id

const getMinister = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const minister = await _models_Ministers__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!minister) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z('Sermon not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      minister
    });
  }
}); // update Minister
// put => api/ministers/:id

const updateMinister = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const minister = await _models_Ministers__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!minister) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z('Sermon not found with this ID', 404));
  } else {
    const {
      name,
      about,
      role,
      imageUrl
    } = req.body;
    minister.name = name;
    minister.about = about;
    minister.role = role;

    if (minister.imageUrl.public_id !== imageUrl.public_id) {
      await cloudinary__WEBPACK_IMPORTED_MODULE_1___default().v2.uploader.destroy(minister.imageUrl.public_id);
      minister.imageUrl = imageUrl;
    }

    await minister.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
});


/***/ }),

/***/ 3373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const ministerSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: [true, 'Please enter your name']
  },
  role: {
    type: String,
    default: 'minister'
  },
  about: {
    type: String,
    required: [true, "Please enter minister's about"]
  },
  imageUrl: {
    public_id: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Minister) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Minister', ministerSchema));

/***/ })

};
;