exports.id = 1817;
exports.ids = [1817];
exports.modules = {

/***/ 1817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Dashboard_DashboardLayout)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Dashboard/Links.js







const Links = ({
  Icon,
  name,
  color,
  path
}) => {
  const {
    0: active,
    1: setActive
  } = (0,external_react_.useState)("");
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    const route = router.pathname.split("/admin")[1];
    setActive(route);
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: `/admin${path}`,
    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: ` ${active.includes(path.split('/')[1]) ? "text-gray-900 rounded-l-full bg-gray-200 font-medium" : "hover:bg-gray-800 hover:rounded-l-full font-light"} flex space-x-2 cursor-pointer items-center py-2 pl-5 `,
        children: [/*#__PURE__*/jsx_runtime_.jsx(Icon, {
          className: `${color}  !text-lg`
        }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: " tracking-wide capitalize",
          children: name
        })]
      })
    })
  });
};

/* harmony default export */ const Dashboard_Links = (Links); // text-gray-900 rounded-l-full bg-gray-100
// EXTERNAL MODULE: external "@mui/icons-material/DashboardCustomize"
var DashboardCustomize_ = __webpack_require__(8511);
var DashboardCustomize_default = /*#__PURE__*/__webpack_require__.n(DashboardCustomize_);
// EXTERNAL MODULE: external "@mui/icons-material/EventNote"
var EventNote_ = __webpack_require__(7980);
var EventNote_default = /*#__PURE__*/__webpack_require__.n(EventNote_);
// EXTERNAL MODULE: external "@mui/icons-material/SupervisorAccount"
var SupervisorAccount_ = __webpack_require__(2584);
var SupervisorAccount_default = /*#__PURE__*/__webpack_require__.n(SupervisorAccount_);
// EXTERNAL MODULE: external "@mui/icons-material/AppRegistration"
var AppRegistration_ = __webpack_require__(5680);
var AppRegistration_default = /*#__PURE__*/__webpack_require__.n(AppRegistration_);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./components/Dashboard/DashboardLinks.js











const DashboardLinks = () => {
  const {
    loading,
    user,
    message
  } = (0,external_react_redux_.useSelector)(state => state.currentUser);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: " fixed top-[73px] bottom-5 rounded-2xl w-[270px] bg-gray-900",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col py-5 space-y-5 h-full text-gray-100 relative ",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col space-y-5 border-b border-b-gray-600 ml-2 px-2 pb-5",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "uppercase font-semi-bold text-center text-gray-200 ",
            children: "admin Dashboard"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: " text-gray-300 uppercase text-xs",
              children: user === null || user === void 0 ? void 0 : user.name
            }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "font-light uppercase py-[2px] px-2 bg-green-700 rounded-full text-[10px] text-gray-200",
              children: "signed in"
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col space-y-2 ml-4",
          children: [/*#__PURE__*/jsx_runtime_.jsx(Dashboard_Links, {
            Icon: (DashboardCustomize_default()),
            path: "/resources/sermon",
            color: "!text-yellow-500",
            name: "resources"
          }), /*#__PURE__*/jsx_runtime_.jsx(Dashboard_Links, {
            Icon: (EventNote_default()),
            path: "/events/upcoming",
            color: "!text-green-700",
            name: "events & news"
          }), /*#__PURE__*/jsx_runtime_.jsx(Dashboard_Links, {
            Icon: (SupervisorAccount_default()),
            path: "/ministers",
            color: "!text-orange-600",
            name: "ministers"
          }), /*#__PURE__*/jsx_runtime_.jsx(Dashboard_Links, {
            Icon: (AppRegistration_default()),
            path: "/register/emails",
            color: "!text-indigo-700",
            name: "register"
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "absolute bottom-0 w-full",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            onClick: () => (0,react_.signOut)(),
            className: "flex justify-center py-2 rounded-b-2xl cursor-pointer bg-red-700",
            children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "uppercase text-sm",
              children: "LogOut"
            })
          })
        })]
      })
    })
  });
};

/* harmony default export */ const Dashboard_DashboardLinks = (DashboardLinks);
// EXTERNAL MODULE: ./redux/features/menu.js
var menu = __webpack_require__(5771);
// EXTERNAL MODULE: external "react-datepicker"
var external_react_datepicker_ = __webpack_require__(983);
var external_react_datepicker_default = /*#__PURE__*/__webpack_require__.n(external_react_datepicker_);
// EXTERNAL MODULE: ./node_modules/react-datepicker/dist/react-datepicker.css
var react_datepicker = __webpack_require__(5994);
// EXTERNAL MODULE: ./redux/features/getMinisters.js
var getMinisters = __webpack_require__(7422);
// EXTERNAL MODULE: ./components/common/ButtonLoader.js
var ButtonLoader = __webpack_require__(1947);
// EXTERNAL MODULE: ./redux/features/event.js
var features_event = __webpack_require__(3122);
;// CONCATENATED MODULE: ./components/Dashboard/Modal.js












const Modal = () => {
  const {
    0: startTime,
    1: setStartTime
  } = (0,external_react_.useState)(new Date());
  const {
    0: endTime,
    1: setEndTime
  } = (0,external_react_.useState)(new Date());
  const {
    0: topic,
    1: setTopic
  } = (0,external_react_.useState)('');
  const {
    0: preacherName,
    1: setPreacherName
  } = (0,external_react_.useState)('');
  const {
    0: description,
    1: setDescription
  } = (0,external_react_.useState)('');
  const {
    0: id,
    1: setId
  } = (0,external_react_.useState)(Math.random());
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)('');
  const {
    modalData
  } = (0,external_react_redux_.useSelector)(state => state.menu);
  const {
    ministers
  } = (0,external_react_redux_.useSelector)(state => state.ministers);
  const dispatch = (0,external_react_redux_.useDispatch)();
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    dispatch((0,getMinisters/* getAdminMinisters */.Yy)());
    const {
      startTime,
      endTime,
      topic,
      description,
      preacher,
      id
    } = modalData;

    if (modalData._id) {
      ministers.map(minister => {
        if (minister._id === preacher._id) {
          setPreacherName(minister.name);
        }
      });

      if (startTime, endTime, topic, description) {
        setStartTime(new Date(startTime));
        setEndTime(new Date(endTime));
        setTopic(topic);
        setDescription(description);
        setId(id);
      }
    } else {
      ministers.map(minister => {
        if (minister._id === preacher) {
          setPreacherName(minister.name);
        }
      });

      if (startTime, endTime, topic, description, id) {
        setStartTime(startTime);
        setEndTime(endTime);
        setTopic(topic);
        setDescription(description);
        setId(id);
      }
    }
  }, []);

  const handleSubmit = e => {
    e.preventDefault();
    setLoading(true);
    let preacher = '';
    let name = '';
    ministers.forEach(minister => {
      if (minister.name === preacherName) {
        preacher = minister._id;
        name = minister.name;
      }
    });

    if (modalData._id && router.query.id) {
      const session = {
        _id: modalData._id,
        topic,
        preacher,
        description,
        startTime,
        endTime
      };
      dispatch((0,features_event/* setEventSessions */.X$)(session));
      dispatch((0,menu/* setModalState */.hr)(false));
    } else if (!modalData._id && router.query.id) {
      const session = {
        day: modalData.day ? modalData.day : modalData,
        topic,
        preacher: {
          _id: preacher,
          name: name
        },
        description,
        startTime,
        endTime,
        _id: id
      };
      dispatch((0,features_event/* setEventSessions */.X$)(session));
      dispatch((0,menu/* setModalState */.hr)(false));
    } else {
      const session = {
        day: modalData.day ? modalData.day : modalData,
        topic,
        preacher,
        description,
        startTime,
        endTime,
        id
      };
      dispatch((0,menu/* setSessions */.iz)(session));
      dispatch((0,menu/* setModalState */.hr)(false));
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    onClick: () => {
      dispatch((0,menu/* setModalState */.hr)(false));
    },
    className: "fixed w-full h-screen  top-0 bottom-0 left-0 right-0 overflow-y-hidden overscroll-y-none bg-gray-900/90 z-50 ",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      onClick: e => e.stopPropagation(),
      className: "flex w-full h-full justify-center items-center",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col space-y-5 max-w-screen-md mx-auto h-[500px] w-full !px-5 !py-5 relative rounded-2xl bg-white",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "uppercase font-medium text-primary-dark text-center",
          children: modalData.day ? modalData.day : modalData
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
          className: "flex flex-col space-y-4 w-full items-center justify-start",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "grid grid-cols-12 w-full items-center gap-3",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "col-span-6 w-full space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "title",
                className: "ml-2 text-sm uppercase",
                children: "Topic"
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "title",
                name: "title",
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                required: true,
                value: topic,
                onChange: e => {
                  setTopic(e.target.value);
                }
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "col-span-3 w-full space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "title",
                className: "ml-2 text-sm uppercase",
                children: "Starts"
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                selected: startTime,
                onChange: date => setStartTime(date),
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                timeInputLabel: "Time:",
                dateFormat: "MM/dd/yyyy h:mm aa",
                showTimeInput: true
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "col-span-3 w-full space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "title",
                className: "ml-2 text-sm uppercase",
                children: "Ends"
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                selected: endTime,
                onChange: date => setEndTime(date),
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                timeInputLabel: "Time:",
                dateFormat: "MM/dd/yyyy h:mm aa",
                showTimeInput: true
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "space-y-2 w-full",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              htmlFor: "name",
              className: "ml-2 text-sm uppercase",
              children: "Preacher"
            }), /*#__PURE__*/jsx_runtime_.jsx("select", {
              type: "text",
              name: "preacher",
              className: "w-full capitalize text-gray-500 !px-1 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
              value: preacherName,
              onChange: e => {
                setPreacherName(e.target.value);
              },
              children: ministers && [{
                name: "select preacher",
                _id: 1
              }, ...ministers].map(minister => /*#__PURE__*/jsx_runtime_.jsx("option", {
                className: "capitalize",
                value: minister.name,
                children: minister.name
              }, minister._id))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full space-y-2",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              htmlFor: "description",
              className: "ml-2 text-sm uppercase",
              children: "description"
            }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
              rows: "4",
              value: description,
              onChange: e => {
                setDescription(e.target.value);
              }
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "absolute bottom-2 left-0 right-0 flex  items-center justify-around w-full !mb-3 ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            onClick: () => {
              dispatch((0,menu/* setModalState */.hr)(false));
            },
            className: "cursor-pointer text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-red-700",
            children: "cancel"
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            onClick: handleSubmit,
            className: "text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-blue-600",
            children: loading ? /*#__PURE__*/jsx_runtime_.jsx(ButtonLoader/* default */.Z, {}) : modalData._id ? "upadte session" : "add session"
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const Dashboard_Modal = (Modal);
// EXTERNAL MODULE: ./redux/features/sermons.js
var sermons = __webpack_require__(272);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./redux/features/bibleStudies.js
var bibleStudies = __webpack_require__(9119);
// EXTERNAL MODULE: ./redux/features/series.js
var series = __webpack_require__(9884);
// EXTERNAL MODULE: ./redux/features/seriesDetails.js
var seriesDetails = __webpack_require__(228);
// EXTERNAL MODULE: ./redux/features/conference.js
var conference = __webpack_require__(2961);
// EXTERNAL MODULE: ./redux/features/conferences.js
var conferences = __webpack_require__(4620);
// EXTERNAL MODULE: ./redux/features/events.js
var events = __webpack_require__(4825);
// EXTERNAL MODULE: ./redux/features/services.js
var services = __webpack_require__(8797);
// EXTERNAL MODULE: ./redux/features/news.js
var news = __webpack_require__(2268);
// EXTERNAL MODULE: ./redux/features/emails.js
var emails = __webpack_require__(1868);
// EXTERNAL MODULE: ./redux/features/register.js
var register = __webpack_require__(5460);
;// CONCATENATED MODULE: ./components/Dashboard/DeleteModal.js





















const DeleteModal = () => {
  const {
    0: name,
    1: setName
  } = (0,external_react_.useState)('');
  const {
    0: data,
    1: setData
  } = (0,external_react_.useState)('');
  const {
    0: dataName,
    1: setDataName
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const {
    deleteModalData
  } = (0,external_react_redux_.useSelector)(state => state.menu);
  (0,external_react_.useEffect)(() => {
    // minister
    deleteModalData.minister && setDataName(deleteModalData.minister.name);
    deleteModalData.minister && setData(deleteModalData.minister); // sermon

    deleteModalData.sermon && setDataName(deleteModalData.sermon.title);
    deleteModalData.sermon && setData(deleteModalData.sermon); // bible study

    deleteModalData.study && setDataName(deleteModalData.study.title);
    deleteModalData.study && setData(deleteModalData.study); // sermon series 

    deleteModalData.serie && setDataName(deleteModalData.serie.title);
    deleteModalData.serie && setData(deleteModalData.serie); // series sermon

    deleteModalData.serm && setDataName(deleteModalData.serm.title);
    deleteModalData.serm && setData(deleteModalData.serm); // conference sermon 

    deleteModalData.sermc && setDataName(deleteModalData.sermc.title);
    deleteModalData.sermc && setData(deleteModalData.sermc); // conference

    deleteModalData.conference && setDataName(deleteModalData.conference.title);
    deleteModalData.conference && setData(deleteModalData.conference); // event

    deleteModalData.event && setDataName(deleteModalData.event.title);
    deleteModalData.event && setData(deleteModalData.event); // event session

    deleteModalData.eve && setDataName(deleteModalData.eve.topic);
    deleteModalData.eve && setData(deleteModalData.eve); // service

    deleteModalData.service && setDataName(deleteModalData.service.service);
    deleteModalData.service && setData(deleteModalData.service); // News

    deleteModalData.info && setDataName(deleteModalData.info.title);
    deleteModalData.info && setData(deleteModalData.info); // Email

    deleteModalData.email && setDataName(deleteModalData.email.email);
    deleteModalData.email && setData(deleteModalData.email); // Register

    deleteModalData.register && setDataName(deleteModalData.register.email);
    deleteModalData.register && setData(deleteModalData.register);
  }, []);
  const dispatch = (0,external_react_redux_.useDispatch)();

  const handleDelete = (id, index) => {
    setLoading(true); // minister

    if (deleteModalData.minister) {
      dispatch((0,getMinisters/* postDeleteMinister */.Mb)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // sermon


    if (deleteModalData.sermon) {
      dispatch((0,sermons/* postDeleteSermon */.aU)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // study


    if (deleteModalData.study) {
      dispatch((0,bibleStudies/* postDeleteBibleStudy */.so)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // sermon series


    if (deleteModalData.serie) {
      dispatch((0,series/* postDeleteSeries */.TH)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // series sermon


    if (deleteModalData.serm) {
      dispatch((0,seriesDetails/* postDeleteSeriesSermon */.TC)({
        sermonId: id,
        index,
        id: deleteModalData.id
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted series sermon");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // conference sermon


    if (deleteModalData.sermc) {
      dispatch((0,conference/* postDeleteConferenceSermon */.id)({
        sermonId: id,
        index,
        id: deleteModalData.id
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted conference sermon");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // conference


    if (deleteModalData.conference) {
      dispatch((0,conferences/* postDeleteConference */.dF)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // event


    if (deleteModalData.event) {
      dispatch((0,events/* postDeleteEvent */.S5)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } //event session


    if (deleteModalData.eve) {
      dispatch((0,features_event/* postDeleteEventSession */.t)({
        sessionId: id,
        index,
        id: deleteModalData.id
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted Event Session");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // service


    if (deleteModalData.service) {
      dispatch((0,services/* postDeleteService */.Mf)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("successfully deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // News


    if (deleteModalData.info) {
      dispatch((0,news/* postDeleteNews */.Df)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("Successfully Deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // Email


    if (deleteModalData.email) {
      dispatch((0,emails/* postDeleteEmail */.bl)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("Successfully Deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    } // Register


    if (deleteModalData.register) {
      dispatch((0,register/* postDeleteRegister */.yu)({
        id,
        index
      })).then(result => {
        if (!result.error) {
          setLoading(false);
          external_react_toastify_.toast.success("Successfully Deleted");
          dispatch((0,menu/* setDeletModalState */.e$)(false));
        } else {
          console.log(result.error);
        }
      });
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "fixed w-full h-screen  top-0 bottom-0 left-0 right-0 overflow-y-hidden overscroll-y-none bg-gray-900/90 z-50 ",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex w-full h-full justify-center items-center",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        onClick: e => e.stopPropagation(),
        className: "flex flex-col space-y-5 max-w-screen-sm mx-auto h-[280px] w-full !px-5 !py-5 relative rounded-2xl bg-white",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "uppercase text-xl font-semibold text-red-700 text-center",
          children: "delete"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
          autoComplete: "off",
          className: "flex flex-col space-y-4 w-full items-center justify-start",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
            children: [" Are you sure you want to delete ", /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "font-bold",
              children: `${dataName}`
            }), "?  "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: " w-full flex flex-col space-y-5",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              htmlFor: "title",
              className: "w-full font-medium text-center  text-sm uppercase",
              children: "Enter Name to Confirm"
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "title",
              name: "title",
              className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
              required: true,
              value: name,
              onChange: e => {
                setName(e.target.value);
              }
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "absolute bottom-2 left-0 right-0 flex  items-center justify-around w-full !mb-3 ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            onClick: () => {
              dispatch((0,menu/* setDeletModalState */.e$)(false));
            },
            className: "cursor-pointer text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-blue-600",
            children: "cancel"
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            onClick: () => handleDelete(data._id, deleteModalData.index),
            disabled: name !== dataName,
            className: "text-center text-white py-1.5 rounded-md text-sm disabled:bg-red-400  px-7 uppercase bg-red-600",
            children: loading ? /*#__PURE__*/jsx_runtime_.jsx(ButtonLoader/* default */.Z, {}) : "delete"
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const Dashboard_DeleteModal = (DeleteModal);
;// CONCATENATED MODULE: ./components/Dashboard/DashboardLayout.js








const DashboardLayout = ({
  children
}) => {
  const {
    modalState,
    deletModalState
  } = (0,external_react_redux_.useSelector)(state => state.menu);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
      className: "xl:hidden pt-[70px] text-center uppercase text-lg ",
      children: "Go To desktop screen"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "hidden xl:block !w-full container px-1 md:px-0 xl:px-[2rem] lg:px-[1rem]  !pt-[60px]",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Dashboard_DashboardLinks, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex ml-[280px] rounded-2xl mt-4 bg-gray-200 min-h-screen mb-4 ",
        children: children
      })]
    }), modalState && /*#__PURE__*/jsx_runtime_.jsx(Dashboard_Modal, {}), deletModalState && /*#__PURE__*/jsx_runtime_.jsx(Dashboard_DeleteModal, {})]
  });
};

/* harmony default export */ const Dashboard_DashboardLayout = (DashboardLayout);

/***/ }),

/***/ 5994:
/***/ (() => {



/***/ })

};
;