exports.id = 1294;
exports.ids = [1294];
exports.modules = {

/***/ 5727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ sermons_Filter)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/features/getMinisters.js
var getMinisters = __webpack_require__(7422);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/sermons/FilterItems.js







const FilterItems = ({
  setFilterToggle,
  fitlerToggle,
  topics,
  preachers,
  scriptures
}) => {
  var _router$query, _router$query2, _router$query3;

  const dispatch = (0,external_react_redux_.useDispatch)();
  const {
    ministers
  } = (0,external_react_redux_.useSelector)(state => state.clientMinisters);
  const router = (0,router_.useRouter)();
  const {
    0: tValue,
    1: setTValue
  } = (0,external_react_.useState)(5);
  const {
    0: sValue,
    1: setSValue
  } = (0,external_react_.useState)(5);
  const {
    0: pValue,
    1: setPValue
  } = (0,external_react_.useState)(5);
  const {
    0: tSelect,
    1: setTSelect
  } = (0,external_react_.useState)((_router$query = router.query) !== null && _router$query !== void 0 && _router$query.topic ? router.query.topic : "");
  const {
    0: pSelect,
    1: setPSelect
  } = (0,external_react_.useState)("");
  const {
    0: sSelect,
    1: setSSelect
  } = (0,external_react_.useState)((_router$query2 = router.query) !== null && _router$query2 !== void 0 && _router$query2.scripture ? router.query.scripture : "");
  (0,external_react_.useEffect)(() => {
    ministers.map(minister => {
      if (minister._id === router.query.preacher) {
        setPSelect(minister.name);
      }
    });
  }, [(_router$query3 = router.query) === null || _router$query3 === void 0 ? void 0 : _router$query3.preacher]);

  const handleSubmit = (tSelect, pSelect, sSelect) => {
    let preacher = '';
    let link = `${router.route}?page=1`;

    if (pSelect) {
      ministers.map(minister => {
        if (minister.name === pSelect) {
          preacher = minister._id;
        }
      });
    }

    if (tSelect) {
      link = link.concat(`&topic=${tSelect}`);
    }

    if (preacher) {
      link = link.concat(`&preacher=${preacher}`);
    }

    if (sSelect) {
      link = link.concat(`&scripture=${sSelect}`);
    } // console.log(preacher)


    router.push(link);

    if (fitlerToggle) {
      setFilterToggle(false);
    }
  };

  const toggleDisable = () => {
    if (tSelect || pSelect || sSelect) {
      return false;
    } else {
      return true;
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex ml-3 md:ml-5 mt-3 flex-col transition duration-500 ease-in-out space-y-5 !mb-10",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "topics flex-col space-y-2 text-sm",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase font-medium",
        children: "Topics"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "ml-4 flex-col space-y-2",
        children: [topics.slice(0, tValue).map((topic, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          onClick: () => {
            if (tSelect !== topic) {
              setTSelect(topic);
            } else {
              setTSelect('');
            }
          },
          className: "flex items-center space-x-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: `${tSelect === topic ? "bg-primary-dark" : ""} border cursor-pointer rounded w-4 h-4 border-primary-dark`
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "capitalize  font-light",
            children: topic
          })]
        }, index)), topics.length > tValue && /*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: () => setTValue(topics.length),
          className: "text-sm cursor-pointer text-primary-dark",
          children: "see more..."
        }), tValue !== 5 && tValue === topics.length && /*#__PURE__*/jsx_runtime_.jsx("h1", {
          onClick: () => setTValue(5),
          className: "text-sm cursor-pointer text-primary-dark",
          children: "see less..."
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "preachers flex-col space-y-2 text-sm",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase font-medium",
        children: "Preachers"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "ml-4 flex-col space-y-2",
        children: [preachers.slice(0, pValue).map((preacher, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          onClick: () => {
            if (pSelect !== preacher) {
              setPSelect(preacher);
            } else {
              setPSelect('');
            }
          },
          className: "flex items-center space-x-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: `${pSelect === preacher ? "bg-primary-dark" : ""}  border cursor-pointer rounded w-4 h-4 border-primary-dark`
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "capitalize font-light",
            children: preacher
          })]
        }, index)), preachers.length > pValue && /*#__PURE__*/jsx_runtime_.jsx("h1", {
          onClick: () => setPValue(preachers.length),
          className: "text-sm cursor-pointer text-primary-dark",
          children: "see more..."
        }), pValue !== 5 && pValue === preachers.length && /*#__PURE__*/jsx_runtime_.jsx("h1", {
          onClick: () => setPValue(5),
          className: "text-sm cursor-pointer text-primary-dark",
          children: "see less..."
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "scriptues flex-col space-y-2 text-sm",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase font-medium",
        children: "Scriptures"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "ml-4 flex-col space-y-2",
        children: [scriptures.slice(0, sValue).map((scripture, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          onClick: () => {
            if (sSelect !== scripture) {
              setSSelect(scripture);
            } else {
              setSSelect('');
            }
          },
          className: "flex items-center space-x-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: `${sSelect === scripture ? "bg-primary-dark" : ""} border cursor-pointer rounded w-4 h-4 border-primary-dark`
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "capitalize font-light",
            children: scripture
          })]
        }, index)), scriptures.length > sValue && /*#__PURE__*/jsx_runtime_.jsx("h1", {
          onClick: () => setSValue(scriptures.length),
          className: "text-sm cursor-pointer text-primary-dark",
          children: "see more..."
        }), sValue !== 5 && sValue === scriptures.length && /*#__PURE__*/jsx_runtime_.jsx("h1", {
          onClick: () => setSValue(5),
          className: "text-sm cursor-pointer text-primary-dark",
          children: "see less..."
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex !mt-8 items-center space-x-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: () => {
          setTSelect('');
          setPSelect('');
          setSSelect('');
        },
        disabled: toggleDisable(),
        className: "py-1 px-3 uppercase text-[white] text-xs  bg-red-600 disabled:bg-red-300",
        children: "Reset"
      }), /*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: () => {
          handleSubmit(tSelect, pSelect, sSelect);
        },
        className: "py-1 px-3 uppercase text-[white]  text-xs  bg-primary-light disabled:bg-primary-dark/60",
        children: "Done"
      })]
    })]
  });
};

/* harmony default export */ const sermons_FilterItems = (FilterItems);
;// CONCATENATED MODULE: ./components/sermons/SortItems.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const SortItems = ({
  setSortToggle
}) => {
  const router = (0,router_.useRouter)();
  const sort = router.query.sort || "newest";

  const handleSort = key => {
    router.push({
      pathname: router.pathname,
      query: _objectSpread(_objectSpread({}, router.query), {}, {
        page: 1,
        sort: key
      })
    });
    setSortToggle && setSortToggle(false);
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex ml-3 md:ml-5 mt-3 flex-col transition duration-500 ease-in-out space-y-5",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "topics flex-col space-y-2 text-sm",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase font-medium",
        children: "sort by"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "ml-4 flex-col space-y-2",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center space-x-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            onClick: () => handleSort("newest"),
            className: `${sort === "newest" ? "bg-primary-dark" : ""} 
                            border cursor-pointer rounded w-4 h-4 border-primary-dark`
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "capitalize font-light",
            children: "newest"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center space-x-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            onClick: () => handleSort("oldest"),
            className: `${sort === "oldest" ? "bg-primary-dark" : ""}
                            border cursor-pointer rounded w-4 h-4 border-primary-dark`
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "capitalize font-light",
            children: "Oldest"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center space-x-1",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            onClick: () => handleSort("a-z"),
            className: `${sort === "a-z" ? "bg-primary-dark" : ""}
                            border cursor-pointer rounded w-4 h-4 border-primary-dark`
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "capitalize font-light",
            children: "Alphabet: A-Z"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: `flex items-center space-x-1`,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            onClick: () => handleSort("z-a"),
            className: `${sort === "z-a" ? "bg-primary-dark" : ""} border cursor-pointer rounded w-4 h-4 border-primary-dark`
          }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "capitalize font-light",
            children: "Alphabet: Z-A"
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const sermons_SortItems = (SortItems);
;// CONCATENATED MODULE: ./components/sermons/Filter.js





const Filter = ({
  topics,
  preachers,
  scriptures,
  fitlerToggle,
  setFilterToggle,
  sortToggle,
  setSortToggle
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: ` ${fitlerToggle || sortToggle ? "pb-5 pt-1  w-full h-full min-h-screen fixed top-0 right-0  !z-50 !overflow-y-scroll !overscroll-contain" : "mb-5"}
            transition-all duration-500 ease-in-out lg:hidden  bg-[white]`,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-2 items-center ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `${fitlerToggle ? "text-[white] bg-primary-dark" : "bg-[white] text-[black]"}
                    w-full border cursor-pointer border-primary-dark/50  `,
          children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "text-center  text-sm lg:text-xs  py-4 uppercase",
            onClick: () => {
              if (!sortToggle) {
                setFilterToggle(!fitlerToggle);
              } else {
                setSortToggle(!sortToggle);
                setFilterToggle(!fitlerToggle);
              }
            },
            children: "filter"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: ` ${sortToggle ? "bg-primary-dark text-[white]" : " bg-[white] text-[black] "} w-full cursor-pointer border border-primary-dark/50 `,
          children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "text-center text-sm lg:text-xs py-4 uppercase",
            onClick: () => {
              if (!fitlerToggle) {
                setSortToggle(!sortToggle);
              } else {
                setFilterToggle(!fitlerToggle);
                setSortToggle(!sortToggle);
              }
            },
            children: " sort"
          })
        })]
      }), fitlerToggle && /*#__PURE__*/jsx_runtime_.jsx(sermons_FilterItems, {
        setFilterToggle: setFilterToggle,
        fitlerToggle: fitlerToggle,
        topics: topics,
        preachers: preachers,
        scriptures: scriptures
      }), sortToggle && /*#__PURE__*/jsx_runtime_.jsx(sermons_SortItems, {
        setSortToggle: setSortToggle
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "hidden lg:block bg-[white]",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-2 items-center shadow-md",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `${!sortToggle ? "bg-primary-dark text-[white]" : "bg-[white] text-[black]"}
                    w-full cursor-pointer border border-primary-dark/30 `,
          children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "text-center text-sm lg:text-xs py-2 uppercase",
            onClick: () => {
              if (!sortToggle) {
                setFilterToggle(!fitlerToggle);
              } else {
                setSortToggle(!sortToggle);
                setFilterToggle(!fitlerToggle);
              }
            },
            children: "filter"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `${sortToggle ? "bg-primary-dark text-[white]" : "bg-[white] text-[black]"}
                    w-full cursor-pointer border border-primary-dark/30`,
          children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "text-center text-sm lg:text-xs py-2 uppercase",
            onClick: () => {
              if (!fitlerToggle) {
                setSortToggle(!sortToggle);
              } else {
                setFilterToggle(!fitlerToggle);
                setSortToggle(!sortToggle);
              }
            },
            children: "sort"
          })
        })]
      }), fitlerToggle ? /*#__PURE__*/jsx_runtime_.jsx(sermons_FilterItems, {
        topics: topics,
        preachers: preachers,
        scriptures: scriptures
      }) : sortToggle ? /*#__PURE__*/jsx_runtime_.jsx(sermons_SortItems, {}) : /*#__PURE__*/jsx_runtime_.jsx(sermons_FilterItems, {
        topics: topics,
        preachers: preachers,
        scriptures: scriptures
      })]
    })]
  });
};

/* harmony default export */ const sermons_Filter = (Filter);

/***/ }),

/***/ 7794:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(8319);


/***/ }),

/***/ 29:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ })

};
;