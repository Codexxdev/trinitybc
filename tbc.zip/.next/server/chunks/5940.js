"use strict";
exports.id = 5940;
exports.ids = [5940];
exports.modules = {

/***/ 5940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ news_New)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Editor.js



const Editor = ({
  onChange,
  editorLoaded,
  name,
  value
}) => {
  const editorRef = (0,external_react_.useRef)();
  const {
    CKEditor,
    ClassicEditor
  } = editorRef.current || {};
  (0,external_react_.useEffect)(() => {
    editorRef.current = {
      CKEditor: (__webpack_require__(384).CKEditor),
      // v3+
      ClassicEditor: __webpack_require__(5614)
    };
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: editorLoaded ? /*#__PURE__*/jsx_runtime_.jsx(CKEditor, {
      type: "",
      name: name,
      editor: ClassicEditor,
      data: value,
      onChange: (event, editor) => {
        const data = editor.getData(); // console.log({ event, editor, data })

        onChange(data);
      }
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: "Editor loading"
    })
  });
};

/* harmony default export */ const components_Editor = (Editor);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./components/common/ImageUploader.js
var ImageUploader = __webpack_require__(6688);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/features/addNews.js
var addNews = __webpack_require__(8857);
// EXTERNAL MODULE: ./components/common/ButtonLoader.js
var ButtonLoader = __webpack_require__(1947);
// EXTERNAL MODULE: ./redux/features/newsDetails.js
var newsDetails = __webpack_require__(4165);
;// CONCATENATED MODULE: ./components/Dashboard/events/news/New.js













const New = ({
  name
}) => {
  const {
    0: imageUrl,
    1: setImageUrl
  } = (0,external_react_.useState)('');
  const {
    0: imagePreview,
    1: setImagePreview
  } = (0,external_react_.useState)('');
  const {
    0: editorLoaded,
    1: setEditorLoaded
  } = (0,external_react_.useState)(false);
  const {
    0: data,
    1: setData
  } = (0,external_react_.useState)("");
  const {
    0: title,
    1: setTitle
  } = (0,external_react_.useState)("");
  const {
    0: action,
    1: setAction
  } = (0,external_react_.useState)("");
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const router = (0,router_.useRouter)();
  const dispatch = (0,external_react_redux_.useDispatch)();
  const {
    id
  } = router.query;
  (0,external_react_.useEffect)(() => {
    setEditorLoaded(true);

    if (name === "update news") {
      dispatch((0,newsDetails/* getNewsDetails */.f9)(id)).then(res => {
        if (!res.error) {
          const {
            title,
            action,
            body,
            imageUrl
          } = res.payload.news;
          setTitle(title);
          setAction(action);
          setData(body);
          setImageUrl(imageUrl);
          setImagePreview(imageUrl.url);
        }
      });
    }
  }, []);

  const handleSubmit = e => {
    e.preventDefault();
    setLoading(true);

    if (title && action && data && imageUrl) {
      name === "add news" && dispatch((0,addNews/* postAddNews */.H)({
        body: data,
        title,
        action,
        imageUrl
      })).then(res => {
        if (!res.error) {
          setLoading(false);
          external_react_toastify_.toast.success("News Added Successfully");
          router.back();
        } else {
          setLoading(false);
          console.log(res.error);
        }
      });
      name === "update news" && dispatch((0,newsDetails/* updateNews */.jB)({
        id,
        body: data,
        title,
        action,
        imageUrl
      })).then(res => {
        if (!res.error) {
          setLoading(false);
          external_react_toastify_.toast.success("News Updated Successfully");
          router.back();
        } else {
          setLoading(false);
          console.log(res.error);
        }
      });
    } else {
      external_react_toastify_.toast.info('Please fill all the fields');
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex  w-full min-h-screen  my-2  mx-2 rounded-2xl bg-white",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full flex flex-col space-y-7 h-fit items-center  pt-5 px-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "uppercase text-lg text-primary-dark font-medium",
        children: name
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
        className: "w-full flex flex-col space-y-4",
        autoComplete: "off",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full h-full grid grid-cols-12 items-center gap-5",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "col-span-7 space-y-5 w-full text-gray-700 ",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "title",
                className: "ml-2 text-sm uppercase",
                children: `News title`
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "title",
                name: "title",
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                required: true,
                value: title,
                onChange: e => {
                  setTitle(e.target.value);
                }
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                htmlFor: "name",
                className: "ml-2 text-sm uppercase",
                children: "Call to action"
              }), /*#__PURE__*/jsx_runtime_.jsx("select", {
                type: "text",
                name: "category",
                className: "w-full capitalize text-gray-500 !px-1 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                value: action,
                onChange: e => {
                  setAction(e.target.value);
                },
                children: ["select call to action", "give"].map(action => /*#__PURE__*/jsx_runtime_.jsx("option", {
                  className: "capitalize",
                  value: action,
                  children: action
                }, action))
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-span-5 space-y-5 w-full text-gray-700 ",
            children: /*#__PURE__*/jsx_runtime_.jsx(ImageUploader/* default */.Z, {
              imagePreview: imagePreview,
              setImagePreview: setImagePreview,
              setImageUrl: setImageUrl,
              imageUrl: imageUrl,
              height: "h-44"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col w-full space-y-3",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: "ml-2 text-sm uppercase",
            children: " Body"
          }), /*#__PURE__*/jsx_runtime_.jsx(components_Editor, {
            name: "description",
            onChange: data => {
              setData(data);
            },
            editorLoaded: editorLoaded,
            value: data
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center justify-between w-full !mt-5 mb-3",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            onClick: () => {
              router.back();
            },
            className: "cursor-pointer text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-red-700",
            children: "cancel"
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            onClick: handleSubmit,
            className: "text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-blue-600",
            children: loading ? /*#__PURE__*/jsx_runtime_.jsx(ButtonLoader/* default */.Z, {}) : name === "update news" ? "update" : "add"
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const news_New = (New);

/***/ })

};
;