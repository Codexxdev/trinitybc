"use strict";
exports.id = 1757;
exports.ids = [1757];
exports.modules = {

/***/ 2666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "l_": () => (/* binding */ deleteRegister),
  "EC": () => (/* binding */ getAdminRegisters),
  "pi": () => (/* binding */ postRegister)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/Register.js

const registerSchema = new (external_mongoose_default()).Schema({
  conference: {
    type: (external_mongoose_default()).Schema.ObjectId,
    required: true,
    ref: 'conference'
  },
  email: {
    type: String,
    required: true
  },
  firstName: {
    type: String,
    required: true
  },
  lastName: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const Register = ((external_mongoose_default()).models.Register || external_mongoose_default().model('Register', registerSchema));
// EXTERNAL MODULE: ./models/Event.js
var Event = __webpack_require__(1730);
// EXTERNAL MODULE: external "express-async-handler"
var external_express_async_handler_ = __webpack_require__(2776);
var external_express_async_handler_default = /*#__PURE__*/__webpack_require__.n(external_express_async_handler_);
// EXTERNAL MODULE: ./middleware/errorHandler.js
var errorHandler = __webpack_require__(21);
;// CONCATENATED MODULE: ./controllers/registerController.js



 // post Register
// post =>  /api/admin/Register

const postRegister = external_express_async_handler_default()(async (req, res, next) => {
  const register = await Register.create(req.body);
  res.status(200).json({
    success: "true",
    message: "Register created successfully"
  });
}); // create Registers
// get =>  /api/admin/Registers

const getAdminRegisters = external_express_async_handler_default()(async (req, res, next) => {
  const registers = await Register.find({}).sort('-date').populate({
    path: 'conference',
    select: "title",
    model: Event/* default */.Z
  });
  res.status(200).json({
    success: "true",
    registers
  });
}); // Delete register
// Delete => api/admin/register/:id

const deleteRegister = external_express_async_handler_default()(async (req, res, next) => {
  const register = await Register.findById(req.query.id);

  if (!register) {
    return next(new errorHandler/* default */.Z('Register not found with this ID', 404));
  } else {
    await register.remove();
    res.status(200).json({
      success: "true",
      message: "Register Deleted"
    });
  }
});


/***/ }),

/***/ 1730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const eventSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  title: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  sessions: [{
    day: {
      type: String,
      required: true
    },
    topic: {
      type: String,
      required: true
    },
    preacher: {
      type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.ObjectId),
      ref: 'minister'
    },
    description: {
      type: String,
      required: true
    },
    startTime: {
      type: Date,
      required: true
    },
    endTime: {
      type: Date,
      required: true
    }
  }]
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Event) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Event', eventSchema));

/***/ })

};
;