"use strict";
exports.id = 4999;
exports.ids = [4999];
exports.modules = {

/***/ 4999:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "G6": () => (/* binding */ createService),
  "wo": () => (/* binding */ deleteService),
  "BU": () => (/* binding */ getAdminService),
  "ko": () => (/* binding */ getService),
  "U2": () => (/* binding */ getServices),
  "Pg": () => (/* binding */ updateService)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
;// CONCATENATED MODULE: ./models/Service.js

const serviceSchema = new (external_mongoose_default()).Schema({
  service: {
    type: String,
    required: true
  },
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  bulletin: {
    type: String
  }
});
/* harmony default export */ const Service = ((external_mongoose_default()).models.Service || external_mongoose_default().model('Service', serviceSchema));
// EXTERNAL MODULE: external "express-async-handler"
var external_express_async_handler_ = __webpack_require__(2776);
var external_express_async_handler_default = /*#__PURE__*/__webpack_require__.n(external_express_async_handler_);
// EXTERNAL MODULE: external "cloudinary"
var external_cloudinary_ = __webpack_require__(3518);
var external_cloudinary_default = /*#__PURE__*/__webpack_require__.n(external_cloudinary_);
// EXTERNAL MODULE: ./middleware/errorHandler.js
var errorHandler = __webpack_require__(21);
;// CONCATENATED MODULE: ./controllers/serviceController.js




external_cloudinary_default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // get client services
// get => /api/client/services

const getServices = external_express_async_handler_default()(async (req, res) => {
  const allServices = await Service.find({}).sort('endTime');
  const services = allServices.filter(service => new Date(service.endTime) > new Date());
  const defaultService = allServices[allServices.length - 1];
  res.status(200).json({
    success: "true",
    services,
    defaultService
  });
}); // create Service
// post =>  /api/admin/services

const createService = external_express_async_handler_default()(async (req, res, next) => {
  const service = await Service.create(req.body);
  service.save();
  console.log(req.body);
  res.status(200).json({
    success: "true",
    message: "Service created successfully"
  });
}); // get service
// get =>  /api/admin/service

const getAdminService = external_express_async_handler_default()(async (req, res, next) => {
  const services = await Service.find({});
  res.status(200).json({
    success: "true",
    services
  });
}); // Delete Service
// Delete => api/admin/Service/:id

const deleteService = external_express_async_handler_default()(async (req, res, next) => {
  const service = await Service.findById(req.query.id);

  if (!service) {
    return next(new errorHandler/* default */.Z('Service not found with this ID', 404));
  } else {
    if (service.imageUrl.public_id) {
      await external_cloudinary_default().v2.uploader.destroy(service.imageUrl.public_id);
    }

    await service.remove();
    res.status(200).json({
      success: "true",
      message: "Service Deleted"
    });
  }
}); // get service
// get => api/service/:id

const getService = external_express_async_handler_default()(async (req, res, next) => {
  const service = await Service.findById(req.query.id);

  if (!service) {
    return next(new errorHandler/* default */.Z('Service not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      service
    });
  }
}); // update Service
// put => api/service/:id

const updateService = external_express_async_handler_default()(async (req, res, next) => {
  const selected = await Service.findById(req.query.id);
  const {
    service,
    startTime,
    endTime,
    topic,
    imageUrl,
    bulletin
  } = req.body;

  if (!selected) {
    return next(new errorHandler/* default */.Z('Service not found with this ID', 404));
  } else {
    selected.service = service;
    selected.startTime = startTime;
    selected.endTime = endTime;
    selected.topic = topic;
    selected.bulletin = bulletin;

    if (imageUrl && imageUrl.public_id) {
      if (selected.imageUrl.public_id !== imageUrl.public_id) {
        await external_cloudinary_default().v2.uploader.destroy(selected.imageUrl.public_id);
        selected.imageUrl = imageUrl;
      }
    }

    await selected.save({
      validateBeforeSave: false
    });
    res.status(200).json({
      success: "true"
    });
  }
});


/***/ })

};
;