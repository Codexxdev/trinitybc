"use strict";
exports.id = 7361;
exports.ids = [7361];
exports.modules = {

/***/ 7361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i6": () => (/* binding */ createSermon),
/* harmony export */   "eU": () => (/* binding */ getAdminSermons),
/* harmony export */   "$_": () => (/* binding */ deleteSermon),
/* harmony export */   "sz": () => (/* binding */ getSermon),
/* harmony export */   "yh": () => (/* binding */ updateSermon),
/* harmony export */   "bl": () => (/* binding */ getSermons),
/* harmony export */   "Q1": () => (/* binding */ getSermonDetails),
/* harmony export */   "xh": () => (/* binding */ getSermonFilters)
/* harmony export */ });
/* harmony import */ var _models_Sermon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7173);
/* harmony import */ var _models_Ministers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3373);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2776);
/* harmony import */ var express_async_handler__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(express_async_handler__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3518);
/* harmony import */ var cloudinary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(cloudinary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21);





cloudinary__WEBPACK_IMPORTED_MODULE_3___default().config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
}); // get client sermons
// get => /api/client/sermons

const getSermons = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const {
    topic,
    preacher,
    scripture,
    sort
  } = req.query;
  const page = Number(req.query.page) || 1;
  const resPerPage = 10;
  const query = {};
  let sortQuery = '-date';

  if (sort) {
    sort === 'oldest' ? sortQuery = 'date' : sort === 'a-z' ? sortQuery = 'title' : sort === 'z-a' ? sortQuery = '-title' : sortQuery = '-date';
  }

  if (topic) {
    query.topic = {
      $regex: topic,
      $options: 'i'
    };
  }

  if (preacher) {
    query.preacher = preacher;
  }

  if (scripture) {
    query.book = {
      $regex: scripture,
      $options: 'i'
    };
  }

  const totalItems = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].countDocuments */ .Z.countDocuments(query);
  const sermons = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find(query).sort(sortQuery).skip((page - 1) * resPerPage).limit(resPerPage).populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    sermons,
    totalItems,
    resPerPage
  });
}); // get client sermons
// get => /api/client/sermons

const getSermonFilters = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const sermons = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort('-date').populate({
    path: 'preacher',
    select: "name imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  let dt = [];
  let dp = [];
  let ds = [];
  sermons.map(sermon => {
    dt.push(sermon.topic);
    dp.push(sermon.preacher.name);
    ds.push(sermon.book);
  });
  const topics = [...new Set(dt)];
  const preachers = [...new Set(dp)];
  const scriptures = [...new Set(ds)];
  res.status(200).json({
    success: "true",
    topics,
    preachers,
    scriptures
  });
}); // get client sermon detail
// get => /api/client/sermon/:id

const getSermonDetails = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const sermon = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'preacher',
    select: "name about imageUrl",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    sermon
  });
}); // create sermon
// post =>  /api/admin/sermons

const createSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const sermon = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create(req.body);
  res.status(200).json({
    success: "true",
    message: "Sermon created successfully"
  });
}); // get sermon
// get =>  /api/admin/sermons

const getAdminSermons = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const page = Number(req.query.page) || 1;
  const resPerPage = 10;
  const totalItems = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].countDocuments */ .Z.countDocuments({});
  const sermons = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].find */ .Z.find({}).sort('-date').skip((page - 1) * resPerPage).limit(resPerPage).populate({
    path: 'preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });
  res.status(200).json({
    success: "true",
    sermons,
    totalItems,
    resPerPage
  });
}); // Delete sermon
// Delete => api/admin/sermon/:id

const deleteSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const sermon = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!sermon) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Sermon not found with this ID', 404));
  } else {
    if (sermon.imageUrl.public_id) {
      await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(sermon.imageUrl.public_id);
    }

    await sermon.remove();
    res.status(200).json({
      success: "true",
      message: "sermon Deleted"
    });
  }
}); // get Sermon
// get => api/sermons/:id

const getSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const sermon = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id).populate({
    path: 'preacher',
    select: "name",
    model: _models_Ministers__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
  });

  if (!sermon) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Sermon not found with this ID', 404));
  } else {
    res.status(200).json({
      success: "true",
      sermon
    });
  }
}); // update Sermon
// put => api/sermons/:id

const updateSermon = express_async_handler__WEBPACK_IMPORTED_MODULE_2___default()(async (req, res, next) => {
  const sermon = await _models_Sermon__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findById */ .Z.findById(req.query.id);

  if (!sermon) {
    return next(new _middleware_errorHandler__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z('Sermon not found with this ID', 404));
  } else {
    const {
      title,
      category,
      topic,
      preacher,
      book,
      chapter,
      verse,
      date,
      description,
      imageUrl,
      audioUrl,
      youtubeLink
    } = req.body;
    sermon.title = title;
    sermon.category = category;
    sermon.topic = topic;
    sermon.preacher = preacher;
    sermon.book = book;
    sermon.chapter = chapter;
    sermon.verse = verse;
    sermon.date = date;
    sermon.description = description;
    sermon.audioUrl = audioUrl;
    sermon.youtubeLink = youtubeLink;

    if (imageUrl && imageUrl.public_id) {
      if (sermon.imageUrl && sermon.imageUrl.public_id && sermon.imageUrl.public_id !== imageUrl.public_id) {
        await cloudinary__WEBPACK_IMPORTED_MODULE_3___default().v2.uploader.destroy(sermon.imageUrl.public_id);
        sermon.imageUrl = imageUrl;
      } else {
        sermon.imageUrl = imageUrl;
      }
    } else {
      sermon.imageUrl = imageUrl;
    }
  }

  await sermon.save({
    validateBeforeSave: false
  });
  res.status(200).json({
    success: "true"
  });
});


/***/ }),

/***/ 3373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const ministerSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  name: {
    type: String,
    required: [true, 'Please enter your name']
  },
  role: {
    type: String,
    default: 'minister'
  },
  about: {
    type: String,
    required: [true, "Please enter minister's about"]
  },
  imageUrl: {
    public_id: {
      type: String,
      required: true
    },
    url: {
      type: String,
      required: true
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Minister) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Minister', ministerSchema));

/***/ }),

/***/ 7173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const sermonSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
  title: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true
  },
  topic: {
    type: String,
    required: true
  },
  preacher: {
    type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.ObjectId),
    required: true,
    ref: 'minister'
  },
  book: {
    type: String,
    required: true
  },
  chapter: {
    type: String,
    required: true
  },
  verse: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  imageUrl: {
    public_id: {
      type: String
    },
    url: {
      type: String
    }
  },
  audioUrl: {
    type: String,
    required: true
  },
  youtubeLink: {
    type: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Sermon) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('Sermon', sermonSchema));

/***/ })

};
;