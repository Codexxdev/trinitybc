"use strict";
exports.id = 3501;
exports.ids = [3501];
exports.modules = {

/***/ 3501:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ wrapper)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _features_menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5771);
/* harmony import */ var _features_currentUser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3998);
/* harmony import */ var _features_addMinister__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9506);
/* harmony import */ var _features_getMinisters__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7422);
/* harmony import */ var _features_getMinister__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1806);
/* harmony import */ var _features_addSermon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2769);
/* harmony import */ var _features_sermons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(272);
/* harmony import */ var _features_sermon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1810);
/* harmony import */ var _features_addBibleStudy__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3312);
/* harmony import */ var _features_bibleStudies__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9119);
/* harmony import */ var _features_bibleStudy__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(223);
/* harmony import */ var _features_addSeries__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4374);
/* harmony import */ var _features_series__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9884);
/* harmony import */ var _features_seriesDetails__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(228);
/* harmony import */ var _features_addConference__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1218);
/* harmony import */ var _features_conferences__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4620);
/* harmony import */ var _features_conference__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2961);
/* harmony import */ var _features_addEvent__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1505);
/* harmony import */ var _features_events__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4825);
/* harmony import */ var _features_event__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(3122);
/* harmony import */ var _features_addService__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(2934);
/* harmony import */ var _features_services__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(8797);
/* harmony import */ var _features_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6199);
/* harmony import */ var _features_client_sermons__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1134);
/* harmony import */ var _features_client_sermon__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(4160);
/* harmony import */ var _features_client_bibleStudies__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(1259);
/* harmony import */ var _features_client_bibleStudy__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(9695);
/* harmony import */ var _features_client_series__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(2227);
/* harmony import */ var _features_client_seriesDetails__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(3995);
/* harmony import */ var _features_client_conferences__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(3253);
/* harmony import */ var _features_client_conference__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(4153);
/* harmony import */ var _features_client_events__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(1630);
/* harmony import */ var _features_client_event__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(9023);
/* harmony import */ var _features_client_latest__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(9041);
/* harmony import */ var _features_client_ministers__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(7334);
/* harmony import */ var _features_addNews__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(8857);
/* harmony import */ var _features_news__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(2268);
/* harmony import */ var _features_newsDetails__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(4165);
/* harmony import */ var _features_register__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(5460);
/* harmony import */ var _features_emails__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(1868);
/* harmony import */ var _features_client_addRegister__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(9963);
/* harmony import */ var _features_client_addEmail__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(4509);
/* harmony import */ var _features_createUser__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(2993);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }














































const combinedReducers = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.combineReducers)({
  menu: _features_menu__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
  currentUser: _features_currentUser__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
  addMinister: _features_addMinister__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
  ministers: _features_getMinisters__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
  minister: _features_getMinister__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP,
  addSermon: _features_addSermon__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
  sermons: _features_sermons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP,
  sermon: _features_sermon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP,
  addBibleStudy: _features_addBibleStudy__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
  bibleStudies: _features_bibleStudies__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .ZP,
  bibleStudy: _features_bibleStudy__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .ZP,
  addSeries: _features_addSeries__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
  series: _features_series__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .ZP,
  seriesDetails: _features_seriesDetails__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .ZP,
  addConference: _features_addConference__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z,
  conferences: _features_conferences__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .ZP,
  conference: _features_conference__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .ZP,
  addEvent: _features_addEvent__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
  events: _features_events__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .ZP,
  event: _features_event__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .ZP,
  addService: _features_addService__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z,
  services: _features_services__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .ZP,
  service: _features_service__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .ZP,
  addNews: _features_addNews__WEBPACK_IMPORTED_MODULE_37__/* ["default"] */ .Z,
  news: _features_news__WEBPACK_IMPORTED_MODULE_38__/* ["default"] */ .ZP,
  register: _features_register__WEBPACK_IMPORTED_MODULE_40__/* ["default"] */ .ZP,
  email: _features_emails__WEBPACK_IMPORTED_MODULE_41__/* ["default"] */ .ZP,
  newsDetails: _features_newsDetails__WEBPACK_IMPORTED_MODULE_39__/* ["default"] */ .ZP,
  clientSermons: _features_client_sermons__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .ZP,
  clientSermon: _features_client_sermon__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z,
  clientBibleStudies: _features_client_bibleStudies__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .ZP,
  clientBibleStudy: _features_client_bibleStudy__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z,
  clientSeries: _features_client_series__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .ZP,
  clientSeriesDetails: _features_client_seriesDetails__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z,
  clientConferences: _features_client_conferences__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .ZP,
  clientConference: _features_client_conference__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z,
  clientEvents: _features_client_events__WEBPACK_IMPORTED_MODULE_33__/* ["default"] */ .ZP,
  clientEvent: _features_client_event__WEBPACK_IMPORTED_MODULE_34__/* ["default"] */ .ZP,
  latest: _features_client_latest__WEBPACK_IMPORTED_MODULE_35__/* ["default"] */ .ZP,
  clientMinisters: _features_client_ministers__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z,
  addRegister: _features_client_addRegister__WEBPACK_IMPORTED_MODULE_42__/* ["default"] */ .Z,
  addEmail: _features_client_addEmail__WEBPACK_IMPORTED_MODULE_43__/* ["default"] */ .Z,
  addUser: _features_createUser__WEBPACK_IMPORTED_MODULE_44__/* ["default"] */ .Z
});
const rootReducer = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createReducer)(combinedReducers(undefined, {
  type: ""
}), builder => {
  builder.addCase("__NEXT_REDUX_WRAPPER_HYDRATE__", (state, action) => _objectSpread(_objectSpread({}, state), action.payload)).addDefaultCase(combinedReducers);
});

const initStore = () => {
  const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: rootReducer,
    middleware: getDefaultMiddleware => getDefaultMiddleware({
      serializableCheck: false
    })
  });
  return store;
};

const wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.createWrapper)(initStore);

/***/ }),

/***/ 9963:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ postAddRegister),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const postAddRegister = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`user/postAddRegister`, async ({
  conference,
  email,
  firstName,
  lastName,
  phone
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/client/register`, {
      conference,
      email,
      firstName,
      lastName,
      phone
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const addRegisterSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'addRegister',
  initialState: {
    loading: true,
    message: null,
    error: null
  },
  reducers: {},
  extraReducers: {
    [postAddRegister.pending]: state => {
      state.loading = true;
    },
    [postAddRegister.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload.message;
    },
    [postAddRegister.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.error = payload;
    }
  }
}); // export const { deleteOne, addProduct } = addRegisterSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addRegisterSlice.reducer);

/***/ }),

/***/ 1259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dT": () => (/* binding */ getClientBibleStudies),
/* harmony export */   "yF": () => (/* binding */ getBibleStudyFilters),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientBibleStudies = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`bibleStudies/getClientBibleStudies`, async ({
  req,
  topic,
  preacher,
  scripture,
  page = 1,
  sort = 'newest'
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);
  let link = `${origin}/api/client/biblestudy?page=${page}&sort=${sort}`;

  if (topic) {
    link = link.concat(`&topic=${topic}`);
  }

  if (preacher) {
    link = link.concat(`&preacher=${preacher}`);
  }

  if (scripture) {
    link = link.concat(`&scripture=${scripture}`);
  }

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(link);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const getBibleStudyFilters = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`biblestudy/getBibleStudyFilters`, async ({
  req
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/biblestudy/filters`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const bibleStudiesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'bibleStudies',
  initialState: {
    loading: true,
    bibleStudies: [],
    resPerPage: 0,
    totalItems: 0,
    preachers: [],
    scriptures: [],
    topics: [],
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientBibleStudies.pending]: state => {
      state.loading = true;
    },
    [getClientBibleStudies.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.bibleStudies = payload.bibleStudies;
      state.resPerPage = payload.resPerPage;
      state.totalItems = payload.totalItems;
    },
    [getClientBibleStudies.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [getBibleStudyFilters.pending]: state => {
      state.loading = true;
    },
    [getBibleStudyFilters.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.topics = payload.topics;
      state.preachers = payload.preachers;
      state.scriptures = payload.scriptures;
    },
    [getBibleStudyFilters.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (bibleStudiesSlice.reducer);

/***/ }),

/***/ 9695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ getClientBibleStudyDetails),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientBibleStudyDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`bibleStudy/getClientBibleStudyDetails`, async ({
  req,
  id
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/biblestudy/${id}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const bibleStudySlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'bibleStudy',
  initialState: {
    loading: true,
    bibleStudy: {},
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientBibleStudyDetails.pending]: state => {
      state.loading = true;
    },
    [getClientBibleStudyDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.bibleStudy = payload.bibleStudy;
    },
    [getClientBibleStudyDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (bibleStudySlice.reducer);

/***/ }),

/***/ 4153:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ getClientConferenceDetails),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientConferenceDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conference/getClientConferenceDetails`, async ({
  req,
  id
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/conference/${id}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const conferenceSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'conference',
  initialState: {
    loading: true,
    conference: {},
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientConferenceDetails.pending]: state => {
      state.loading = true;
    },
    [getClientConferenceDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.conference = payload.conference;
    },
    [getClientConferenceDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (conferenceSlice.reducer);

/***/ }),

/***/ 3253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ov": () => (/* binding */ getClientConferences),
/* harmony export */   "Oy": () => (/* binding */ getConferenceFilters),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientConferences = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`conferences/getClientConferences`, async ({
  req,
  topic,
  preacher,
  scripture,
  page = 1,
  sort = 'newest'
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);
  let link = `${origin}/api/client/conference?page=${page}&sort=${sort}`;

  if (topic) {
    link = link.concat(`&topic=${topic}`);
  }

  if (preacher) {
    link = link.concat(`&preacher=${preacher}`);
  }

  if (scripture) {
    link = link.concat(`&scripture=${scripture}`);
  }

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(link);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const getConferenceFilters = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermons/getConferenceFilters`, async ({
  req
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/conference/filters`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const conferencesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'conferences',
  initialState: {
    loading: true,
    conferences: [],
    resPerPage: 0,
    totalItems: 0,
    preachers: [],
    scriptures: [],
    topics: [],
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientConferences.pending]: state => {
      state.loading = true;
    },
    [getClientConferences.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.conferences = payload.conferences;
      state.resPerPage = payload.resPerPage;
      state.totalItems = payload.totalItems;
    },
    [getClientConferences.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [getConferenceFilters.pending]: state => {
      state.loading = true;
    },
    [getConferenceFilters.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.topics = payload.topics;
      state.preachers = payload.preachers;
      state.scriptures = payload.scriptures;
    },
    [getConferenceFilters.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (conferencesSlice.reducer);

/***/ }),

/***/ 9023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s3": () => (/* binding */ getClientEventDetails),
/* harmony export */   "xA": () => (/* binding */ getClientNewsDetails),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientEventDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`event/getClientEventDetails`, async ({
  req,
  id
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/event/${id}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const getClientNewsDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`event/getClientNewsDetails`, async ({
  id
}, {
  rejectWithValue
}) => {
  // const { origin } = absoluteUrl(req)
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/client/news/${id}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const eventSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'event',
  initialState: {
    loading: true,
    event: {},
    news: {},
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientEventDetails.pending]: state => {
      state.loading = true;
    },
    [getClientEventDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.event = payload.event;
    },
    [getClientEventDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [getClientNewsDetails.pending]: state => {
      state.loading = true;
    },
    [getClientNewsDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.news = payload.news;
    },
    [getClientNewsDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (eventSlice.reducer);

/***/ }),

/***/ 1630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Iu": () => (/* binding */ getClientEvents),
/* harmony export */   "bo": () => (/* binding */ getClientNews),
/* harmony export */   "uq": () => (/* binding */ getClientServices),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientEvents = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`events/getClientEvents`, async ({
  month,
  next
}, {
  rejectWithValue
}) => {
  // const { origin } = absoluteUrl(req)
  let link = `/api/client/event`;

  if (month) {
    link = link.concat(`?month=${month}`);
  }

  if (next) {
    link = link.concat(`&next=${next}`);
  }

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(link);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const getClientNews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`events/getClientNews`, async (obj, {
  rejectWithValue
}) => {
  // const { origin } = absoluteUrl(req)
  let link = `/api/client/news`; // if (month) {
  //     link = link.concat(`?month=${month}`)
  // }
  // if (next) {
  //     link = link.concat(`&next=${next}`)
  // }

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(link);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const getClientServices = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`events/getClientServices`, async (obj, {
  rejectWithValue
}) => {
  // const { origin } = absoluteUrl(req)
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/client/service`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const eventsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'events',
  initialState: {
    loading: true,
    events: [],
    defaultEvent: {},
    defaultService: {},
    services: [],
    news: [],
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientEvents.pending]: state => {
      state.loading = true;
    },
    [getClientEvents.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.events = payload.events;
      state.defaultEvent = payload.defaultEvent;
    },
    [getClientEvents.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [getClientServices.pending]: state => {
      state.loading = true;
    },
    [getClientServices.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.services = payload.services;
      state.defaultService = payload.defaultService;
    },
    [getClientServices.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [getClientNews.pending]: state => {
      state.loading = true;
    },
    [getClientNews.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.news = payload.news;
    },
    [getClientNews.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (eventsSlice.reducer);

/***/ }),

/***/ 7334:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ getClientMinisters),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientMinisters = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`ministers/getClientMinisters`, async (obj, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/client/ministers`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const ministersSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'ministers',
  initialState: {
    loading: true,
    ministers: [],
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientMinisters.pending]: state => {
      state.loading = true;
    },
    [getClientMinisters.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.ministers = payload.ministers;
    },
    [getClientMinisters.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ministersSlice.reducer);

/***/ }),

/***/ 2227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q5": () => (/* binding */ getClientSeries),
/* harmony export */   "DY": () => (/* binding */ getSeriesFilters),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientSeries = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`series/getClientSeries`, async ({
  req,
  topic,
  preacher,
  scripture,
  page = 1,
  sort = 'newest'
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);
  let link = `${origin}/api/client/series?page=${page}&sort=${sort}`;

  if (topic) {
    link = link.concat(`&topic=${topic}`);
  }

  if (preacher) {
    link = link.concat(`&preacher=${preacher}`);
  }

  if (scripture) {
    link = link.concat(`&scripture=${scripture}`);
  }

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(link);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const getSeriesFilters = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermons/getSeriesFilters`, async ({
  req
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/series/filters`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const seriesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'series',
  initialState: {
    loading: true,
    series: [],
    resPerPage: 0,
    totalItems: 0,
    preachers: [],
    scriptures: [],
    topics: [],
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientSeries.pending]: state => {
      state.loading = true;
    },
    [getClientSeries.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.series = payload.series;
      state.resPerPage = payload.resPerPage;
      state.totalItems = payload.totalItems;
    },
    [getClientSeries.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [getSeriesFilters.pending]: state => {
      state.loading = true;
    },
    [getSeriesFilters.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.topics = payload.topics;
      state.preachers = payload.preachers;
      state.scriptures = payload.scriptures;
    },
    [getSeriesFilters.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (seriesSlice.reducer);

/***/ }),

/***/ 3995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ getClientSeriesDetails),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientSeriesDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`series/getClientSeriesDetails`, async ({
  req,
  id
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/series/${id}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const seriesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'series',
  initialState: {
    loading: true,
    series: {},
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientSeriesDetails.pending]: state => {
      state.loading = true;
    },
    [getClientSeriesDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.series = payload.series;
    },
    [getClientSeriesDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (seriesSlice.reducer);

/***/ }),

/***/ 4160:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ getClientSermonDetails),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientSermonDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermon/getClientSermonDetails`, async ({
  req,
  id
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/sermon/${id}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const sermonSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'sermon',
  initialState: {
    loading: true,
    sermon: {},
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientSermonDetails.pending]: state => {
      state.loading = true;
    },
    [getClientSermonDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.sermon = payload.sermon;
    },
    [getClientSermonDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sermonSlice.reducer);

/***/ }),

/***/ 1134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mF": () => (/* binding */ getClientSermons),
/* harmony export */   "xh": () => (/* binding */ getSermonFilters),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientSermons = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermons/getClientSermons`, async ({
  req,
  topic,
  preacher,
  scripture,
  page = 1,
  sort = 'newest'
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);
  let link = `${origin}/api/client/sermon?page=${page}&sort=${sort}`;

  if (topic) {
    link = link.concat(`&topic=${topic}`);
  }

  if (preacher) {
    link = link.concat(`&preacher=${preacher}`);
  }

  if (scripture) {
    link = link.concat(`&scripture=${scripture}`);
  }

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(link);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const getSermonFilters = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`sermons/getSermonFilters`, async ({
  req
}, {
  rejectWithValue
}) => {
  const {
    origin
  } = next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default()(req);

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`${origin}/api/client/sermon/filters`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const sermonsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'sermons',
  initialState: {
    loading: true,
    sermons: [],
    resPerPage: 0,
    totalItems: 0,
    preachers: [],
    scriptures: [],
    topics: [],
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientSermons.pending]: state => {
      state.loading = true;
    },
    [getClientSermons.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.sermons = payload.sermons;
      state.resPerPage = payload.resPerPage;
      state.totalItems = payload.totalItems;
    },
    [getClientSermons.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [getSermonFilters.pending]: state => {
      state.loading = true;
    },
    [getSermonFilters.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.topics = payload.topics;
      state.preachers = payload.preachers;
      state.scriptures = payload.scriptures;
    },
    [getSermonFilters.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sermonsSlice.reducer);

/***/ })

};
;