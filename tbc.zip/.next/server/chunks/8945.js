exports.id = 8945;
exports.ids = [8945,1947,1569];
exports.modules = {

/***/ 109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Events_Body)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Events/Introduction.js


const Introduction = ({
  int
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex flex-col space-y-2 px-2",
    children: /*#__PURE__*/jsx_runtime_.jsx("p", {
      className: " font-light text-justify",
      children: int
    })
  });
};

/* harmony default export */ const Events_Introduction = (Introduction);
;// CONCATENATED MODULE: ./components/Events/NavLink.js


const NavLink = ({
  name,
  toggleActive,
  active
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("h1", {
    onClick: () => {
      toggleActive(name);
    },
    className: `${active === name ? "bg-primary-dark text-white font-light" : "hover:bg-primary-dark/70 font-light hover:text-white"} uppercase text-sm py-1 px-2 cursor-pointer`,
    children: name
  });
};

/* harmony default export */ const Events_NavLink = (NavLink);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "date-fns"
var external_date_fns_ = __webpack_require__(4146);
;// CONCATENATED MODULE: ./components/Events/Schedule.js





const Schedule = ({
  sessions,
  startDate,
  endDate
}) => {
  const {
    0: dates,
    1: setDates
  } = (0,external_react_.useState)([]);
  const {
    0: schedules,
    1: setSchedules
  } = (0,external_react_.useState)([]);
  (0,external_react_.useEffect)(() => {
    const e = new Date(endDate);
    const s = new Date(startDate);
    const diff = e.getTime() - s.getTime();
    const days = Math.round(diff / (1000 * 60 * 60 * 24) + 1);
    const start = s.getTime();
    setDates([]);

    for (let i = 0; i < days; i++) {
      setDates(prev => [...prev, new Date(start + 1000 * 60 * 60 * 24 * i)]);
    }

    let subArr = [];

    for (let i = 1; i <= days; i++) {
      subArr.push([]);
    }

    for (let i = 1; i <= days; i++) {
      sessions.map(session => {
        if (session.day.includes(i.toString())) {
          subArr[i - 1].push(session);
        }
      });
    }

    subArr.forEach(sub => {
      sub.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
    });
    setSchedules(subArr);
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: " px-2 md:px-0",
      children: schedules.map((subArr, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-center text-sm text-primary-light uppercase font-medium",
          children: `Day ${index + 1} - ${(0,external_date_fns_.format)(new Date(dates[index]), 'do MMM yyyy')} `
        }), subArr.map((session, i) => /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "!mb-5",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col space-y-3 py-5 border-b border-b-primary-light   ",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex space-x-1 items-center ",
              children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                className: "text-sm  uppercase",
                children: `Session ${i + 1} :`
              }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
                className: "text-sm font-light uppercase",
                children: `${(0,external_date_fns_.format)(new Date(session.startTime), 'h:mm a')} - ${(0,external_date_fns_.format)(new Date(session.endTime), 'h:mm a')} `
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex flex-col space-y-2",
              children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
                className: "font-medium uppercase",
                children: session.topic
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "font-light text-sm text-justify",
                children: session.description
              })]
            }), session.preacher.name && /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-sm font-light capitalize",
              children: `Speaker: ${session.preacher.name}`
            })]
          })
        }, session._id))]
      }, index))
    })
  });
};

/* harmony default export */ const Events_Schedule = (Schedule);
// EXTERNAL MODULE: ./components/common/blur.js
var common_blur = __webpack_require__(1569);
;// CONCATENATED MODULE: ./components/Events/Speakers.js





const Speakers = ({
  speakers
}) => {
  const lister = () => {
    const preachers = [];
    speakers.map(session => {
      const inArray = preachers.find(preacher => preacher._id === session.preacher._id);

      if (!inArray) {
        preachers.push(session.preacher);
      }
    });
    return preachers.map(preacher => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col md:flex-row md:justify-between space-y-3 md:space-y-0 items-center md:space-x-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-full max-w-[100px] mx-auto h-[100px] rounded-full  relative",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
          src: preacher.imageUrl.url,
          className: "object-cover rounded-full w-full h-full",
          layout: "fill",
          blurDataURL: common_blur/* default */.Z,
          placeholder: "blur",
          alt: "logo"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "w-full space-y-3 md:space-y-1 px-2 md:px-0 ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: "text-center font-medium text-sm md:text-left uppercase ",
          children: preacher.name
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-sm font-light text-center md:text-justify",
          children: preacher.about
        })]
      })]
    }, preacher._id));
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "space-y-5 ",
    children: lister()
  });
};

/* harmony default export */ const Events_Speakers = (Speakers);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./redux/features/client/addRegister.js
var addRegister = __webpack_require__(9963);
// EXTERNAL MODULE: ./components/common/ButtonLoader.js
var ButtonLoader = __webpack_require__(1947);
;// CONCATENATED MODULE: ./components/Events/Register.js








const Register = ({
  conference
}) => {
  const {
    0: email,
    1: setEmail
  } = (0,external_react_.useState)('');
  const {
    0: firstName,
    1: setFirstName
  } = (0,external_react_.useState)('');
  const {
    0: lastName,
    1: setLastName
  } = (0,external_react_.useState)('');
  const {
    0: phone,
    1: setPhone
  } = (0,external_react_.useState)('');
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(false);
  const dispatch = (0,external_react_redux_.useDispatch)();

  const handleSubmit = e => {
    e.preventDefault();
    setLoading(true);

    if (email !== null && email !== void 0 && email.includes('@') && email !== null && email !== void 0 && email.includes('.') && firstName && lastName && phone && conference) {
      console.log(email, firstName, lastName, phone, conference);
      dispatch((0,addRegister/* postAddRegister */.D)({
        email,
        firstName,
        lastName,
        phone,
        conference
      })).then(res => {
        if (!res.error) {
          setFirstName('');
          setLastName('');
          setEmail('');
          setPhone('');
          setLoading(false);
          external_react_toastify_.toast.success('Successfully registered!');
        } else {
          setLoading(false);
          external_react_toastify_.toast.error('Registration failed!');
        }
      });
    } else {
      setLoading(false);
      external_react_toastify_.toast.info('Please enter a valid email');
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "max-w-full px-3 md:px-0 md:max-w-[400px] mx-auto",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      className: "space-y-3",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "firstname",
          className: "text-xs uppercase font-medium mb-2 ",
          children: "First Name: *"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "name",
          name: "name",
          className: "w-full px-3  py-2 md:text-xs xl:text-sm  border border-gray-300 focus:outline-none",
          value: firstName,
          onChange: e => {
            setFirstName(e.target.value);
          }
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "lastname",
          className: "text-xs uppercase font-medium mb-2 ",
          children: "Last Name: *"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "name",
          name: "name",
          className: "w-full px-3  py-2 md:text-xs xl:text-sm  border border-gray-300 focus:outline-none",
          value: lastName,
          onChange: e => {
            setLastName(e.target.value);
          }
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "email",
          className: "text-xs uppercase font-medium mb-2 ",
          children: "Email Address: *"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "email",
          name: "email address",
          className: "w-full px-3  py-2 md:text-xs xl:text-sm  border border-gray-300 focus:outline-none",
          value: email,
          onChange: e => {
            setEmail(e.target.value);
          }
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          htmlFor: "phonenumber",
          className: "text-xs uppercase font-medium !mb-5 ",
          children: "Phone Number: *"
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "number",
          name: "number",
          className: "w-full px-3  py-2 md:text-xs xl:text-sm  border border-gray-300 focus:outline-none",
          value: phone,
          onChange: e => {
            setPhone(e.target.value.toString());
          }
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-center space-x-3 items-center !mt-5",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: handleSubmit,
          className: "text-sm uppercase text-white bg-primary-light py-1 shadow-md hover:shadow-xl px-4",
          children: loading ? /*#__PURE__*/jsx_runtime_.jsx(ButtonLoader/* default */.Z, {}) : 'Register'
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-xs uppercase font-medium",
          children: "you can also!"
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "text-sm uppercase text-white bg-primary-dark py-1 shadow-md hover:shadow-xl px-4",
          children: "Donate"
        })]
      })]
    })
  });
};

/* harmony default export */ const Events_Register = (Register);
;// CONCATENATED MODULE: ./components/Events/Body.js













const Body = () => {
  const {
    0: active,
    1: setActive
  } = (0,external_react_.useState)('introduction');
  const {
    event
  } = (0,external_react_redux_.useSelector)(state => state.clientEvent);

  const toggleActive = name => {
    if (active !== name) {
      setActive(name);
    }
  };

  const date = (start, end) => {
    if (start === end) {
      return (0,external_date_fns_.format)(new Date(start), 'MMM, do yyyy');
    } else {
      return `${(0,external_date_fns_.format)(new Date(start), 'do')} - ${(0,external_date_fns_.format)(new Date(end), 'do MMM yyyy')}`;
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "bg-[#eee]/60 sm:!pt-20 !pt-[60px] !mb-3  !pb-5",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "max-w-screen-sm mx-auto ",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col space-y-3 w-full",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full h-[250px] sm:h-[300px] relative",
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
              src: "https://res.cloudinary.com/dk6uhtgvo/image/upload/v1651307275/Global/conference_eojsyc.jpg",
              className: "object-cover w-full h-full",
              layout: "fill",
              blurDataURL: common_blur/* default */.Z,
              placeholder: "blur",
              alt: "logo"
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col space-y-2 items-center justify-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-xs uppercase",
              children: event.type
            }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-xl md:text-3xl font-medium uppercase",
              children: event.title
            }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: "text-sm capitalize",
              children: date(event.startDate, event.endDate)
            })]
          })]
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "max-w-screen-sm mx-auto mt-2 space-y-8 ",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex w-full overflow-x-auto overscroll-contain box-border justify-between font-medium space-x-3 px-2 md:px-0 py-2 border-b border-b-primary-dark ",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Events_NavLink, {
          name: "introduction",
          toggleActive: toggleActive,
          active: active
        }), /*#__PURE__*/jsx_runtime_.jsx(Events_NavLink, {
          name: "speakers",
          toggleActive: toggleActive,
          active: active
        }), /*#__PURE__*/jsx_runtime_.jsx(Events_NavLink, {
          name: "schedule",
          toggleActive: toggleActive,
          active: active
        }), /*#__PURE__*/jsx_runtime_.jsx(Events_NavLink, {
          name: "register",
          toggleActive: toggleActive,
          active: active
        })]
      }), active === 'introduction' && /*#__PURE__*/jsx_runtime_.jsx(Events_Introduction, {
        int: event.description
      }), active === 'speakers' && /*#__PURE__*/jsx_runtime_.jsx(Events_Speakers, {
        speakers: event.sessions
      }), active === 'schedule' && /*#__PURE__*/jsx_runtime_.jsx(Events_Schedule, {
        sessions: event.sessions,
        startDate: event.startDate,
        endDate: event.endDate
      }), active === 'register' && /*#__PURE__*/jsx_runtime_.jsx(Events_Register, {
        conference: event._id
      })]
    })]
  });
};

/* harmony default export */ const Events_Body = (Body);

/***/ }),

/***/ 1947:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3060);
/* harmony import */ var react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const ButtonLoader = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx((react_spinners_BeatLoader__WEBPACK_IMPORTED_MODULE_0___default()), {
    color: "#ffffff",
    size: 10
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonLoader);

/***/ }),

/***/ 1569:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const blur = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wgARCAAKAAoDASIAAhEBAxEB/8QAFwAAAwEAAAAAAAAAAAAAAAAAAAMGB//EABQBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAdDRKg//xAAYEAADAQEAAAAAAAAAAAAAAAABAgMQE//aAAgBAQABBQJpyA4Jv//EABURAQEAAAAAAAAAAAAAAAAAAAAR/9oACAEDAQE/Aa//xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAgBAgEBPwGP/8QAGxAAAAcBAAAAAAAAAAAAAAAAAAECEDEzkqL/2gAIAQEABj8CrRkRyT//xAAbEAACAQUAAAAAAAAAAAAAAAABEQAQIWGR4f/aAAgBAQABPyFiOpG3UY4V/9oADAMBAAIAAwAAABAD/8QAFxEAAwEAAAAAAAAAAAAAAAAAAAERMf/aAAgBAwEBPxBRh//EABcRAAMBAAAAAAAAAAAAAAAAAAABETH/2gAIAQIBAT8Qdaf/xAAcEAAABgMAAAAAAAAAAAAAAAAAAREhQVEQMWH/2gAIAQEAAT8QmtEUBLbaF13QxzL/2Q==";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blur);

/***/ }),

/***/ 7794:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(8319);


/***/ }),

/***/ 29:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ })

};
;