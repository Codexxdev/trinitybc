"use strict";
exports.id = 9041;
exports.ids = [9041];
exports.modules = {

/***/ 9041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O3": () => (/* binding */ getClientLatest),
/* harmony export */   "Kw": () => (/* binding */ searchAllResources),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5506);
/* harmony import */ var next_absolute_url__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_absolute_url__WEBPACK_IMPORTED_MODULE_2__);



const getClientLatest = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`latest/getClientLatest`, async (obj, {
  rejectWithValue
}) => {
  // const { origin } = absoluteUrl(req)
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const searchAllResources = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`latest/searchAllResources`, async ({
  keyword,
  page = 1
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/search?keyword=${keyword}&page=${page}`);
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const latestSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'latest',
  initialState: {
    loading: true,
    latest: [],
    searchResults: [],
    resPerPage: 0,
    totalItems: 0,
    message: null
  },
  reducers: {},
  extraReducers: {
    [getClientLatest.pending]: state => {
      state.loading = true;
    },
    [getClientLatest.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.latest = payload.latest;
    },
    [getClientLatest.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [searchAllResources.pending]: state => {
      state.loading = true;
    },
    [searchAllResources.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.searchResults = payload.all;
      state.resPerPage = payload.resPerPage;
      state.totalItems = payload.totalItems;
    },
    [searchAllResources.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (latestSlice.reducer);

/***/ })

};
;