"use strict";
exports.id = 9422;
exports.ids = [9422];
exports.modules = {

/***/ 8857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ postAddNews),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const postAddNews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`user/postAddNews`, async ({
  title,
  action,
  body,
  imageUrl
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/admin/news`, {
      title,
      action,
      body,
      imageUrl
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const addNewsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'addNews',
  initialState: {
    loading: true,
    message: null,
    error: null
  },
  reducers: {},
  extraReducers: {
    [postAddNews.pending]: state => {
      state.loading = true;
    },
    [postAddNews.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload.message;
    },
    [postAddNews.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.error = payload;
    }
  }
}); // export const { deleteOne, addProduct } = addNewsSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addNewsSlice.reducer);

/***/ }),

/***/ 4165:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f9": () => (/* binding */ getNewsDetails),
/* harmony export */   "jB": () => (/* binding */ updateNews),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getNewsDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`news/getNewsDetails`, async (id, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`/api/admin/news/${id}`);
    return data;
  } catch (error) {
    console.log(rejectWithValue(error));
    return rejectWithValue(error.response.data.message);
  }
});
const updateNews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`news/updateNews`, async ({
  id,
  title,
  action,
  body,
  imageUrl
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`/api/admin/news/${id}`, {
      id,
      title,
      action,
      body,
      imageUrl
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const newsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'news',
  initialState: {
    loading: false,
    news: null,
    message: null
  },
  reducers: {},
  extraReducers: {
    [getNewsDetails.pending]: state => {
      state.loading = true;
    },
    [getNewsDetails.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.news = payload.news;
    },
    [getNewsDetails.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    },
    [updateNews.pending]: state => {
      state.loading = true;
    },
    [updateNews.fulfilled]: state => {
      state.loading = false;
    },
    [updateNews.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload;
    }
  }
}); // export const { deleteOne, addnews } = newsSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (newsSlice.reducer);

/***/ })

};
;