"use strict";
exports.id = 3858;
exports.ids = [3858];
exports.modules = {

/***/ 3858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6146);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6902);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(983);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_datepicker__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5994);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _common_ImageUploader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6688);
/* harmony import */ var _redux_features_addSeries__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4374);
/* harmony import */ var _common_ButtonLoader__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1947);
/* harmony import */ var _redux_features_addConference__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1218);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
















const lists = (/* unused pure expression or super */ null && ([]));

const New = ({
  name
}) => {
  const {
    0: imageUrl,
    1: setImageUrl
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: imagePreview,
    1: setImagePreview
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: title,
    1: setTitle
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: description,
    1: setDescription
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
  const {
    0: startDate,
    1: setStartDate
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: endDate,
    1: setEndDate
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {}, []);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();

  const handleSubmit = e => {
    e.preventDefault();

    if (name === 'series') {
      if (title, description, imageUrl) {
        setLoading(true);
        dispatch((0,_redux_features_addSeries__WEBPACK_IMPORTED_MODULE_11__/* .postAddSeries */ .v)({
          title,
          description,
          imageUrl
        })).then(result => {
          if (!result.error) {
            setLoading(false);
            react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.success('Series Created Successfully');
            router.back();
          } else {
            setLoading(false);
            console.log(result.error);
          }
        });
      } else {
        react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.info('Please fill all the required fields');
      }
    }

    if (name === 'conference') {
      if (title, description, imageUrl, startDate, endDate) {
        setLoading(true);
        dispatch((0,_redux_features_addConference__WEBPACK_IMPORTED_MODULE_13__/* .postAddConference */ .a)({
          title,
          description,
          imageUrl,
          startDate,
          endDate
        })).then(result => {
          if (!result.error) {
            setLoading(false);
            react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.success('Conference Created Successfully');
            router.back();
          } else {
            setLoading(false);
            console.log(result.error);
          }
        });
      } else {
        react_toastify__WEBPACK_IMPORTED_MODULE_7__.toast.info('Please fill all the required fields');
      }
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("div", {
    className: "flex  w-full min-h-screen  my-2  mx-2 rounded-2xl bg-white",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
      className: "w-full flex flex-col space-y-7  h-fit items-center  pt-5 px-3",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("h1", {
        className: "uppercase text-lg text-primary-dark font-medium",
        children: `create New ${name}`
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("form", {
        className: "w-full",
        autoComplete: "off",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
          className: "w-full h-full grid grid-cols-12 items-center gap-5",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
            className: "col-span-7 space-y-5 w-full text-gray-700 ",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
              className: "space-y-2",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("label", {
                htmlFor: "title",
                className: "ml-2 text-sm uppercase",
                children: `${name} title`
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("input", {
                type: "title",
                name: "title",
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                required: true,
                value: title,
                onChange: e => {
                  setTitle(e.target.value.toLowerCase());
                }
              })]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
              className: "w-full space-y-2",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("label", {
                htmlFor: "description",
                className: "ml-2 text-sm uppercase",
                children: `${name} description`
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("textarea", {
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                rows: `${name === "series" ? "8" : "10"}`,
                value: description,
                onChange: e => {
                  setDescription(e.target.value.toLowerCase());
                }
              })]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
            className: "col-span-5 space-y-5 w-full text-gray-700 ",
            children: [name === "conference" && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
              className: "space-y-2 w-full",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("label", {
                htmlFor: "name",
                className: "ml-2 text-sm uppercase",
                children: "Conference Date"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx((react_datepicker__WEBPACK_IMPORTED_MODULE_8___default()), {
                selectsRange: true,
                selected: startDate,
                startDate: startDate,
                endDate: endDate,
                className: "w-full px-3 py-2 text-sm rounded-md border-gray-300  border focus:outline-none focus:ring-1 focus:ring-primary-light",
                onChange: dates => {
                  const [startDate, endDate] = dates;
                  setStartDate(startDate);
                  setEndDate(endDate);
                },
                isClearable: true
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_ImageUploader__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
              imagePreview: imagePreview,
              setImagePreview: setImagePreview,
              setImageUrl: setImageUrl,
              imageUrl: imageUrl,
              height: "h-52"
            })]
          })]
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsxs)("div", {
        className: "flex items-center justify-between w-full !mb-3",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("h1", {
          onClick: () => {
            router.back();
          },
          className: "cursor-pointer text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-red-700",
          children: "cancel"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx("button", {
          onClick: handleSubmit,
          className: "text-center text-white py-1.5 rounded-md text-sm  px-7 uppercase bg-blue-600",
          children: loading ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_common_ButtonLoader__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}) : "create"
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (New);

/***/ })

};
;