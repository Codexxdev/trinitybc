"use strict";
exports.id = 3036;
exports.ids = [3036];
exports.modules = {

/***/ 1218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ postAddConference),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const postAddConference = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`addConference/postAddConference`, async ({
  title,
  description,
  imageUrl,
  startDate,
  endDate
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/admin/conference`, {
      title,
      description,
      imageUrl,
      startDate,
      endDate
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const addConferenceSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'addConference',
  initialState: {
    loading: false,
    message: null,
    error: null
  },
  reducers: {},
  extraReducers: {
    [postAddConference.pending]: state => {
      state.loading = true;
    },
    [postAddConference.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload.message;
    },
    [postAddConference.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.error = payload;
    }
  }
}); // export const { deleteOne, addProduct } = addConferenceSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addConferenceSlice.reducer);

/***/ }),

/***/ 4374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ postAddSeries),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const postAddSeries = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)(`addSeries/postAddSeries`, async ({
  title,
  description,
  imageUrl
}, {
  rejectWithValue
}) => {
  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`/api/admin/series`, {
      title,
      description,
      imageUrl
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });
    return data;
  } catch (error) {
    return rejectWithValue(error.response.data.message);
  }
});
const addSeriesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: 'addSeries',
  initialState: {
    loading: false,
    message: null,
    error: null
  },
  reducers: {},
  extraReducers: {
    [postAddSeries.pending]: state => {
      state.loading = true;
    },
    [postAddSeries.fulfilled]: (state, {
      payload
    }) => {
      state.loading = false;
      state.message = payload.message;
    },
    [postAddSeries.rejected]: (state, {
      payload
    }) => {
      state.loading = false;
      state.error = payload;
    }
  }
}); // export const { deleteOne, addProduct } = addSeriesSlice.actions

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addSeriesSlice.reducer);

/***/ })

};
;